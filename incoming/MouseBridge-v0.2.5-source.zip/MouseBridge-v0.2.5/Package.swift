// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "MouseBridge",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "MouseBridge", targets: ["MouseBridge"]),
    ],
    dependencies: [
        .package(url: "https://github.com/sparkle-project/Sparkle", exact: "2.9.4"),
    ],
    targets: [
        .systemLibrary(
            name: "MultitouchSupport",
            path: "Sources/MultitouchSupport"
        ),
        .executableTarget(
            name: "MouseBridge",
            dependencies: [
                "MultitouchSupport",
                .product(name: "Sparkle", package: "Sparkle"),
            ],
            path: "Sources/MouseBridge",
            swiftSettings: [.swiftLanguageMode(.v5)],
            linkerSettings: [
                .linkedFramework("MultitouchSupport"),
                .unsafeFlags(["-F/System/Library/PrivateFrameworks"]),
                .unsafeFlags(["-Xlinker", "-rpath", "-Xlinker", "@executable_path/../Frameworks"]),
            ]
        ),
        .testTarget(
            name: "MouseBridgeTests",
            dependencies: ["MouseBridge"],
            path: "Tests/MouseBridgeTests"
        ),
    ]
)
