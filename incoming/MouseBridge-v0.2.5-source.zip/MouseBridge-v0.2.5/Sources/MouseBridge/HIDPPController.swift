// SPDX-License-Identifier: GPL-3.0-or-later
// HID++ adjustable-DPI list decoding is adapted from Solaar,
// Copyright 2012-2013 Daniel Pavel and Solaar contributors,
// originally licensed under GPL-2.0-or-later. See LICENSES/.
// Modified and reimplemented for MouseBridge in 2026.

import Foundation
import IOKit.hid

struct MouseDeviceProfile: Sendable {
    let name: String
    let vendorID: Int
    let productIDs: Set<Int>
    let usagePage: Int
    let usage: Int
    var usesOutputElement = false
    var fallbackDPIs: [Int] = Array(stride(from: 400, through: 4000, by: 50))

    static let m750Bluetooth = MouseDeviceProfile(
        name: "Logitech Signature Plus M750 L",
        vendorID: 0x046D,
        productIDs: [0xB02C],
        usagePage: 1,
        usage: 2
    )

    static let mxMaster3SBluetooth = MouseDeviceProfile(
        name: "MX Master 3S", vendorID: 0x046D, productIDs: [0xB034],
        usagePage: 1, usage: 2, usesOutputElement: true,
        fallbackDPIs: [] // MX requires a device-reported range before any write.
    )
    static let supported: [MouseDeviceProfile] = [.m750Bluetooth, .mxMaster3SBluetooth]

    var matchingDictionaries: [[String: Any]] {
        productIDs.map {
            [
                kIOHIDVendorIDKey as String: vendorID,
                kIOHIDProductIDKey as String: $0,
                kIOHIDPrimaryUsagePageKey as String: usagePage,
                kIOHIDPrimaryUsageKey as String: usage,
            ]
        }
    }
}

final class HIDPPController {
    struct DPICapabilities: Sendable {
        let values: [Int]
        let cameFromDevice: Bool
        var minimum: Int { values.first ?? 400 }
        var maximum: Int { values.last ?? 4000 }
    }

    private static let longReportID: UInt8 = 0x11
    private let softwareID: UInt8

    var onConnectionChanged: ((Bool) -> Void)?
    var onDPICapabilities: ((DPICapabilities) -> Void)?

    private let profiles: [MouseDeviceProfile]
    private let restoreOnStop: Bool
    private let requestQueue = DispatchQueue(label: "mousebridge.hidpp.requests")
    private let stateLock = NSLock()
    private let requestLock = NSLock()
    private let pendingLock = NSLock()
    private let stopped = DispatchSemaphore(value: 0)

    // Device lifecycle state is created and destroyed on the HID run-loop
    // thread. Other threads may only take retained snapshots under stateLock.
    private var runLoopThread: Thread?
    private var hidRunLoop: CFRunLoop?
    private var manager: IOHIDManager?
    private var device: IOHIDDevice?
    private var connectionGeneration: UInt64 = 0
    private var activeProfile: MouseDeviceProfile?
    private var outputElement: IOHIDElement?
    private var inputBuffer: UnsafeMutablePointer<UInt8>?
    private var dpiFeature: UInt8?
    private var supportedDPIs: [Int] = []
    private var originalDPI: Int?
    private var running = false
    private var stopping = false
    private var pending: PendingRequest?

    private final class PendingRequest {
        let feature: UInt8
        let function: UInt8
        let semaphore = DispatchSemaphore(value: 0)
        var response: Message?

        init(feature: UInt8, function: UInt8) {
            self.feature = feature
            self.function = function
        }
    }

    struct Message: Sendable {
        let deviceIndex: UInt8
        let feature: UInt8
        let function: UInt8
        let softwareID: UInt8
        let parameters: [UInt8]
    }

    init(profiles: [MouseDeviceProfile] = MouseDeviceProfile.supported, restoreOnStop: Bool = true, softwareID: UInt8 = 0x0A) {
        self.profiles = profiles
        self.restoreOnStop = restoreOnStop
        precondition((1...15).contains(softwareID))
        self.softwareID = softwareID
    }

    var connectedDeviceName: String? {
        stateLock.lock()
        defer { stateLock.unlock() }
        return activeProfile?.name
    }

    func start() {
        stateLock.lock()
        guard !running else {
            stateLock.unlock()
            return
        }
        running = true
        stopping = false
        stateLock.unlock()

        let thread = Thread { [weak self] in self?.runHIDLoop() }
        thread.name = "MouseBridge-HIDRunLoop"
        runLoopThread = thread
        thread.start()
    }

    /// Restores the DPI observed at connection time, then shuts down the HID
    /// run loop. A force-quit cannot restore device state.
    func stop() {
        stateLock.lock()
        guard running, !stopping else {
            stateLock.unlock()
            return
        }
        stopping = true
        let feature = dpiFeature
        let dpi = originalDPI
        let runLoop = hidRunLoop
        let generation = connectionGeneration
        stateLock.unlock()

        // Drain in-flight writes before restoring. A write and its readback must
        // remain one ordered transaction, including during app termination.
        requestQueue.sync {
            if restoreOnStop, let feature, let dpi {
                let restored = sendDPI(feature: feature, value: dpi, generation: generation, allowWhileStopping: true)
                DiagnosticLog.shared.write("dpi restore value=\(dpi) success=\(restored)")
            }
        }

        guard let runLoop else {
            // The HID thread may still be starting. It observes stopping before
            // entering its loop and owns all cleanup, including manager closure.
            _ = stopped.wait(timeout: .now() + 3)
            return
        }
        CFRunLoopPerformBlock(runLoop, CFRunLoopMode.defaultMode.rawValue) { [weak self] in
            guard let self else { return }
            self.cleanupDeviceOnHIDThread()
            CFRunLoopStop(runLoop)
        }
        CFRunLoopWakeUp(runLoop)
        _ = stopped.wait(timeout: .now() + 3)
    }

    func setDPI(_ value: Int, completion: ((Int?) -> Void)? = nil) {
        requestQueue.async { [weak self] in
            guard let self else {
                completion?(nil)
                return
            }
            self.stateLock.lock()
            let feature = self.dpiFeature
            let supported = self.supportedDPIs
            let stopping = self.stopping
            let generation = self.connectionGeneration
            self.stateLock.unlock()
            guard let feature, !stopping else {
                completion?(nil)
                return
            }
            let requested = AppConfig.clampDPI(value)
            let dpi = supported.min(by: { abs($0 - requested) < abs($1 - requested) }) ?? requested
            let success = self.sendDPI(feature: feature, value: dpi, generation: generation)
            completion?(success ? dpi : nil)
        }
    }

    func readDPI(completion: @escaping (Int?) -> Void) {
        requestQueue.async { [weak self] in
            guard let self else {
                completion(nil)
                return
            }
            self.stateLock.lock()
            let feature = self.dpiFeature
            let generation = self.connectionGeneration
            self.stateLock.unlock()
            completion(feature.flatMap { self.readDPIValue(feature: $0, generation: generation) })
        }
    }

    private func runHIDLoop() {
        autoreleasepool {
            guard let runLoop = CFRunLoopGetCurrent() else {
                DiagnosticLog.shared.write("hid run loop creation FAILED")
                stateLock.lock()
                running = false
                stopping = false
                stateLock.unlock()
                stopped.signal()
                return
            }
            let manager = IOHIDManagerCreate(kCFAllocatorDefault, IOOptionBits(kIOHIDOptionsTypeNone))
            stateLock.lock()
            hidRunLoop = runLoop
            self.manager = manager
            stateLock.unlock()

            let context = Unmanaged.passUnretained(self).toOpaque()
            IOHIDManagerSetDeviceMatchingMultiple(manager, profiles.flatMap(\.matchingDictionaries) as CFArray)
            IOHIDManagerRegisterDeviceMatchingCallback(manager, deviceMatchedCallback, context)
            IOHIDManagerRegisterDeviceRemovalCallback(manager, deviceRemovedCallback, context)
            IOHIDManagerScheduleWithRunLoop(manager, runLoop, CFRunLoopMode.defaultMode.rawValue)
            let openResult = IOHIDManagerOpen(manager, IOOptionBits(kIOHIDOptionsTypeNone))
            DiagnosticLog.shared.write("hid manager open result=\(openResult) profiles=\(profiles.map(\.name).joined(separator: ", "))")

            if openResult == kIOReturnSuccess {
                // A sleeping BLE mouse may time out during the first handshake.
                // Revisit matching devices instead of requiring an app restart.
                while true {
                    stateLock.lock()
                    let shouldStop = stopping
                    let needsDevice = device == nil
                    stateLock.unlock()
                    if shouldStop { break }
                    if needsDevice,
                       let candidates = IOHIDManagerCopyDevices(manager) as? Set<IOHIDDevice> {
                        for candidate in candidates { matched(candidate) }
                    }
                    CFRunLoopRunInMode(.defaultMode, 2, false)
                }
            }

            cleanupDeviceOnHIDThread()
            IOHIDManagerUnscheduleFromRunLoop(manager, runLoop, CFRunLoopMode.defaultMode.rawValue)
            IOHIDManagerClose(manager, IOOptionBits(kIOHIDOptionsTypeNone))
            stateLock.lock()
            self.manager = nil
            hidRunLoop = nil
            running = false
            stopping = false
            stateLock.unlock()
            stopped.signal()
        }
    }

    fileprivate func matched(_ candidate: IOHIDDevice) {
        stateLock.lock()
        let canAttach = running && !stopping && device == nil
        stateLock.unlock()
        guard canAttach else { return }
        let productID = (IOHIDDeviceGetProperty(candidate, kIOHIDProductIDKey as CFString) as? NSNumber)?.intValue
        guard let profile = profiles.first(where: { $0.productIDs.contains(productID ?? -1) }) else { return }
        guard IOHIDDeviceOpen(candidate, IOOptionBits(kIOHIDOptionsTypeNone)) == kIOReturnSuccess else {
            DiagnosticLog.shared.write("hid device open FAILED")
            return
        }

        let elements = (IOHIDDeviceCopyMatchingElements(candidate, nil, IOOptionBits(kIOHIDOptionsTypeNone)) as? [IOHIDElement]) ?? []
        let output = elements.first {
            IOHIDElementGetType($0) == kIOHIDElementTypeOutput &&
            IOHIDElementGetReportID($0) == UInt32(Self.longReportID) &&
            IOHIDElementGetUsagePage($0) >= 0xFF00 &&
            IOHIDElementGetReportSize($0) == 8 && IOHIDElementGetReportCount($0) == 19
        }
        if profile.usesOutputElement && output == nil {
            DiagnosticLog.shared.write("hid output element unavailable device=\(profile.name)")
            IOHIDDeviceClose(candidate, IOOptionBits(kIOHIDOptionsTypeNone))
            return
        }
        DiagnosticLog.shared.write("hid device matched name=\(profile.name) productID=\(productID ?? 0) transport=\(profile.usesOutputElement ? "set-value" : "set-report")")
        let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: 64)
        buffer.initialize(repeating: 0, count: 64)
        stateLock.lock()
        device = candidate
        connectionGeneration &+= 1
        let generation = connectionGeneration
        activeProfile = profile
        outputElement = profile.usesOutputElement ? output : nil
        inputBuffer = buffer
        stateLock.unlock()

        let context = Unmanaged.passUnretained(self).toOpaque()
        IOHIDDeviceRegisterInputReportCallback(candidate, buffer, 64, inputReportCallback, context)
        IOHIDDeviceScheduleWithRunLoop(candidate, CFRunLoopGetCurrent(), CFRunLoopMode.defaultMode.rawValue)
        requestQueue.async { [weak self, candidate] in self?.configureConnectedDevice(candidate, generation: generation) }
    }

    fileprivate func removed(_ removed: IOHIDDevice) {
        stateLock.lock()
        let isCurrent = device === removed
        stateLock.unlock()
        guard isCurrent else { return }
        cleanupDeviceOnHIDThread()
        notifyConnection(false)
    }

    private func configureConnectedDevice(_ expectedDevice: IOHIDDevice, generation: UInt64) {
        guard let dpi = findFeature(0x2201, generation: generation) else {
            scheduleCleanup(expectedDevice, generation: generation)
            return
        }
        stateLock.lock()
        let profile = activeProfile
        stateLock.unlock()
        let deviceDPIs = readSupportedDPIs(feature: dpi, generation: generation)
        let currentDPI = readDPIValue(feature: dpi, generation: generation)
        if profile?.usesOutputElement == true && (deviceDPIs.isEmpty || currentDPI == nil) {
            DiagnosticLog.shared.write("hid DPI discovery incomplete; leaving device unchanged")
            scheduleCleanup(expectedDevice, generation: generation)
            return
        }
        let capabilities = DPICapabilities(
            values: deviceDPIs.isEmpty ? (profile?.fallbackDPIs ?? []) : deviceDPIs,
            cameFromDevice: !deviceDPIs.isEmpty
        )

        stateLock.lock()
        guard device === expectedDevice, connectionGeneration == generation, !stopping else {
            stateLock.unlock()
            return
        }
        dpiFeature = dpi
        supportedDPIs = capabilities.values
        originalDPI = currentDPI
        stateLock.unlock()

        DiagnosticLog.shared.write(
            "dpi capabilities min=\(capabilities.minimum) max=\(capabilities.maximum) " +
            "count=\(capabilities.values.count) deviceReported=\(capabilities.cameFromDevice) original=\(currentDPI.map(String.init) ?? "unknown")"
        )
        DispatchQueue.main.async { [weak self] in
            guard let self, self.isCurrentGeneration(generation) else { return }
            self.onDPICapabilities?(capabilities)
            self.onConnectionChanged?(true)
        }
    }

    private func scheduleCleanup(_ expectedDevice: IOHIDDevice, generation: UInt64) {
        stateLock.lock()
        let runLoop = hidRunLoop
        stateLock.unlock()
        guard let runLoop else { return }
        CFRunLoopPerformBlock(runLoop, CFRunLoopMode.defaultMode.rawValue) { [weak self, expectedDevice] in
            guard let self else { return }
            self.stateLock.lock()
            let isCurrent = self.device === expectedDevice && self.connectionGeneration == generation
            self.stateLock.unlock()
            guard isCurrent else { return }
            self.cleanupDeviceOnHIDThread()
            self.notifyConnection(false)
        }
        CFRunLoopWakeUp(runLoop)
    }

    private func cleanupDeviceOnHIDThread() {
        cancelPendingRequest()
        requestLock.lock()
        defer { requestLock.unlock() }

        stateLock.lock()
        let device = self.device
        let buffer = inputBuffer
        self.device = nil
        connectionGeneration &+= 1
        activeProfile = nil
        outputElement = nil
        inputBuffer = nil
        dpiFeature = nil
        supportedDPIs = []
        originalDPI = nil
        stateLock.unlock()

        if let device {
            IOHIDDeviceUnscheduleFromRunLoop(device, CFRunLoopGetCurrent(), CFRunLoopMode.defaultMode.rawValue)
            IOHIDDeviceClose(device, IOOptionBits(kIOHIDOptionsTypeNone))
        }
        buffer?.deinitialize(count: 64)
        buffer?.deallocate()
    }

    private func sendDPI(feature: UInt8, value: Int, generation: UInt64, allowWhileStopping: Bool = false) -> Bool {
        guard (100...10000).contains(value) else { return false }
        let dpi = value
        guard request(
            feature: feature,
            function: 3,
            parameters: [0, UInt8((dpi >> 8) & 0xFF), UInt8(dpi & 0xFF)],
            generation: generation,
            allowWhileStopping: allowWhileStopping
        ) != nil else { return false }
        let actual = readDPIValue(feature: feature, generation: generation, allowWhileStopping: allowWhileStopping)
        DiagnosticLog.shared.write("dpi write requested=\(dpi) readback=\(actual.map(String.init) ?? "unknown") success=\(actual == dpi)")
        return actual == dpi
    }

    private func readDPIValue(feature: UInt8, generation: UInt64, allowWhileStopping: Bool = false) -> Int? {
        guard let response = request(feature: feature, function: 2, parameters: [0], generation: generation, allowWhileStopping: allowWhileStopping),
              response.parameters.first == 0,
              response.parameters.count >= 3 else { return nil }
        let current = (Int(response.parameters[1]) << 8) | Int(response.parameters[2])
        if current != 0 { return current }
        guard response.parameters.count >= 5 else { return nil }
        return (Int(response.parameters[3]) << 8) | Int(response.parameters[4])
    }

    private func readSupportedDPIs(feature: UInt8, generation: UInt64) -> [Int] {
        var bytes: [UInt8] = []
        for page in 0..<16 {
            guard let response = request(feature: feature, function: 1, parameters: [0, 0, UInt8(page)], generation: generation),
                  let entries = Self.dpiPageEntries(response.parameters) else { return [] }
            bytes.append(contentsOf: entries)
            if stride(from: 0, to: entries.count, by: 2).contains(where: { entries[$0] == 0 && entries[$0 + 1] == 0 }) {
                return Self.decodeDPIList(bytes)
            }
        }
        return [] // A partial/unterminated list is not a validated capability.
    }

    static func dpiPageEntries(_ parameters: [UInt8]) -> [UInt8]? {
        guard parameters.first == 0, parameters.count >= 3 else { return nil }
        let payload = Array(parameters.dropFirst())
        // Each page carries complete UInt16 entries, plus an odd padding byte.
        return Array(payload.prefix(payload.count - payload.count % 2))
    }

    static func decodeDPIList(_ bytes: [UInt8]) -> [Int] {
        var values: [Int] = []
        var index = 0
        while index + 1 < bytes.count {
            let value = (Int(bytes[index]) << 8) | Int(bytes[index + 1])
            if value == 0 { break }
            if value >> 13 == 0b111 {
                let step = value & 0x1FFF
                guard step > 0, let previous = values.last, index + 3 < bytes.count else { return [] }
                let maximum = (Int(bytes[index + 2]) << 8) | Int(bytes[index + 3])
                guard maximum > previous, maximum <= 10000 else { return [] }
                values.append(contentsOf: stride(from: previous + step, through: maximum, by: step))
                index += 4
            } else {
                guard (100...10000).contains(value) else { return [] }
                values.append(value)
                index += 2
            }
        }
        return Array(Set(values.filter { (100...10000).contains($0) })).sorted()
    }

    private func findFeature(_ identifier: UInt16, generation: UInt64) -> UInt8? {
        let response = request(
            feature: 0,
            function: 0,
            parameters: [UInt8(identifier >> 8), UInt8(identifier & 0xFF), 0],
            generation: generation
        )
        return response?.parameters.first.flatMap { $0 == 0 ? nil : $0 }
    }

    private func request(
        feature: UInt8,
        function: UInt8,
        parameters: [UInt8],
        generation: UInt64,
        allowWhileStopping: Bool = false
    ) -> Message? {
        requestLock.lock()
        defer { requestLock.unlock() }

        stateLock.lock()
        let device = self.device
        let outputElement = self.outputElement
        let canRequest = device != nil && connectionGeneration == generation && (!stopping || allowWhileStopping)
        stateLock.unlock()
        guard canRequest, let device else { return nil }

        let pending = PendingRequest(feature: feature, function: function)
        pendingLock.lock()
        self.pending = pending
        pendingLock.unlock()

        let bytes = Self.outputReport(feature: feature, function: function,
                                      parameters: parameters, softwareID: softwareID)
        let result: IOReturn
        if let outputElement {
            let payload = Array(bytes.dropFirst())
            let value = payload.withUnsafeBufferPointer {
                IOHIDValueCreateWithBytes(kCFAllocatorDefault, outputElement, mach_absolute_time(), $0.baseAddress!, $0.count)
            }
            result = value.map { IOHIDDeviceSetValue(device, outputElement, $0) } ?? kIOReturnError
        } else {
            result = bytes.withUnsafeBytes { pointer in
                IOHIDDeviceSetReport(
                    device,
                    kIOHIDReportTypeOutput,
                    CFIndex(Self.longReportID),
                    pointer.bindMemory(to: UInt8.self).baseAddress!,
                    bytes.count
                )
            }
        }
        guard result == kIOReturnSuccess else {
            clearPending(pending)
            DiagnosticLog.shared.write("hid request send FAILED result=\(result) feature=\(feature) function=\(function)")
            return nil
        }
        guard pending.semaphore.wait(timeout: .now() + 2) == .success else {
            clearPending(pending)
            DiagnosticLog.shared.write("hid request timeout feature=\(feature) function=\(function)")
            return nil
        }
        clearPending(pending)
        return pending.response
    }

    static func outputReport(feature: UInt8, function: UInt8, parameters: [UInt8], softwareID: UInt8) -> [UInt8] {
        var bytes = [UInt8](repeating: 0, count: 20)
        bytes[0] = longReportID
        bytes[1] = 0xFF
        bytes[2] = feature
        bytes[3] = ((function & 0x0F) << 4) | (softwareID & 0x0F)
        for (index, value) in parameters.prefix(16).enumerated() { bytes[index + 4] = value }
        return bytes
    }

    private func clearPending(_ request: PendingRequest) {
        pendingLock.lock()
        if pending === request { pending = nil }
        pendingLock.unlock()
    }

    private func cancelPendingRequest() {
        pendingLock.lock()
        let request = pending
        pending = nil
        pendingLock.unlock()
        request?.semaphore.signal()
    }

    fileprivate func received(reportID: UInt32, bytes: UnsafeMutablePointer<UInt8>, count: Int) {
        guard count > 0 else { return }
        guard reportID == 0x10 || reportID == 0x11 else { return }
        var data = Array(UnsafeBufferPointer(start: bytes, count: count))
        if data.first != 0x10 && data.first != 0x11 { data.insert(UInt8(reportID & 0xFF), at: 0) }
        guard let message = Self.parse(data), [UInt8(0), 0xFF].contains(message.deviceIndex) else { return }
        stateLock.lock()
        let legacyFunctionReply = activeProfile?.usesOutputElement == false
        stateLock.unlock()

        pendingLock.lock()
        let active = pending
        guard let active else { pendingLock.unlock(); return }
        switch Self.classifyResponse(message, feature: active.feature, function: active.function,
                                     softwareID: softwareID, legacyFunctionReply: legacyFunctionReply) {
        case .success:
            active.response = message
        case .deviceError(let code):
            DiagnosticLog.shared.write("hid device error feature=\(active.feature) function=\(active.function) code=\(code)")
        case .unrelated:
            pendingLock.unlock()
            return
        }
        pending = nil
        active.semaphore.signal()
        pendingLock.unlock()
    }

    enum ResponseMatch: Equatable {
        case success
        case deviceError(UInt8)
        case unrelated
    }

    static func classifyResponse(_ message: Message, feature: UInt8, function: UInt8,
                                 softwareID: UInt8, legacyFunctionReply: Bool) -> ResponseMatch {
        guard [UInt8(0), 0xFF].contains(message.deviceIndex) else { return .unrelated }
        if message.feature == 0xFF,
           ((message.function << 4) | message.softwareID) == feature,
           message.parameters.count >= 2,
           message.parameters[0] == ((function << 4) | softwareID) {
            return .deviceError(message.parameters[1])
        }
        guard message.feature == feature, message.softwareID == softwareID,
              message.function == function || (legacyFunctionReply && message.function == ((function + 1) & 0x0F)) else {
            return .unrelated
        }
        return .success
    }

    static func parse(_ data: [UInt8]) -> Message? {
        guard data.count >= 4 else { return nil }
        guard data[0] == 0x10 || data[0] == 0x11 else { return nil }
        let offset = 1
        let functionAndSoftware = data[offset + 2]
        return Message(
            deviceIndex: data[offset],
            feature: data[offset + 1],
            function: (functionAndSoftware >> 4) & 0x0F,
            softwareID: functionAndSoftware & 0x0F,
            parameters: Array(data.dropFirst(offset + 3))
        )
    }

    private func isCurrentGeneration(_ generation: UInt64) -> Bool {
        stateLock.lock()
        defer { stateLock.unlock() }
        return connectionGeneration == generation && !stopping
    }

    private func notifyConnection(_ connected: Bool) {
        stateLock.lock()
        let generation = connectionGeneration
        stateLock.unlock()
        DispatchQueue.main.async { [weak self] in
            guard let self, self.isCurrentGeneration(generation) else { return }
            self.onConnectionChanged?(connected)
        }
    }
}

private let deviceMatchedCallback: IOHIDDeviceCallback = { context, _, _, device in
    guard let context else { return }
    Unmanaged<HIDPPController>.fromOpaque(context).takeUnretainedValue().matched(device)
}

private let deviceRemovedCallback: IOHIDDeviceCallback = { context, _, _, device in
    guard let context else { return }
    Unmanaged<HIDPPController>.fromOpaque(context).takeUnretainedValue().removed(device)
}

private let inputReportCallback: IOHIDReportCallback = { context, result, _, _, reportID, report, reportLength in
    guard result == kIOReturnSuccess, let context, reportLength > 0 else { return }
    Unmanaged<HIDPPController>.fromOpaque(context).takeUnretainedValue().received(
        reportID: reportID,
        bytes: report,
        count: reportLength
    )
}
