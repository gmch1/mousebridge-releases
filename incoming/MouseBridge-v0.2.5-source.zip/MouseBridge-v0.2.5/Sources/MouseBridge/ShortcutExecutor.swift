// SPDX-License-Identifier: GPL-3.0-or-later

import ApplicationServices
import Foundation

enum ShortcutExecutor {
    static let injectedMarker: Int64 = 0x4C4F4749

    private enum Action {
        case disabled
        case key(CGKeyCode)
        case click(CGMouseButton)
    }

    private static func parse(_ specification: String) -> (action: Action, flags: CGEventFlags)? {
        let value = specification.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if value.isEmpty || value == "none" { return (.disabled, []) }
        let parts = value.split(separator: "+", omittingEmptySubsequences: false).map {
            $0.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        guard let name = parts.last else { return nil }
        let action: Action
        switch name {
        case "left click": action = .click(.left)
        case "right click": action = .click(.right)
        case "middle click": action = .click(.center)
        default:
            guard let keyCode = keyCodes[name] else { return nil }
            action = .key(keyCode)
        }

        var flags: CGEventFlags = []
        for modifier in parts.dropLast() {
            switch modifier {
            case "cmd", "command": flags.insert(.maskCommand)
            case "shift": flags.insert(.maskShift)
            case "opt", "option", "alt": flags.insert(.maskAlternate)
            case "ctrl", "control": flags.insert(.maskControl)
            default: return nil
            }
        }
        return (action, flags)
    }

    // Construct without posting so event types, coordinates and modifiers can
    // be tested without injecting input into the user's desktop.
    static func makeEvents(_ specification: String, at location: CGPoint? = nil) -> [CGEvent]? {
        guard let parsed = parse(specification) else { return nil }
        let down: CGEvent?
        let up: CGEvent?
        switch parsed.action {
        case .disabled: return []
        case .key(let keyCode):
            down = CGEvent(keyboardEventSource: nil, virtualKey: keyCode, keyDown: true)
            up = CGEvent(keyboardEventSource: nil, virtualKey: keyCode, keyDown: false)
        case .click(let button):
            guard let point = location ?? CGEvent(source: nil)?.location else { return nil }
            let downType: CGEventType
            let upType: CGEventType
            switch button {
            case .left: (downType, upType) = (.leftMouseDown, .leftMouseUp)
            case .right: (downType, upType) = (.rightMouseDown, .rightMouseUp)
            default: (downType, upType) = (.otherMouseDown, .otherMouseUp)
            }
            down = CGEvent(mouseEventSource: nil, mouseType: downType, mouseCursorPosition: point, mouseButton: button)
            up = CGEvent(mouseEventSource: nil, mouseType: upType, mouseCursorPosition: point, mouseButton: button)
            down?.setIntegerValueField(.mouseEventClickState, value: 1)
            up?.setIntegerValueField(.mouseEventClickState, value: 1)
        }
        guard let down, let up else { return nil }
        for event in [down, up] {
            event.flags = parsed.flags
            event.setIntegerValueField(.eventSourceUserData, value: injectedMarker)
        }
        return [down, up]
    }

    static func execute(_ specification: String, at location: CGPoint? = nil) {
        guard let events = makeEvents(specification, at: location) else {
            DiagnosticLog.shared.writeEvent("shortcut invalid or event creation FAILED specification=\(specification)")
            return
        }
        for event in events { event.post(tap: .cghidEventTap) }
        DiagnosticLog.shared.writeEvent("shortcut specification=\(specification) postedEvents=\(events.count)")
    }

    static func isValid(_ specification: String) -> Bool {
        parse(specification) != nil
    }

    private static let keyCodes: [String: CGKeyCode] = [
        "a": 0, "s": 1, "d": 2, "f": 3, "h": 4, "g": 5, "z": 6, "x": 7,
        "c": 8, "v": 9, "b": 11, "q": 12, "w": 13, "e": 14, "r": 15,
        "y": 16, "t": 17, "1": 18, "2": 19, "3": 20, "4": 21, "6": 22,
        "5": 23, "=": 24, "9": 25, "7": 26, "-": 27, "8": 28, "0": 29,
        "]": 30, "o": 31, "u": 32, "[": 33, "i": 34, "p": 35, "enter": 36,
        "l": 37, "j": 38, "'": 39, "k": 40, ";": 41, "\\": 42, ",": 43,
        "/": 44, "n": 45, "m": 46, ".": 47, "tab": 48, "space": 49,
        "delete": 51, "escape": 53, "left": 123, "right": 124, "down": 125,
        "up": 126,
    ]
}
