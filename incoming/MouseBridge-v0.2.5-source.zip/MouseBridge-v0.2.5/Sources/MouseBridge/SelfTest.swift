// SPDX-License-Identifier: GPL-3.0-or-later

import Foundation

enum SelfTest {
    static func run() -> Bool {
        var normalized = AppConfig()
        normalized.scrollLines = 99
        normalized.trackpadFingerCount = 9
        normalized.normalize()
        let dpiList = HIDPPController.decodeDPIList([0x01, 0x90, 0xE0, 0x64, 0x0F, 0xA0, 0, 0])
        let mxDPIList = HIDPPController.decodeDPIList([0x00, 0xC8, 0xE0, 0x32, 0x1F, 0x40, 0, 0])
        let checks: [(String, Bool)] = [
            ("DPI lower bound", AppConfig.clampDPI(0) == 100),
            ("DPI unchanged", AppConfig.clampDPI(1200) == 1200),
            ("DPI upper bound", AppConfig.clampDPI(9000) == 8000),
            ("DPI range decoding", dpiList.first == 400 && dpiList.last == 4000 && dpiList.count == 37),
            ("MX Master 3S DPI range decoding", mxDPIList.first == 200 && mxDPIList.last == 8000 && mxDPIList.count == 157),
            ("scroll lines upper bound", normalized.scrollLines == 20),
            ("trackpad finger upper bound", normalized.trackpadFingerCount == 5),
            ("shortcut cmd+r", ShortcutExecutor.isValid("cmd+r")),
            ("shortcut modifiers", ShortcutExecutor.isValid("shift+cmd+z")),
            ("command click", ShortcutExecutor.isValid("cmd+left click")),
            ("command click whitespace", ShortcutExecutor.isValid(" CMD + LEFT CLICK ")),
            ("invalid click", !ShortcutExecutor.isValid("cmd+not-a-click")),
            ("empty modifier", !ShortcutExecutor.isValid("cmd++left click")),
            ("disabled action", ShortcutExecutor.isValid("none")),
            ("invalid shortcut", !ShortcutExecutor.isValid("cmd+not-a-key")),
        ]
        for (name, passed) in checks {
            print("\(passed ? "PASS" : "FAIL") \(name)")
        }
        return checks.allSatisfy(\.1)
    }
}
