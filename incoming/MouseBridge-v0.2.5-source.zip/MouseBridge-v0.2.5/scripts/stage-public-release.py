#!/usr/bin/env python3
"""Create an explicit publication payload without copying the working directory."""
import hashlib
import json
import pathlib
import plistlib
import re
import runpy
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]


def stage(version, signed):
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
        raise ValueError("Expected MAJOR.MINOR.PATCH")
    info = plistlib.loads((ROOT / "dist/MouseBridge.app/Contents/Info.plist").read_bytes())
    if info["CFBundleShortVersionString"] != version:
        raise ValueError("App version mismatch")
    major, minor, patch = map(int, version.split("."))
    if minor > 999 or patch > 999 or str(major * 1_000_000 + minor * 1000 + patch) != info["CFBundleVersion"]:
        raise ValueError("App build number must derive from the release version")
    directory = ROOT / "dist/public-release"
    directory.mkdir(exist_ok=False)
    binary = f"MouseBridge-v{version}-macOS.zip"
    source = f"MouseBridge-v{version}-source.zip"
    shutil.copy2(ROOT / "dist" / binary, directory / binary)
    shutil.copy2(ROOT / "dist/appcast.xml", directory / "appcast.xml")
    # Export a clean snapshot of build inputs, never Git history or untracked files.
    paths = ["Sources", "Tests", "LICENSES", "scripts", "docs", "Package.swift", "Info.plist",
             "build-app.sh", "LICENSE", "COPYRIGHT", "SOURCE.md", "THIRD_PARTY_NOTICES.md",
             "README.md", "README.zh-CN.md", "CHANGELOG.md"]
    subprocess.run(["git", "archive", "--format=zip", f"--prefix=MouseBridge-v{version}/",
                    "-o", str(directory / source), "HEAD", *paths], cwd=ROOT, check=True)
    for name in (binary, source):
        digest = hashlib.sha256((directory / name).read_bytes()).hexdigest()
        (directory / (name + ".sha256")).write_text(f"{digest}  {name}\n")
    changelog = (ROOT / "CHANGELOG.md").read_text()
    section = re.search(rf"^## {re.escape(version)} [^\n]*\n(.*?)(?=^## |\Z)", changelog, re.M | re.S)
    if not section:
        raise ValueError("Missing release notes")
    notes = f"MouseBridge v{version}\n\n" + section.group(1).strip() + "\n\n"
    notes += ("Developer ID signed and notarized by Apple.\n" if signed else
              "预发布版本：使用 ad-hoc 签名，未经过 Apple 公证。首次安装可能需要在 macOS 中手动允许打开。\n")
    notes += ("\n安装包与更新清单使用独立 Ed25519 签名。首次安装本版后，可在菜单栏选择“检查更新…”。\n"
              "\nGPL-3.0-or-later：完整对应源码见 `MouseBridge-v" + version + "-source.zip`，"
              "请勿使用 GitHub 自动生成的下载仓库源码归档。各 ZIP 附带 SHA-256 校验文件。\n")
    (directory / "notes.md").write_text(notes)
    (directory / "release.json").write_text(json.dumps({"version": version, "tag": "v" + version,
        "build": info["CFBundleVersion"], "prerelease": not signed}, indent=2) + "\n")
    runpy.run_path(str(ROOT / "scripts/audit-release.py"))["audit"](directory)
    print("Public payload staged and audited:", ", ".join(sorted(p.name for p in directory.iterdir())))


if __name__ == "__main__":
    stage(sys.argv[1], sys.argv[2] == "true")
