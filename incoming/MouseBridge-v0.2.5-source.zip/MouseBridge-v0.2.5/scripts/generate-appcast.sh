#!/bin/zsh
set -euo pipefail

ROOT=${0:A:h:h}
archive=${1:?Usage: generate-appcast.sh archive.zip https://download-prefix/}
download_prefix=${2:?Missing HTTPS download prefix}
[[ "$download_prefix" == https://* ]] || { print -u2 'Download prefix must use HTTPS'; exit 1; }
[[ -n ${SPARKLE_PRIVATE_KEY:-} ]] || { print -u2 'SPARKLE_PRIVATE_KEY is not configured'; exit 1; }

generators=("$ROOT"/.build/artifacts/**/bin/generate_appcast(N))
verifiers=("$ROOT"/.build/artifacts/**/bin/sign_update(N))
if (( ${#generators} != 1 || ${#verifiers} != 1 )); then
    print -u2 'Expected Sparkle tools in SwiftPM artifacts; build the app first'
    exit 1
fi

staging=$(mktemp -d)
trap 'rm -rf "$staging"' EXIT
mkdir "$staging/archives"
cp "$archive" "$staging/archives/"
# The seed never appears in arguments, logs or release assets.
print -rn -- "$SPARKLE_PRIVATE_KEY" | "$generators[1]" \
    --ed-key-file - --maximum-deltas 0 \
    --download-url-prefix "$download_prefix" \
    -o "$staging/appcast.xml" "$staging/archives"
print -rn -- "$SPARKLE_PRIVATE_KEY" | "$verifiers[1]" \
    --verify --ed-key-file - "$staging/appcast.xml"

# Missing/mismatched signing keys can leave an item unsigned. Verify the
# generated enclosure as well as the feed before making it publishable.
python3 "$ROOT/scripts/validate-appcast.py" "$staging/appcast.xml" "$archive" "$download_prefix"
signature=$(python3 - "$staging/appcast.xml" <<'PY'
import sys, xml.etree.ElementTree as ET
item = ET.parse(sys.argv[1]).find('./channel/item/enclosure')
print(item.attrib['{http://www.andymatuschak.org/xml-namespaces/sparkle}edSignature'])
PY
)
print -rn -- "$SPARKLE_PRIVATE_KEY" | "$verifiers[1]" \
    --verify --ed-key-file - "$archive" "$signature"
cp "$staging/appcast.xml" "${archive:A:h}/appcast.xml"
print "${archive:A:h}/appcast.xml"
