#!/usr/bin/env python3
"""Check only the allowlisted public payload; never print matched secrets."""
import pathlib
import os
import re
import sys
import zipfile

PATTERNS = {
    "private key": re.compile(b"-----BEGIN " + rb"(?:[A-Z0-9]+ )*PRIVATE KEY-----"),
    "GitHub token": re.compile(rb"(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,})"),
    "cloud access key": re.compile(rb"(?:AKIA|ASIA)[A-Z0-9]{16}"),
    "credential in URL": re.compile(rb"https?://[^\s/:'\"<>]+:[^\s/'\"<>]+@"),
    "local personal path": re.compile(rb"/(?:home/ming|Users/(?!runner(?:/|\b))[^/\s]+)/"),
}
FORBIDDEN_PARTS = {".git", ".ssh", ".env", ".DS_Store", "config.json", "settings.json", "hosts.yml"}
FORBIDDEN_SUFFIXES = {".p12", ".p8", ".key", ".pem", ".log"}


def inspect(name, data):
    path = pathlib.PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or FORBIDDEN_PARTS.intersection(path.parts):
        raise ValueError(f"Disallowed archive path: {name}")
    if path.suffix.lower() in FORBIDDEN_SUFFIXES or any(part.startswith(".env.") for part in path.parts):
        raise ValueError(f"Disallowed file type: {name}")
    for label, pattern in PATTERNS.items():
        if pattern.search(data):
            raise ValueError(f"Possible {label} in {name}; matched value withheld")
    for key in ["SPARKLE_PRIVATE_KEY", "RELEASES_DEPLOY_KEY", "GH_TOKEN", "GITHUB_TOKEN",
                "APPLE_CERTIFICATE_P12", "APPLE_API_KEY_P8"]:
        value = os.environ.get(key, "").strip().encode()
        if len(value) >= 16 and value in data:
            raise ValueError(f"Credential value found in {name}; matched value withheld")


def audit(directory):
    directory = pathlib.Path(directory)
    for path in directory.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"Unexpected symlink: {path.name}")
        if not path.is_file():
            continue
        inspect(path.relative_to(directory).as_posix(), path.read_bytes())
        if path.suffix == ".zip":
            with zipfile.ZipFile(path) as archive:
                for entry in archive.infolist():
                    inspect(entry.filename, archive.read(entry))


if __name__ == "__main__":
    audit(sys.argv[1])
    print("Public payload scan passed: no flagged credentials, personal paths or local configuration files")
