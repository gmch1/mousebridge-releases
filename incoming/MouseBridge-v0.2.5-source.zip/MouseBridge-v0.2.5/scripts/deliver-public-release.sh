#!/bin/zsh
set -euo pipefail

ROOT=${0:A:h:h}
payload=${1:?Missing audited publication directory}
[[ -n ${RELEASES_DEPLOY_KEY:-} ]] || { print -u2 'RELEASES_DEPLOY_KEY is not configured'; exit 1; }
python3 "$ROOT/scripts/audit-release.py" "$payload"
tag=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["tag"])' "$payload/release.json")
[[ "$tag" =~ '^v[0-9]+\.[0-9]+\.[0-9]+$' ]] || { print -u2 'Invalid release tag'; exit 1; }

temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT
umask 077
print -r -- "$RELEASES_DEPLOY_KEY" > "$temporary/deploy-key"
# Obtain GitHub's host keys over its authenticated HTTPS API.
gh api meta --jq '.ssh_keys[] | "github.com " + .' > "$temporary/known_hosts"
export GIT_SSH_COMMAND="ssh -i \"$temporary/deploy-key\" -o IdentitiesOnly=yes -o UserKnownHostsFile=\"$temporary/known_hosts\" -o StrictHostKeyChecking=yes"
git clone --depth 1 --branch main https://github.com/gmch1/mousebridge-releases.git "$temporary/public"
git -C "$temporary/public" config user.name 'MouseBridge release automation'
git -C "$temporary/public" config user.email 'mousebridge@users.noreply.github.com'
git -C "$temporary/public" rm -r --ignore-unmatch incoming
mkdir -p "$temporary/public/incoming"
cp "$payload"/* "$temporary/public/incoming/"
python3 "$temporary/public/scripts/verify.py" "$temporary/public/incoming"
git -C "$temporary/public" add incoming
if git -C "$temporary/public" diff --cached --quiet; then
    print 'This publication payload is already delivered'
    exit 0
fi
git -C "$temporary/public" commit -m "Publish MouseBridge $tag"
git -C "$temporary/public" push git@github.com:gmch1/mousebridge-releases.git HEAD:main
