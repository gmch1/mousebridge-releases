#!/usr/bin/env python3
"""Validate the signed update metadata against the exact packaged app."""
import base64
import pathlib
import plistlib
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

SPARKLE = "{http://www.andymatuschak.org/xml-namespaces/sparkle}"


def validate(feed, archive, download_prefix):
    archive = pathlib.Path(archive)
    items = ET.parse(feed).findall("./channel/item")
    if len(items) != 1:
        raise ValueError("Expected exactly one update in the feed")
    item = items[0]
    enclosure = item.find("enclosure")
    if enclosure is None:
        raise ValueError("Missing update archive")
    expected_url = download_prefix.rstrip("/") + "/" + urllib.parse.quote(archive.name)
    if enclosure.get("url") != expected_url or not expected_url.startswith("https://"):
        raise ValueError("Unexpected update download URL")
    if int(enclosure.get("length", "0")) != archive.stat().st_size:
        raise ValueError("Update archive size mismatch")
    signature = base64.b64decode(enclosure.get(SPARKLE + "edSignature", ""), validate=True)
    if len(signature) != 64:
        raise ValueError("Missing or invalid archive signature")
    with zipfile.ZipFile(archive) as package:
        info = plistlib.loads(package.read("MouseBridge.app/Contents/Info.plist"))
    for field, key in [("version", "CFBundleVersion"), ("shortVersionString", "CFBundleShortVersionString")]:
        value = item.findtext(SPARKLE + field) or enclosure.get(SPARKLE + field)
        if value != info[key]:
            raise ValueError(f"Update {field} does not match the packaged app")
    if item.findtext(SPARKLE + "minimumSystemVersion") != info["LSMinimumSystemVersion"]:
        raise ValueError("Update minimum OS does not match the packaged app")


if __name__ == "__main__":
    validate(*sys.argv[1:])
    print("Update archive URL, size, versions, OS requirement and signature metadata verified")
