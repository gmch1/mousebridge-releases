// SPDX-License-Identifier: GPL-3.0-or-later

import Foundation
import XCTest
@testable import MouseBridge

final class UpdateConfigurationTests: XCTestCase {
    func testUpdateConfigurationRequiresSignedFeedAndArchives() throws {
        let root = URL(fileURLWithPath: #filePath)
            .deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
        let data = try Data(contentsOf: root.appendingPathComponent("Info.plist"))
        let info = try XCTUnwrap(PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any])
        let feed = try XCTUnwrap(URL(string: try XCTUnwrap(info["SUFeedURL"] as? String)))
        XCTAssertEqual(feed.scheme, "https")
        XCTAssertEqual(feed.absoluteString,
                       "https://github.com/gmch1/mousebridge-releases/releases/download/appcast/appcast.xml")
        XCTAssertNil(feed.user)
        XCTAssertNil(feed.password)
        let key = try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(info["SUPublicEDKey"] as? String)))
        XCTAssertEqual(key.count, 32)
        XCTAssertEqual(info["SURequireSignedFeed"] as? Bool, true)
        XCTAssertEqual(info["SUVerifyUpdateBeforeExtraction"] as? Bool, true)
        XCTAssertEqual(info["SUEnableAutomaticChecks"] as? Bool, true)
        XCTAssertEqual(info["SUScheduledCheckInterval"] as? Int, 86400)
        // Discover updates automatically; installation still requires the user's choice.
        XCTAssertNotEqual(info["SUAutomaticallyUpdate"] as? Bool, true)
    }
}
