import base64
import pathlib
import plistlib
import runpy
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile

module = runpy.run_path(str(pathlib.Path(__file__).resolve().parents[1] / "scripts/validate-appcast.py"))
validate = module["validate"]
SPARKLE = module["SPARKLE"]


class AppcastTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        root = pathlib.Path(self.temporary.name)
        self.archive = root / "MouseBridge.zip"
        self.feed = root / "appcast.xml"
        self.prefix = "https://example.com/releases/v0.2.5/"
        info = {"CFBundleVersion": "2005", "CFBundleShortVersionString": "0.2.5", "LSMinimumSystemVersion": "13.0"}
        with zipfile.ZipFile(self.archive, "w") as package:
            package.writestr("MouseBridge.app/Contents/Info.plist", plistlib.dumps(info))
        self.rss = ET.Element("rss")
        self.item = ET.SubElement(ET.SubElement(self.rss, "channel"), "item")
        ET.SubElement(self.item, SPARKLE + "version").text = "2005"
        ET.SubElement(self.item, SPARKLE + "shortVersionString").text = "0.2.5"
        ET.SubElement(self.item, SPARKLE + "minimumSystemVersion").text = "13.0"
        self.enclosure = ET.SubElement(self.item, "enclosure", {
            "url": self.prefix + self.archive.name,
            "length": str(self.archive.stat().st_size),
            SPARKLE + "edSignature": base64.b64encode(bytes(64)).decode(),
        })

    def check(self):
        ET.ElementTree(self.rss).write(self.feed)
        validate(self.feed, self.archive, self.prefix)

    def test_matching_metadata(self):
        self.check()

    def test_missing_signature_is_rejected(self):
        del self.enclosure.attrib[SPARKLE + "edSignature"]
        with self.assertRaisesRegex(ValueError, "signature"):
            self.check()

    def test_incorrect_download_is_rejected(self):
        self.enclosure.set("url", "https://example.com/another.zip")
        with self.assertRaisesRegex(ValueError, "URL"):
            self.check()

    def test_wrong_size_is_rejected(self):
        self.enclosure.set("length", "1")
        with self.assertRaisesRegex(ValueError, "size"):
            self.check()

    def test_wrong_build_version_is_rejected(self):
        self.item.find(SPARKLE + "version").text = "6"
        with self.assertRaisesRegex(ValueError, "version"):
            self.check()

    def test_wrong_os_requirement_is_rejected(self):
        self.item.find(SPARKLE + "minimumSystemVersion").text = "12.0"
        with self.assertRaisesRegex(ValueError, "minimum OS"):
            self.check()

    def test_empty_feed_is_rejected(self):
        self.rss.find("channel").remove(self.item)
        with self.assertRaisesRegex(ValueError, "exactly one"):
            self.check()


if __name__ == "__main__":
    unittest.main()
