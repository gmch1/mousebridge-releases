import pathlib
import runpy
import tempfile
import unittest
import zipfile

module = runpy.run_path(str(pathlib.Path(__file__).resolve().parents[1] / "scripts/audit-release.py"))
inspect = module["inspect"]
audit = module["audit"]


class ReleaseAuditTests(unittest.TestCase):
    def test_public_key_is_allowed(self):
        inspect("Info.plist", b"SUPublicEDKey: p5C1GSj0p2P2eVmKlMIc4yJrNOIjdf3+dqgrMowLfm0=")

    def test_private_key_is_blocked_without_printing_value(self):
        with self.assertRaisesRegex(ValueError, "matched value withheld"):
            inspect("unexpected.txt", b"-----BEGIN " + b"OPENSSH PRIVATE KEY-----")

    def test_token_is_blocked(self):
        with self.assertRaisesRegex(ValueError, "GitHub token"):
            inspect("notes.md", b"ghp_" + b"X" * 36)

    def test_personal_paths_are_blocked_but_ci_paths_are_allowed(self):
        with self.assertRaisesRegex(ValueError, "personal path"):
            inspect("binary", b"/Users/" + b"personal/Documents/private")
        inspect("binary", b"/Users/runner/work/MouseBridge")

    def test_local_config_and_traversal_are_blocked(self):
        for name in ["app/.git/config", "config.json", "a/.env.production", "key.p12", "../secret"]:
            with self.subTest(name=name), self.assertRaises(ValueError):
                inspect(name, b"")

    def test_zip_contents_are_scanned(self):
        with tempfile.TemporaryDirectory() as temporary:
            with zipfile.ZipFile(pathlib.Path(temporary) / "source.zip", "w") as archive:
                archive.writestr("source/config.json", "{}")
            with self.assertRaises(ValueError):
                audit(temporary)


if __name__ == "__main__":
    unittest.main()
