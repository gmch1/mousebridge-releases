# Releasing MouseBridge

English | [简体中文](RELEASING.zh-CN.md)

The release workflow is triggered by a semantic version tag. The tag must match
`CFBundleShortVersionString` in `Info.plist`.

## Signed updates and public distribution

Since 0.2.5, Sparkle checks the signed feed in the `appcast` Release of
`gmch1/mousebridge-releases`. Existing users must install this version manually
once. The menu offers manual checks and a daily automatic-check toggle;
installation remains a user choice.

The private source repository keeps `SPARKLE_PRIVATE_KEY` (the base64 Ed25519
seed matching `SUPublicEDKey`) and `RELEASES_DEPLOY_KEY` (a write deploy key scoped
only to the public download repository) as Actions secrets. Neither key is
packaged or published. No personal GitHub token is stored in the app or workflow.

The release workflow signs the archive and feed, creates an allowlisted source
snapshot, and scans both ZIPs for credentials, personal paths and local config
files before delivering the seven publication files to the public repository.
That repository verifies both Ed25519 signatures using only the pinned public
key, publishes the versioned assets, then advances the rolling feed. It rejects
changed assets for an existing version and never rolls the feed back.

Set `CFBundleVersion` to `major * 1000000 + minor * 1000 + patch`, with minor and
patch at most 999. For example, `0.2.5` uses `2005`. Workflow reruns keep this value.

## Preview release

Without Apple signing secrets, the workflow builds an ad-hoc signed archive and
publishes it as a GitHub pre-release:

```bash
git tag -a v0.2.1 -m "MouseBridge v0.2.1"
git push origin v0.2.1
```

## Signed and notarized release

Configure these GitHub Actions repository secrets before pushing the tag:

- `APPLE_CERTIFICATE_P12`: base64-encoded Developer ID Application `.p12`
- `APPLE_CERTIFICATE_PASSWORD`: password for the `.p12`
- `KEYCHAIN_PASSWORD`: optional temporary CI keychain password
- `APPLE_API_KEY_P8`: base64-encoded App Store Connect API private key
- `APPLE_API_KEY_ID`: App Store Connect API key ID
- `APPLE_API_ISSUER_ID`: App Store Connect API issuer ID

When all required Apple secrets are available, the workflow imports the
certificate into a temporary keychain, applies a hardened Developer ID
signature, submits the app to Apple's notary service, staples the ticket, and
publishes a normal GitHub Release.

Every release contains the app ZIP and a SHA-256 checksum. If any validation,
test, signature, notarization, or packaging step fails, no Release is created.
The app ZIP also contains GPL-3.0, upstream license and NOTICE files, copyright
information, and directions to the corresponding source. The explicit
`MouseBridge-v<version>-source.zip` attachment contains the corresponding source;
GitHub's generated archives of the public download repository do not.

## Retry an existing release tag

If a tag-triggered run did not create a Release, dispatch the workflow from the
default branch to build the same existing tag:

```bash
gh workflow run release.yml --ref main -f tag=v0.2.3
```

Manual runs check out the tag and validate it against `Info.plist`; they do not
move it. Build, signing, notarization, packaging and Release uploads remain
required. The Actions artifact is a secondary CI copy, so its storage quota does
not block Release asset uploads. Existing Releases are not overwritten.

If the private Release exists but public delivery failed, download all its
assets into an empty directory and run `scripts/deliver-public-release.sh <dir>`
with the existing deploy key to deliver those exact signed files. Do not rebuild
or replace an existing version. If delivery already succeeded, rerun the public
repository's Publish workflow; identical assets are safe to retry.
