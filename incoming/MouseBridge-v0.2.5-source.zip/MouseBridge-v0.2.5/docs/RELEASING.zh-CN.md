# 发布 MouseBridge

[English](RELEASING.md) | 简体中文

## Sparkle 更新与公开分发

从 0.2.5 起集成 Sparkle 2.9.4，在菜单栏提供“检查更新…”和“自动检查更新”，默认每天
检查一次；下载和安装仍由用户在 Sparkle 窗口中确认。`v0.2.4` 不包含更新功能，首次使用
更新功能的版本仍需手动安装。

应用内的 `SUPublicEDKey` 与 GitHub Actions secret `SPARKLE_PRIVATE_KEY` 配对，后者
保存 base64 编码的 Ed25519 seed。私钥不进入源码、命令行参数或 Release 附件；不要重新
生成或替换它，否则已安装客户端无法验证后续更新。

`scripts/generate-appcast.sh <archive.zip> <https-download-prefix/>` 使用 Sparkle 官方工具
生成并验证归档及清单签名，并检查下载 URL、长度、构建号、版本和最低系统要求与应用包
一致。常规 CI 验证这条链路，但不会发布或更新下载源。

公开下载仓库为 `gmch1/mousebridge-releases`，客户端读取其 `appcast` Release 中的
签名清单。私有源码仓库保留开发历史，公开 Release 另外附上构建所需的干净源码快照。
`scripts/stage-public-release.py` 只导出指定的已跟踪文件，扫描安装包和源码包中的
凭据、个人路径及本地配置；扫描成功才允许交付。扫描不会输出疑似秘密的值。

私有仓库的 `RELEASES_DEPLOY_KEY` secret 只能向下载仓库推送。发布流水线将审核后的
7 个发布文件写入下载仓库 `incoming/`，该仓库自己的 Actions 验证 Ed25519 签名后先
发布版本化安装包，再更新滚动清单。它不需要访问私有仓库，也不保存个人 GitHub 令牌。
应用同样不包含 GitHub 访问令牌。

`CFBundleVersion` 固定为 `major × 1000000 + minor × 1000 + patch`（minor、patch
不超过 999）。例如 `0.2.5` 对应 `2005`；重新运行工作流不会改变版本顺序。

发布流水线由语义化版本 tag 触发。Tag 必须与 `Info.plist` 中的
`CFBundleShortVersionString` 完全一致。

## 预发布版本

没有 Apple 签名 secrets 时，流水线会构建 ad-hoc 签名压缩包，并发布为 GitHub
Pre-release：

```bash
git tag -a v0.2.5 -m "MouseBridge v0.2.5"
git push origin v0.2.5
```

## 签名并公证的正式版本

推送 tag 前，在 GitHub Actions 仓库设置中配置：

- `APPLE_CERTIFICATE_P12`：Developer ID Application `.p12` 的 Base64 内容
- `APPLE_CERTIFICATE_PASSWORD`：`.p12` 密码
- `KEYCHAIN_PASSWORD`：可选的 CI 临时钥匙串密码
- `APPLE_API_KEY_P8`：App Store Connect API 私钥的 Base64 内容
- `APPLE_API_KEY_ID`：App Store Connect API Key ID
- `APPLE_API_ISSUER_ID`：App Store Connect API Issuer ID

全部必要 secrets 可用时，流水线会把证书导入临时钥匙串，应用 hardened Developer ID
签名，提交 Apple 公证，装订公证票据，然后发布普通 GitHub Release。

每个版本包含应用 ZIP 和 SHA-256 校验文件。版本校验、测试、签名、公证或打包任一步骤
失败时，Release 都不会创建。

应用 ZIP 还必须包含 GPL-3.0、上游许可证与 NOTICE、版权信息和对应源码获取方式。
完整对应源码以显式的 `MouseBridge-v<版本>-source.zip` 附件提供；公开下载仓库自动
生成的源码归档不是应用源码。

## 重试已有标签的发布

如果 tag 流水线未创建 Release，可从默认分支手动触发发布，继续构建已有标签的源码：

```bash
gh workflow run release.yml --ref main -f tag=v0.2.3
```

手动发布会校验 tag 与检出的 `Info.plist` 一致，不移动标签。构建、签名、公证、打包和
Release 上传仍必须成功。Actions artifact 只是一份可选 CI 备份；其存储配额不足不会阻止
上传 Release 附件。已存在的 Release 不会被此工作流覆盖。

若私有 Release 已成功而公开交付失败，先从私有 Release 下载全部附件到空目录，然后
使用现有发布部署密钥运行 `scripts/deliver-public-release.sh <目录>`，交付原来的已签名
文件；不要重新构建或覆盖已有版本。若公开仓库已收到文件，可重跑其 Publish 工作流。
公开发布允许相同文件的重试，但拒绝修改已有版本，也不会把滚动清单降级。
