# MouseBridge for macOS

[English](README.md) | 简体中文

MouseBridge 是一个采用 GPL-3.0-or-later 的轻量原生 macOS 输入工具底座，提供鼠标按键
映射、触控板多指快捷键、仅鼠标滚轮控制以及 Logitech HID++ 硬件 DPI 配置。它面向只
需要少量输入功能、不希望长期运行大型厂商套件的用户。

项目有意通过小型 AppKit 界面、带版本的 JSON 配置文件和 CLI 暴露底层能力，方便普通
用户、脚本以及 Codex 等编码代理继续开发，而不必先理解或替换一个庞大的框架。

[下载最新版本](https://github.com/gmch1/mousebridge-releases/releases)

## 设置界面

<p align="center">
  <img src="docs/images/settings-trackpad.png" alt="包含触控板多指快捷键设置的 MouseBridge 界面" width="640">
</p>

## 项目目标

- 保持小巧、原生、容易理解和修改。
- 提供可靠的按键、滚轮与硬件 DPI 基础能力。
- 配置完全保存在本地，并适合自动化处理。
- 新增鼠标支持时优先增加设备配置，而不是重写界面。
- 不引入账号、云服务、遥测，也不依赖 Electron、Qt 或 Python 运行时。

MouseBridge 并不打算复刻 Logitech Options+ 的全部功能。除专注的触控板多指绑定外，
目前不管理连续手势、按应用配置、Flow、固件升级、电量信息，也不管理 Logitech 摄像头
和键盘。

## 当前功能

- 将滚轮中键、后退侧键和前进侧键映射为 `cmd+r` 等快捷键。
- 支持 `left click`、`right click`、`middle click` 与修饰键组合；例如将滚轮中键设为
  `cmd+left click`，模拟 Command + 左键点击链接，通常在后台新标签页打开（取决于浏览器设置）。
- 填写 `none` 可禁用按键；留空则透传原始按键。
- 将触控板 2–5 指物理按压映射为任意受支持的快捷键；可选同时响应短促轻点，并可选择
  “恰好指定手指数”或“指定手指数及以上”。
- 只反转鼠标的垂直或水平滚动，不改变触控板方向。
- 设置 0–20 的离散滚动量；`0` 表示跟随 macOS 默认值。
- 通过 Logitech HID++ `0x2201` 查询设备实际 DPI 档位，并使用 0–100% 滑杆选择。
- 显示鼠标连接状态与隐私权限状态，并可直接打开“辅助功能”和“输入监控”设置。
- 可从菜单栏暂停或恢复全部映射，无需退出应用。
- 脚本或编码代理修改 JSON 后自动重新加载配置。
- 通过 `SMAppService` 设置登录时启动。
- 菜单栏手动检查更新，或每天自动检查；更新包与清单使用签名验证，安装前由用户确认。
- 将诊断日志写入 `~/Library/Logs/MouseBridge.log`。

## 已测试硬件与环境

以下蓝牙设备已在 Apple 芯片 Mac 上进行实机验证：

| 鼠标 | VID / PID | 设备报告的 DPI | 环境 | 已验证功能 |
| --- | --- | --- | --- | --- |
| Logitech Signature Plus M750 L | `046D:B02C` | 400–4000，每档 100（37 档） | macOS 26.5.2、MouseBridge 0.2.0 | 发现、侧键、垂直滚动反转、DPI 读写 |
| Logitech MX Master 3S | `046D:B034` | 200–8000，每档 50（157 档） | macOS 26.6.2、MouseBridge 0.2.3 | 发现、DPI 范围查询、3000 DPI 写入及读回 |

M750 保留原有传输方式，本次尚未使用该型号重新进行 0.2.3 实机测试；MX Master 3S 的
按键和滚轮也尚未逐项手动验证。应用一次管理一只支持的鼠标。Bolt 接收器、Intel Mac、
其他鼠标型号及全部受支持 macOS 版本尚未验证。报告兼容性问题时，请附上产品名称、
连接方式、VID/PID、macOS 版本和诊断日志。

## 权限

拦截鼠标按键、修改滚轮事件和发送快捷键需要“辅助功能”权限；触控板绑定发送快捷键也
需要该权限。为了可靠地区分鼠标与触控板滚动，强烈建议同时开启“输入监控”；当前实测
环境已开启该权限。macOS 的隐私权限必须由用户手动批准，应用无法静默给自己授权。

设置窗口提供了对应系统设置页面的快捷入口。

## 安装

从 [GitHub Releases](https://github.com/gmch1/mousebridge-releases/releases) 下载 ZIP，
解压后把 `MouseBridge.app` 移动到 `/Applications`。

0.2.4 及更早版本需要先手动安装一次 0.2.5，之后可使用菜单栏“检查更新…”。

标记为 **Pre-release** 的版本使用 ad-hoc 签名，Gatekeeper 可能要求手动批准。经过
Developer ID 签名和 Apple 公证的构建会发布为普通 Release。

## 开发（贡献者）

```bash
zsh build-app.sh
open dist/MouseBridge.app
```

构建脚本会优先使用 `/Applications/Xcode.app`，运行 XCTest 与二进制自检，构建 Release
可执行文件并组装应用包。默认的 ad-hoc 签名只用于贡献者本地构建。

Developer ID 构建示例：

```bash
SIGN_IDENTITY="Developer ID Application: Example (TEAMID)" \
VERSION=0.2.1 BUILD_NUMBER=2 zsh build-app.sh
NOTARY_PROFILE=mousebridge-notary zsh scripts/notarize.sh
```

## 版本维护

推送 `v0.2.1` 这样的语义化版本 tag 后，流水线会校验 tag 与 `Info.plist` 版本是否一致，
运行全部测试、构建应用、生成 ZIP 和 SHA-256，并创建 GitHub Release。没有 Apple 签名
secrets 时，流水线会明确发布为 Pre-release。

完整步骤见 [docs/RELEASING.zh-CN.md](docs/RELEASING.zh-CN.md)。

## 配置与 CLI

配置文件位于：

```text
~/Library/Application Support/MouseBridge/config.json
```

```bash
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config get
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set middle "cmd+left click"
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set back cmd+r
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set trackpad-enabled true
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set trackpad-fingers 3
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set trackpad-action cmd+w
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set scroll-lines 4
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set dpi 1200
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge launch-at-login status
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge launch-at-login enable
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge diagnose
```

应用运行时会监控配置目录，并自动应用外部写入的合法配置。

也可以在设置窗口的“滚轮中键”输入 `cmd+left click`，然后点击“保存并应用”。命令行中
包含空格的动作需要加引号。此映射在所有应用中生效，留空可恢复原生中键；它模拟的是
单次点击，不是按住或拖动。后台打开行为由浏览器和网页决定；Safari 可在“设置 → 标签页”
中启用“⌘ 点按会在新标签页中打开链接”，并关闭新标签页或窗口打开时自动激活。

## 架构与扩展点

- `AppConfig` 与 `ConfigStore`：带版本的 JSON、校验、原子写入与目录监控。
- `EventTapController`：按键拦截、输入源识别和滚轮转换。
- `MultitouchController` 与 `MultitouchGestureRecognizer`：原生私有框架设备回调，以及零
  数组分配、可独立测试的手势状态机；功能关闭或 MouseBridge 暂停时不会保留设备回调。
- `ScrollTransform`：纯函数实现并经过测试的离散滚动计算。
- `ShortcutExecutor`：轻量快捷键解析和 Quartz 事件注入。
- `HIDPPController`：基于设备配置的 IOKit 传输、DPI 查询、串行请求、安全断连清理和退出时
  尽力恢复 DPI。
- `SettingsWindowController`：小型 AppKit 设置界面。
- `CommandLineInterface`：面向脚本与编码代理的自动化接口。

新增设备从 `MouseDeviceProfile` 开始，传输层不需要知道产品的市场名称。

## 开源基础

MouseBridge 的互操作能力与部分实现模式建立在以下项目的公开工作之上：

- [Scroll Reverser](https://github.com/pilotmoon/Scroll-Reverser)（Apache-2.0）：其公开
  实现帮助确认了触控板/鼠标的事件时序，以及可靠反转滚轮时同时更新 Quartz 和底层
  IOHID 滚动数据的必要性。
- [Solaar](https://github.com/pwr-Solaar/Solaar)（GPL-2.0-or-later）：其 HID++ 可调
  DPI 列表解码为 MouseBridge 的对应逻辑提供了实现依据。
- [TapBind](https://github.com/gmch1/TapBind)（衍生自
  [MiddleClick](https://github.com/artginzburg/MiddleClick)，GPL-3.0）：其
  MultitouchSupport 声明和交互行为为 MouseBridge 独立重写的可配置触控板状态机提供参考。

组合后的 MouseBridge 项目使用 GPL-3.0-or-later 分发；第三方来源部分继续保留原始声明
和许可证历史。详情见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) 和
[LICENSES](LICENSES/)。

## 兼容性与分发说明

为了可靠反转滚轮，MouseBridge 会动态加载 Scroll Reverser 也记录过的私有 IOHID 桥接
符号；触控板多指接触数使用 Apple 私有 MultitouchSupport 框架。滚轮私有符号不可用时会
退回公开 Quartz 字段；若 MultitouchSupport 发生不兼容变化，多指绑定将不可用。私有 API
可能随 macOS 更新而变化，因此新系统版本需要重新回归这两条链路。这也意味着项目更适合
直接分发，而不是 Mac App Store。

## 许可证

MouseBridge 是使用 [GPL-3.0-or-later](LICENSE) 分发的自由软件。对应源码可从本仓库及
每个 GitHub Release 获取，详见 [SOURCE.md](SOURCE.md)。

## MX Master 3S 蓝牙支持（0.2.3）

已新增 VID `0x046D` / PID `0xB034` 的 MX Master 3S 设备配置。该型号通过 HID++
Output Element 传输进行 DPI 查询和写入，M750 保留原有传输方式。界面使用设备报告的
实际档位；配置支持 100–8000 DPI，应用时会取该鼠标支持的最近档位，并读取设备确认。
现有 schema 3 配置、按键、滚轮和触控板多指功能均保留。

只读硬件诊断（不会加载或重写配置，也不会写入或恢复 DPI）：

```bash
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge device status
```

程序需要输入监控权限才能访问鼠标。macOS 可能把 CLI 调用归属于终端或自动化工具；
调用方的输入监控权限与 MouseBridge App 独立。如果 CLI 访问被拒绝，可以查看 App 中
已确认的应用结果及本地诊断日志，已有权限的 GUI 无需额外授权即可继续使用。
退出时仍尽力恢复连接时的 DPI，重新连接后会重新应用配置。

实现时核对了 [Solaar](https://github.com/pwr-Solaar/Solaar) 的 HID++ 协议和
[Lazy Mouse](https://github.com/RRY/lazy-mouse) 的 macOS 蓝牙传输方式，未依赖或安装它们。
