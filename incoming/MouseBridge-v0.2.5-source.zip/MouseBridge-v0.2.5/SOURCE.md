# Corresponding source / 对应源码

MouseBridge is distributed under GPL-3.0-or-later. The complete corresponding
source for each binary release, including build and installation scripts, is
available in the explicit `MouseBridge-v<version>-source.zip` asset alongside
the application ZIP at:

https://github.com/gmch1/mousebridge-releases/releases

Use this source ZIP, not GitHub's automatically generated archives of the
download repository. The source snapshot contains the build inputs for the
released version; private Git history and local configuration are excluded.

MouseBridge 使用 GPL-3.0-or-later 分发。每个二进制版本的完整对应源码（包括构建与安装
脚本）在同一公开 Release 中以 `MouseBridge-v<版本>-source.zip` 附件免费提供。请使用
该附件，而非 GitHub 自动生成的下载仓库归档。源码快照不包含私有 Git 历史或本地配置。
