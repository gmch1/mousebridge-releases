# OpenLogi reference

MouseBridge's visual mouse selector and paired thumb-wheel presets reference
[AprilNEA/OpenLogi](https://github.com/AprilNEA/OpenLogi), inspected at commit
`a10264bd235fccce914dce51984ac7224a2fbcab`.

## Reused behavior

- Mouse diagram hotspots select a control and its action editor, following
  `crates/openlogi-desktop/src/features/mouse/view.rs`.
- Paired presets and exact-pair recognition are adapted from
  `crates/openlogi-desktop/src/features/mouse/thumbwheel.rs`. Mixed or reversed
  custom bindings remain custom; a preset changes both directions explicitly.
- Discrete actions use independent 200 ms cooldowns for each direction, with
  configuration changes clearing retained state, adapted from
  `crates/openlogi-agent-core/src/watchers/gesture/dispatch/wheel.rs`.

OpenLogi's reused source is available under MIT; its copyright and license are
retained in `LICENSES/OpenLogi-MIT.txt`. The MouseBridge adaptation is in Swift.

## Platform adaptation

OpenLogi captures the thumb wheel directly with HID++ feature `0x2150`, reads
physical direction and resolution, and accumulates raw increments. MouseBridge
uses the existing macOS scroll event path, so this implementation maps delivered
horizontal scroll directions, including tilt wheels, rather than claiming a
model-specific physical forward/back direction. System natural scrolling may
change the delivered direction; the UI provides a swap button. MouseBridge's
reverse-horizontal toggle applies to unbound native scrolling only.

The HID++ increment threshold is not copied onto pixel/line CGEvent deltas:
those units are not interchangeable. One nonzero mapped packet can trigger an
action; subsequent packets in that direction are consumed during the cooldown.
No delayed backlog is queued. The vertical-scrolling presets follow OpenLogi's
`ScrollBinding` distinction: continuous scroll output bypasses the action
cooldown. MouseBridge moves each X delta into Y in place, retaining the original
line/fixed-point/pixel encodings and any existing Y/Z movement; it then applies
the normal main-wheel reversal and discrete-line settings.

Unbound directions retain native scrolling; mixed
axis events preserve vertical scrolling. Existing mouse/trackpad classification
is used; continuous devices require Input Monitoring for this path.

Presets use the existing keyboard/click action executor or the wheel-specific
`scroll up` / `scroll down` actions. Device diversion, wheel-touch taps, media-key actions and per-device
profiles are not implemented by this change. The diagram is an original AppKit
vector schematic; OpenLogi's brand assets are not redistributed.

CI verifies synthetic input and layout. Physical MX Master thumb-wheel behavior
still needs validation on the user's Mac, including natural-scrolling direction
and coexistence with other mouse utilities.
