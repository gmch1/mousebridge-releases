// SPDX-License-Identifier: GPL-3.0-or-later
// Scroll payload access informed by Scroll Reverser, Copyright 2011 Nicholas
// Moore, licensed under Apache-2.0; see LICENSES/. Adapted for MouseBridge in 2026.
// Sender lookup adapted from OpenLogi, Copyright (c) 2026 AprilNEA (MIT).
// See docs/OPENLOGI-REFERENCE.md and LICENSES/OpenLogi-MIT.txt.

import ApplicationServices
import Darwin
import Foundation

final class HIDEventBridge {
    typealias CopyHIDEvent = @convention(c) (UnsafeRawPointer?) -> UnsafeMutableRawPointer?
    typealias GetFloatValue = @convention(c) (UnsafeRawPointer?, UInt32) -> Double
    typealias SetFloatValue = @convention(c) (UnsafeMutableRawPointer?, UInt32, Double) -> Void
    typealias GetSenderID = @convention(c) (UnsafeRawPointer?) -> UInt64

    static let shared = HIDEventBridge()

    private let coreGraphicsHandle: UnsafeMutableRawPointer?
    private let ioKitHandle: UnsafeMutableRawPointer?
    private let copyFunction: CopyHIDEvent?
    private let getFunction: GetFloatValue?
    private let setFunction: SetFloatValue?
    private let senderFunction: GetSenderID?

    private init() {
        coreGraphicsHandle = dlopen("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics", RTLD_LAZY | RTLD_LOCAL)
        ioKitHandle = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_LAZY | RTLD_LOCAL)
        if let symbol = coreGraphicsHandle.flatMap({ dlsym($0, "CGEventCopyIOHIDEvent") }) {
            copyFunction = unsafeBitCast(symbol, to: CopyHIDEvent.self)
        } else {
            copyFunction = nil
        }
        if let symbol = ioKitHandle.flatMap({ dlsym($0, "IOHIDEventGetFloatValue") }) {
            getFunction = unsafeBitCast(symbol, to: GetFloatValue.self)
        } else {
            getFunction = nil
        }
        if let symbol = ioKitHandle.flatMap({ dlsym($0, "IOHIDEventSetFloatValue") }) {
            setFunction = unsafeBitCast(symbol, to: SetFloatValue.self)
        } else {
            setFunction = nil
        }
        if let symbol = ioKitHandle.flatMap({ dlsym($0, "IOHIDEventGetSenderID") }) {
            senderFunction = unsafeBitCast(symbol, to: GetSenderID.self)
        } else {
            senderFunction = nil
        }
    }

    /// Resolve origin independently of the optional scroll mutation symbols.
    func senderID(from event: CGEvent) -> UInt64? {
        guard let senderFunction,
              let hid = copyFunction?(Unmanaged.passUnretained(event).toOpaque()) else { return nil }
        defer { releaseHIDEvent(hid) }
        let sender = senderFunction(hid)
        return sender == 0 ? nil : sender
    }

    var isAvailable: Bool { copyFunction != nil && getFunction != nil && setFunction != nil }

    func copyHIDEvent(from event: CGEvent) -> UnsafeMutableRawPointer? {
        guard isAvailable else { return nil }
        return copyFunction?(Unmanaged.passUnretained(event).toOpaque())
    }

    func releaseHIDEvent(_ event: UnsafeMutableRawPointer) {
        Unmanaged<AnyObject>.fromOpaque(event).release()
    }

    func floatValue(_ event: UnsafeRawPointer, field: UInt32) -> Double? {
        getFunction?(event, field)
    }

    func setFloatValue(_ event: UnsafeMutableRawPointer, field: UInt32, value: Double) {
        setFunction?(event, field, value)
    }
}
