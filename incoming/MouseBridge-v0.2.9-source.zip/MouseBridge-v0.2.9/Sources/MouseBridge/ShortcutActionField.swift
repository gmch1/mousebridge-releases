// SPDX-License-Identifier: GPL-3.0-or-later

import AppKit

/// Common actions stay readable; existing/custom shortcut strings round-trip unchanged.
@MainActor
final class ShortcutActionField: NSView, NSTextFieldDelegate {
    var onChange: (() -> Void)?
    private static let commonPresets: [(String, String)] = [
        ("默认行为（不设置）", ""), ("不执行任何操作", "none"),
        ("后台打开链接（⌘ + 点击）", "cmd+left click"),
        ("刷新（⌘R）", "cmd+r"), ("关闭标签页（⌘W）", "cmd+w"),
        ("后退（⌘[）", "cmd+["), ("前进（⌘]）", "cmd+]"),
        ("上一个标签页（⌃⇧⇥）", "ctrl+shift+tab"), ("下一个标签页（⌃⇥）", "ctrl+tab"),
        ("放大（⌘=）", "cmd+="), ("缩小（⌘−）", "cmd+-"),
        ("中键点击", "middle click"),
    ]
    private let presets: [(String, String)]
    let popup = NSPopUpButton(frame: .zero, pullsDown: false)
    private let customField = NSTextField()

    var stringValue: String {
        get {
            let index = popup.indexOfSelectedItem
            return presets.indices.contains(index) ? presets[index].1 : customField.stringValue
        }
        set {
            customField.stringValue = newValue
            if let index = presets.firstIndex(where: { $0.1 == newValue }) {
                popup.selectItem(at: index)
            } else {
                popup.selectItem(at: presets.count)
            }
            updateCustomField()
            onChange?()
        }
    }

    var isEnabled = true {
        didSet { popup.isEnabled = isEnabled; customField.isEnabled = isEnabled }
    }

    init(label: String, includesScrollActions: Bool = false) {
        presets = Self.commonPresets + (includesScrollActions ? [("向上滚动", "scroll up"), ("向下滚动", "scroll down")] : [])
        super.init(frame: .zero)
        popup.addItems(withTitles: presets.map(\.0) + ["自定义快捷键…"])
        popup.target = self
        popup.action = #selector(selectionChanged)
        popup.setAccessibilityLabel(label)
        customField.delegate = self
        customField.placeholderString = "例如 shift+cmd+z 或 cmd+left click"
        customField.setAccessibilityLabel(label + "自定义快捷键")
        customField.isHidden = true
        let stack = NSStackView(views: [popup, customField])
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 6
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor),
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor),
            popup.widthAnchor.constraint(equalTo: stack.widthAnchor),
            customField.widthAnchor.constraint(equalTo: stack.widthAnchor),
        ])
    }

    required init?(coder: NSCoder) { nil }

    func controlTextDidChange(_ notification: Notification) { onChange?() }

    @objc private func selectionChanged() {
        updateCustomField()
        onChange?()
        if !customField.isHidden { window?.makeFirstResponder(customField) }
    }

    private func updateCustomField() {
        customField.isHidden = popup.indexOfSelectedItem != presets.count
    }

    func focus() {
        window?.makeFirstResponder(customField.isHidden ? popup : customField)
    }
}
