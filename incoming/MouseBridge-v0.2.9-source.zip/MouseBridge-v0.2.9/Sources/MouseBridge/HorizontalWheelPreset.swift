// SPDX-License-Identifier: GPL-3.0-or-later
// Paired presets and exact-pair recognition adapted from OpenLogi.
// Copyright (c) 2026 AprilNEA. MIT license: LICENSES/OpenLogi-MIT.txt.

/// Uses MouseBridge's existing shortcut strings, so choosing Custom never rewrites a binding.
enum HorizontalWheelPreset: Int, CaseIterable {
    case native, vertical, verticalReversed, tabs, history, undoRedo, desktops, zoom, disabled

    var title: String {
        switch self {
        case .native: return "默认横向滚动"
        case .vertical: return "上下滚动（像主滚轮）"
        case .verticalReversed: return "上下滚动（反向）"
        case .tabs: return "上一个 / 下一个标签页"
        case .history: return "浏览器后退 / 前进"
        case .undoRedo: return "撤销 / 重做"
        case .desktops: return "上一个 / 下一个桌面"
        case .zoom: return "缩小 / 放大"
        case .disabled: return "禁用横向滚动"
        }
    }
    var pair: (left: String, right: String) {
        switch self {
        case .native: return ("", "")
        case .vertical: return ("scroll up", "scroll down")
        case .verticalReversed: return ("scroll down", "scroll up")
        case .tabs: return ("ctrl+shift+tab", "ctrl+tab")
        case .history: return ("cmd+[", "cmd+]")
        case .undoRedo: return ("cmd+z", "shift+cmd+z")
        case .desktops: return ("ctrl+left", "ctrl+right")
        case .zoom: return ("cmd+-", "cmd+=")
        case .disabled: return ("none", "none")
        }
    }
    static func recognize(left: String, right: String) -> Self? {
        allCases.first { $0.pair.left == left && $0.pair.right == right }
    }
}
