// SPDX-License-Identifier: GPL-3.0-or-later
// Sender/product classification adapted from OpenLogi's macos/sender.rs.
// Copyright (c) 2026 AprilNEA. MIT: LICENSES/OpenLogi-MIT.txt.
// Pinned source and platform limits: docs/OPENLOGI-REFERENCE.md.

import ApplicationServices
import Foundation
import IOKit

/// Used on the event tap's main run loop. Resolve device identity, never infer
/// a trackpad click merely from fingers resting on a multitouch surface.
final class EventDeviceResolver {
    enum Kind: String { case trackpad, other, unknown }

    static let shared = EventDeviceResolver()
    private let senderID: (CGEvent) -> UInt64?
    private let productName: (UInt64) -> String?
    private var cache: [UInt64: Kind] = [:]

    init(
        senderID: @escaping (CGEvent) -> UInt64? = { HIDEventBridge.shared.senderID(from: $0) },
        productName: @escaping (UInt64) -> String? = EventDeviceResolver.productName
    ) {
        self.senderID = senderID
        self.productName = productName
    }

    func kind(for event: CGEvent) -> Kind {
        guard let id = senderID(event), id != 0 else { return .unknown }
        if let known = cache[id] { return known }
        guard let name = productName(id)?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else {
            // A transient lookup failure must not disable a device for this session.
            return .unknown
        }
        let kind: Kind = name.lowercased().contains("trackpad") ? .trackpad : .other
        // Registry IDs change on reconnect; bound retained facts over long sessions.
        if cache.count >= 128 { cache.removeAll(keepingCapacity: true) }
        cache[id] = kind
        DiagnosticLog.shared.write("click source identified kind=\(kind.rawValue) registryID=\(id)")
        return kind
    }

    private static func productName(for senderID: UInt64) -> String? {
        guard let matching = IORegistryEntryIDMatching(senderID) else { return nil }
        let service = IOServiceGetMatchingService(kIOMainPortDefault, matching)
        guard service != 0 else { return nil }
        defer { IOObjectRelease(service) }
        // Trackpads expose a mouse HID interface for clicks. Follow the service
        // parents to the device Product rather than using its mouse usage code.
        return IORegistryEntrySearchCFProperty(
            service, kIOServicePlane, "Product" as CFString, kCFAllocatorDefault,
            IOOptionBits(kIORegistryIterateRecursively | kIORegistryIterateParents)
        ) as? String
    }
}
