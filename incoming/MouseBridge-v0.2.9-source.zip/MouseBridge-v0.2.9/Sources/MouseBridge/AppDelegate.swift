// SPDX-License-Identifier: GPL-3.0-or-later

import AppKit
import ApplicationServices
import Sparkle

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem!
    private var settingsWindow: SettingsWindowController?
    private let updaterController = SPUStandardUpdaterController(
        startingUpdater: false, updaterDelegate: nil, userDriverDelegate: nil
    )
    private let hid = HIDPPController()
    private var eventTap: EventTapController!
    private let multitouch = MultitouchController.shared
    private var config = AppConfig()
    private var isEnabled = true
    private var connectionItem: NSMenuItem!
    private var toggleItem: NSMenuItem!
    private var updaterObservations: [NSKeyValueObservation] = []
    private var permissionTimer: Timer?
    private var lastLoggedPermissions: (Bool, Bool)?
    private var hidConnectionState: Bool?
    private var currentDeviceName: String?
    private var dpiApplyRevision: UInt64 = 0
    private var currentDPIApplyResult: (actual: Int?, requested: Int)?
    private var currentDPICapabilities: HIDPPController.DPICapabilities?
    private var currentInputStatus: (text: String, ready: Bool)?
    private var currentPermissionStatus: (accessibility: Bool, inputMonitoring: Bool)?

    func applicationDidFinishLaunching(_ notification: Notification) {
        DiagnosticLog.shared.resetForLaunch()
        config = ConfigStore.shared.config
        ConfigStore.shared.startWatching()
        DiagnosticLog.shared.write("launch bundle=\(Bundle.main.bundlePath) pid=\(ProcessInfo.processInfo.processIdentifier)")
        DiagnosticLog.shared.write("config back=\(config.backAction) forward=\(config.forwardAction) middle=\(config.middleAction) reverseV=\(config.reverseVerticalScroll) reverseH=\(config.reverseHorizontalScroll) scrollLines=\(config.scrollLines) dpi=\(config.primaryDPI) trackpadEnabled=\(config.trackpadGestureEnabled) trackpadFingers=\(config.trackpadFingerCount) trackpadAction=\(config.trackpadAction) trackpadTap=\(config.trackpadTapEnabled)")
        buildStatusMenu()
        updaterController.startUpdater()
        updaterObservations = [
            updaterController.updater.observe(\.canCheckForUpdates, options: [.initial, .new]) { [weak self] _, _ in
                Task { @MainActor in self?.refreshUpdateSettings() }
            },
            updaterController.updater.observe(\.automaticallyChecksForUpdates, options: [.new]) { [weak self] _, _ in
                Task { @MainActor in self?.refreshUpdateSettings() }
            },
        ]

        multitouch.configure(config: config) { action, trigger in
            DiagnosticLog.shared.writeEvent("trackpad gesture trigger=\(trigger.rawValue) action=\(action)")
            ShortcutExecutor.execute(action)
        }
        multitouch.setAppEnabled(isEnabled)
        multitouch.start()

        eventTap = EventTapController(
            configProvider: { [weak self] in self?.config ?? AppConfig() },
            enabledProvider: { [weak self] in self?.isEnabled ?? false },
            trackpadClickHandler: { [weak self] in self?.multitouch.handlePhysicalClick() ?? false }
        )
        eventTap.onActivity = { [weak self] scrolls, buttons in
            self?.setInputStatus("按键与滚轮：运行中（滚轮 \(scrolls)，按键 \(buttons)）", ready: true)
        }
        startInputMonitoringWhenAuthorized(prompt: true)

        hid.onConnectionChanged = { [weak self] connected in
            guard let self else { return }
            DiagnosticLog.shared.write("hid connection changed connected=\(connected)")
            self.dpiApplyRevision &+= 1
            self.hidConnectionState = connected
            self.currentDeviceName = self.hid.connectedDeviceName
            self.refreshMenuStatus()
            self.settingsWindow?.setConnected(connected, deviceName: self.currentDeviceName)
            self.currentDPIApplyResult = nil
            if connected {
                self.applyConfiguredDPI(self.config.primaryDPI, reason: "initial")
            } else {
                self.currentDPICapabilities = nil
            }
        }
        hid.onDPICapabilities = { [weak self] capabilities in
            self?.currentDPICapabilities = capabilities
            self?.settingsWindow?.setDPICapabilities(capabilities)
        }
        hid.start()

        NotificationCenter.default.addObserver(
            forName: ConfigStore.changed,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self, let updated = notification.object as? AppConfig else { return }
            Task { @MainActor in
                self.config = updated
                self.multitouch.updateConfig(updated)
                DiagnosticLog.shared.write("config changed back=\(updated.backAction) forward=\(updated.forwardAction) middle=\(updated.middleAction) reverseV=\(updated.reverseVerticalScroll) reverseH=\(updated.reverseHorizontalScroll) scrollLines=\(updated.scrollLines) dpi=\(updated.primaryDPI) trackpadEnabled=\(updated.trackpadGestureEnabled) trackpadFingers=\(updated.trackpadFingerCount) trackpadAction=\(updated.trackpadAction) trackpadTap=\(updated.trackpadTapEnabled)")
                self.applyConfiguredDPI(updated.primaryDPI, reason: "config changed")
            }
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        ConfigStore.shared.stopWatching()
        permissionTimer?.invalidate()
        eventTap?.stop()
        multitouch.stop()
        hid.stop()
    }

    private func applyConfiguredDPI(_ requested: Int, reason: String) {
        dpiApplyRevision &+= 1
        let revision = dpiApplyRevision
        hid.setDPI(requested) { [weak self] actualDPI in
            DiagnosticLog.shared.write(
                "DPI apply reason=\(reason) requested=\(requested) actual=\(actualDPI.map(String.init) ?? "unknown") success=\(actualDPI != nil)"
            )
            DispatchQueue.main.async { [weak self] in
                guard let self, self.dpiApplyRevision == revision,
                      self.config.primaryDPI == requested,
                      self.hidConnectionState == true else { return }
                self.currentDPIApplyResult = (actualDPI, requested)
                self.settingsWindow?.setDPIApplyResult(actualDPI, requested: requested)
            }
        }
    }

    private func startInputMonitoringWhenAuthorized(prompt: Bool) {
        let accessibilityGranted = AXIsProcessTrusted()
        let inputMonitoringGranted = CGPreflightListenEventAccess()
        if lastLoggedPermissions?.0 != accessibilityGranted || lastLoggedPermissions?.1 != inputMonitoringGranted {
            DiagnosticLog.shared.write("permissions accessibility=\(accessibilityGranted) inputMonitoring=\(inputMonitoringGranted)")
            lastLoggedPermissions = (accessibilityGranted, inputMonitoringGranted)
        }
        currentPermissionStatus = (accessibilityGranted, inputMonitoringGranted)
        settingsWindow?.setPermissionStatus(
            accessibilityGranted: accessibilityGranted,
            inputMonitoringGranted: inputMonitoringGranted
        )

        if accessibilityGranted {
            let started = eventTap.start(monitorGestures: inputMonitoringGranted)
            DiagnosticLog.shared.write("event tap requested gestures=\(inputMonitoringGranted) started=\(started)")
            let suffix = inputMonitoringGranted ? "" : "（基础鼠标模式）"
            setInputStatus(started ? "按键与滚轮：运行中\(suffix)" : "按键与滚轮：启动失败", ready: started)
            if inputMonitoringGranted {
                permissionTimer?.invalidate()
                permissionTimer = nil
            } else {
                schedulePermissionRefresh()
                requestMissingPermissions(
                    accessibilityGranted: true,
                    inputMonitoringGranted: false,
                    prompt: prompt
                )
            }
            return
        }

        var missing: [String] = []
        if !accessibilityGranted { missing.append("辅助功能") }
        if !inputMonitoringGranted { missing.append("输入监控") }
        setInputStatus("按键与滚轮：等待\(missing.joined(separator: "、"))权限", ready: false)
        requestMissingPermissions(
            accessibilityGranted: accessibilityGranted,
            inputMonitoringGranted: inputMonitoringGranted,
            prompt: prompt
        )
        schedulePermissionRefresh()
    }

    private func requestMissingPermissions(
        accessibilityGranted: Bool,
        inputMonitoringGranted: Bool,
        prompt: Bool
    ) {
        guard prompt else { return }
        if !accessibilityGranted {
            let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
            _ = AXIsProcessTrustedWithOptions(options)
        }
        if !inputMonitoringGranted && !UserDefaults.standard.bool(forKey: "hasRequestedInputMonitoring") {
            UserDefaults.standard.set(true, forKey: "hasRequestedInputMonitoring")
            DispatchQueue.global(qos: .userInitiated).async {
                _ = CGRequestListenEventAccess()
            }
        }
    }

    private func schedulePermissionRefresh() {
        guard permissionTimer == nil else { return }
        permissionTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.startInputMonitoringWhenAuthorized(prompt: false) }
        }
    }

    private func setInputStatus(_ text: String, ready: Bool) {
        currentInputStatus = (text, ready)
        refreshMenuStatus()
        settingsWindow?.setInputStatus(text, ready: ready)
    }

    private func buildStatusMenu() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        if let button = statusItem.button {
            button.image = NSImage(systemSymbolName: "computermouse", accessibilityDescription: "MouseBridge")
        }
        let menu = NSMenu()
        connectionItem = NSMenuItem(title: "MouseBridge · 正在启动", action: nil, keyEquivalent: "")
        connectionItem.isEnabled = false
        menu.addItem(connectionItem)
        menu.addItem(.separator())
        menu.addItem(NSMenuItem(title: "打开设置…", action: #selector(openSettings), keyEquivalent: ","))
        toggleItem = NSMenuItem(title: "暂停映射", action: #selector(toggleEnabled), keyEquivalent: "")
        menu.addItem(toggleItem)
        for item in menu.items where item.action != nil { item.target = self }
        // Sparkle validates this menu item while a check or installation is in progress.
        let updateItem = NSMenuItem(
            title: "检查更新…",
            action: #selector(SPUStandardUpdaterController.checkForUpdates(_:)),
            keyEquivalent: ""
        )
        updateItem.target = updaterController
        menu.addItem(updateItem)
        menu.addItem(.separator())
        let quitItem = NSMenuItem(title: "退出 MouseBridge", action: #selector(quit), keyEquivalent: "q")
        quitItem.target = self
        menu.addItem(quitItem)
        statusItem.menu = menu
    }

    private func refreshMenuStatus() {
        let name = currentDeviceName ?? "MouseBridge"
        let state = !isEnabled ? "已暂停" : (currentInputStatus?.ready == true ? "运行中" : "需要设置")
        connectionItem?.title = "\(name) · \(state)"
        connectionItem?.toolTip = currentInputStatus?.text
        statusItem?.button?.toolTip = "MouseBridge · \(state)"
    }

    private func refreshUpdateSettings() {
        settingsWindow?.configureUpdates(
            automaticChecks: updaterController.updater.automaticallyChecksForUpdates,
            canCheck: updaterController.updater.canCheckForUpdates
        )
    }

    @objc private func openSettings() {
        if settingsWindow == nil {
            let controller = SettingsWindowController()
            controller.onCheckForUpdates = { [weak self] in
                guard let self, self.updaterController.updater.canCheckForUpdates else { return }
                self.updaterController.checkForUpdates(nil)
            }
            controller.onAutomaticUpdatesChanged = { [weak self] enabled in
                self?.updaterController.updater.automaticallyChecksForUpdates = enabled
            }
            controller.onAboutRequested = { [weak self] in self?.showAbout() }
            controller.onDPIApplyRequested = { [weak self] in
                guard let self else { return }
                self.applyConfiguredDPI(self.config.primaryDPI, reason: "manual retry")
            }
            if let hidConnectionState {
                controller.setConnected(hidConnectionState, deviceName: currentDeviceName)
            }
            if let currentDPICapabilities { controller.setDPICapabilities(currentDPICapabilities) }
            if let currentDPIApplyResult {
                controller.setDPIApplyResult(currentDPIApplyResult.actual, requested: currentDPIApplyResult.requested)
            }
            if let currentInputStatus {
                controller.setInputStatus(currentInputStatus.text, ready: currentInputStatus.ready)
            }
            if let currentPermissionStatus {
                controller.setPermissionStatus(
                    accessibilityGranted: currentPermissionStatus.accessibility,
                    inputMonitoringGranted: currentPermissionStatus.inputMonitoring
                )
                if !currentPermissionStatus.accessibility { controller.showGeneralSettings() }
            }
            settingsWindow = controller
        }
        refreshUpdateSettings()
        settingsWindow?.showWindow(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    @objc private func toggleEnabled() {
        isEnabled.toggle()
        multitouch.setAppEnabled(isEnabled)
        toggleItem.title = isEnabled ? "暂停映射" : "恢复映射"
        refreshMenuStatus()
    }

    @objc private func showAbout() {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
        let alert = NSAlert()
        alert.messageText = "MouseBridge \(version)"
        alert.informativeText = """
        Copyright © 2026 guomingchao 与 MouseBridge 贡献者

        本程序是使用 GPL-3.0-or-later 分发的自由软件，不提供任何担保。你可以依照许可证复制、修改和再分发。完整许可证与第三方声明位于应用包 Contents/Resources/Legal，源码可从 GitHub 免费获取。
        """
        alert.addButton(withTitle: "好")
        alert.addButton(withTitle: "查看源码")
        if alert.runModal() == .alertSecondButtonReturn,
           let url = URL(string: "https://github.com/gmch1/mousebridge-releases/releases") {
            NSWorkspace.shared.open(url)
        }
    }

    @objc private func quit() {
        NSApp.terminate(nil)
    }

}
