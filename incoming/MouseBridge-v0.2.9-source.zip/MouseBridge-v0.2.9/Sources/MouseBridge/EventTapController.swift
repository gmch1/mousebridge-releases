// SPDX-License-Identifier: GPL-3.0-or-later
// Scroll-event handling includes adaptations informed by Scroll Reverser,
// Copyright 2011 Nicholas Moore, licensed under Apache-2.0. See LICENSES/.
// Modified and reimplemented for MouseBridge in 2026.

import ApplicationServices
import AppKit
import Foundation

final class EventTapController {
    private static let probeMarker: Int64 = 0x4D425052
    private var tap: CFMachPort?
    private var source: CFRunLoopSource?
    private var gestureTap: CFMachPort?
    private var gestureSource: CFRunLoopSource?
    private var configProvider: () -> AppConfig
    private var enabledProvider: () -> Bool
    private var trackpadClickHandler: () -> Bool
    private let clickSourceProvider: (CGEvent) -> EventDeviceResolver.Kind
    private var lastTouchTime = -Double.greatestFiniteMagnitude
    private var touchingCount = 0
    private var lastScrollWasMouse = true
    private var scrollEventCount = 0
    private var buttonEventCount = 0
    private var probeScheduled = false
    private var probeReceived = false
    private var horizontalMapper = HorizontalScrollMapper()
    private let actionExecutor: (String, CGPoint) -> Void
    private let uptime: () -> Double
    var onActivity: ((Int, Int) -> Void)?

    init(
        configProvider: @escaping () -> AppConfig,
        enabledProvider: @escaping () -> Bool,
        trackpadClickHandler: @escaping () -> Bool = { false },
        clickSourceProvider: @escaping (CGEvent) -> EventDeviceResolver.Kind = { EventDeviceResolver.shared.kind(for: $0) },
        actionExecutor: @escaping (String, CGPoint) -> Void = { ShortcutExecutor.execute($0, at: $1) },
        uptime: @escaping () -> Double = { ProcessInfo.processInfo.systemUptime }
    ) {
        self.configProvider = configProvider
        self.enabledProvider = enabledProvider
        self.trackpadClickHandler = trackpadClickHandler
        self.clickSourceProvider = clickSourceProvider
        self.actionExecutor = actionExecutor
        self.uptime = uptime
    }

    func start(monitorGestures: Bool) -> Bool {
        if tap != nil {
            if monitorGestures && gestureTap == nil { startGestureTap() }
            DiagnosticLog.shared.write("active event tap already exists")
            return true
        }
        var mask = CGEventMask(1 << CGEventType.otherMouseDown.rawValue)
            | CGEventMask(1 << CGEventType.otherMouseUp.rawValue)
            | CGEventMask(1 << CGEventType.leftMouseDown.rawValue)
            | CGEventMask(1 << CGEventType.rightMouseDown.rawValue)
            | CGEventMask(1 << CGEventType.scrollWheel.rawValue)
        if DiagnosticLog.verboseEvents {
            mask |= CGEventMask(1 << CGEventType.keyDown.rawValue)
                | CGEventMask(1 << CGEventType.keyUp.rawValue)
        }
        let context = Unmanaged.passUnretained(self).toOpaque()
        guard let newTap = CGEvent.tapCreate(
            tap: .cgSessionEventTap,
            place: .tailAppendEventTap,
            options: .defaultTap,
            eventsOfInterest: mask,
            callback: eventTapCallback,
            userInfo: context
        ) else {
            DiagnosticLog.shared.write("active event tap creation FAILED")
            return false
        }
        tap = newTap
        source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, newTap, 0)
        CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
        CGEvent.tapEnable(tap: newTap, enable: true)
        DiagnosticLog.shared.write("active event tap created mask=\(mask)")
        DiagnosticLog.shared.write("scroll IOHID SPI available=\(HIDEventBridge.shared.isAvailable)")

        if monitorGestures { startGestureTap() }
        if DiagnosticLog.verboseEvents { scheduleSelfProbe() }
        return true
    }

    private func scheduleSelfProbe() {
        guard !probeScheduled else { return }
        probeScheduled = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.75) { [weak self] in
            guard let self else { return }
            guard let probe = CGEvent(
                scrollWheelEvent2Source: nil,
                units: .line,
                wheelCount: 1,
                wheel1: 1,
                wheel2: 0,
                wheel3: 0
            ) else {
                DiagnosticLog.shared.write("self probe event creation FAILED")
                return
            }
            probe.setIntegerValueField(.eventSourceUserData, value: Self.probeMarker)
            DiagnosticLog.shared.write("self probe posting")
            probe.post(tap: .cghidEventTap)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.75) { [weak self] in
                DiagnosticLog.shared.write("self probe result received=\(self?.probeReceived ?? false)")
            }
        }
    }

    private func startGestureTap() {
        guard gestureTap == nil else { return }
        let gestureMask = CGEventMask(1 << NSEvent.EventType.gesture.rawValue)
        let context = Unmanaged.passUnretained(self).toOpaque()
        gestureTap = CGEvent.tapCreate(
            tap: .cgSessionEventTap,
            place: .tailAppendEventTap,
            options: .listenOnly,
            eventsOfInterest: gestureMask,
            callback: eventTapCallback,
            userInfo: context
        )
        if let gestureTap {
            gestureSource = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, gestureTap, 0)
            CFRunLoopAddSource(CFRunLoopGetMain(), gestureSource, .commonModes)
            CGEvent.tapEnable(tap: gestureTap, enable: true)
            DiagnosticLog.shared.write("gesture event tap created")
        } else {
            DiagnosticLog.shared.write("gesture event tap creation FAILED")
        }
    }

    func stop() {
        horizontalMapper.reset()
        if let tap { CGEvent.tapEnable(tap: tap, enable: false) }
        if let gestureTap { CGEvent.tapEnable(tap: gestureTap, enable: false) }
        if let source { CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes) }
        if let gestureSource { CFRunLoopRemoveSource(CFRunLoopGetMain(), gestureSource, .commonModes) }
        tap = nil
        source = nil
        gestureTap = nil
        gestureSource = nil
    }

    func handle(type: CGEventType, event: CGEvent) -> Unmanaged<CGEvent>? {
        if event.getIntegerValueField(.eventSourceUserData) == Self.probeMarker {
            probeReceived = true
            DiagnosticLog.shared.writeEvent("self probe callback type=\(type.rawValue)")
            return nil
        }
        if type.rawValue == UInt32.max - 1 || type.rawValue == UInt32.max {
            DiagnosticLog.shared.write("event tap disabled callback type=\(type.rawValue); re-enabling")
            if let tap { CGEvent.tapEnable(tap: tap, enable: true) }
            return Unmanaged.passUnretained(event)
        }
        // Synthetic clicks must not trigger trackpad actions or be remapped
        // again (especially when a button is mapped to middle click).
        if event.getIntegerValueField(.eventSourceUserData) == ShortcutExecutor.injectedMarker {
            DiagnosticLog.shared.writeEvent("shortcut observed type=\(type.rawValue) flags=\(event.flags.rawValue)")
            return Unmanaged.passUnretained(event)
        }
        guard enabledProvider() else {
            horizontalMapper.reset()
            return Unmanaged.passUnretained(event)
        }
        let config = configProvider()

        if type == .leftMouseDown || type == .rightMouseDown {
            // Finger contact alone cannot identify which device was clicked.
            // Unknown/synthetic sources must not consume an armed trackpad gesture.
            let source = config.trackpadGestureEnabled ? clickSourceProvider(event) : .unknown
            if source == .trackpad && trackpadClickHandler() {
                DiagnosticLog.shared.writeEvent("trackpad physical click gesture triggered")
            }
            DiagnosticLog.shared.writeEvent("physical click source=\(source.rawValue)")
            // Preserve the physical click. The configured shortcut is an
            // additional action, matching TapBind's behavior.
            return Unmanaged.passUnretained(event)
        }

        if type.rawValue == UInt32(NSEvent.EventType.gesture.rawValue) {
            if let nsEvent = NSEvent(cgEvent: event) {
                let count = nsEvent.touches(matching: .touching, in: nil).count
                if count >= 2 {
                    touchingCount = max(touchingCount, count)
                    lastTouchTime = uptime()
                }
            }
            return Unmanaged.passUnretained(event)
        }

        if type == .scrollWheel {
            scrollEventCount += 1
            reportActivity()
            let continuous = event.getIntegerValueField(.scrollWheelEventIsContinuous) != 0
            let now = uptime()
            let touchElapsed = now - lastTouchTime
            let touches = touchingCount
            touchingCount = 0
            let phase = NSEvent(cgEvent: event)?.momentumPhase ?? []
            let isMouse: Bool
            if gestureTap == nil {
                // M750 produces discrete wheel events. Without Input Monitoring,
                // leave continuous trackpad/Magic Mouse events untouched.
                isMouse = !continuous
            } else if !continuous {
                isMouse = true
            } else if touches >= 2 && touchElapsed < 0.222 {
                isMouse = false
            } else if phase.isEmpty && touchElapsed > 0.333 {
                isMouse = true
            } else {
                isMouse = lastScrollWasMouse
            }
            lastScrollWasMouse = isMouse
            DiagnosticLog.shared.writeEvent(
                "scroll #\(scrollEventCount) continuous=\(continuous) isMouse=\(isMouse) phase=\(phase.rawValue) " +
                "axis1=\(event.getIntegerValueField(.scrollWheelEventDeltaAxis1)) " +
                "point1=\(event.getIntegerValueField(.scrollWheelEventPointDeltaAxis1)) " +
                "fixed1=\(event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis1)) " +
                "reverseV=\(config.reverseVerticalScroll) reverseH=\(config.reverseHorizontalScroll)"
            )
            if isMouse {
                if mapHorizontalScroll(event, config: config, now: now) { return nil }
                transformScrollInPlace(event, config: config, continuous: continuous)
            }
            return Unmanaged.passUnretained(event)
        }

        if type == .keyDown || type == .keyUp {
            return Unmanaged.passUnretained(event)
        }

        let button = event.getIntegerValueField(.mouseEventButtonNumber)
        if type == .otherMouseDown {
            buttonEventCount += 1
            reportActivity()
        }
        let action: String
        switch button {
        case 2: action = config.middleAction
        case 3: action = config.backAction
        case 4: action = config.forwardAction
        default: return Unmanaged.passUnretained(event)
        }
        DiagnosticLog.shared.writeEvent("mouse button type=\(type.rawValue) button=\(button) action=\(action.isEmpty ? "<passthrough>" : action)")
        guard !action.isEmpty else { return Unmanaged.passUnretained(event) }
        if type == .otherMouseDown { actionExecutor(action, event.location) }
        return nil
    }

    /// Consume only the mapped X axis. Preserve Y/Z in diagonal wheel events.
    private func mapHorizontalScroll(_ event: CGEvent, config: AppConfig, now: Double) -> Bool {
        let fixed = event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis2)
        let point = event.getIntegerValueField(.scrollWheelEventPointDeltaAxis2)
        let axis = event.getIntegerValueField(.scrollWheelEventDeltaAxis2)
        let delta = fixed != 0 ? fixed : (point != 0 ? Double(point) : Double(axis))
        guard let decision = horizontalMapper.process(delta: delta, config: config, now: now) else { return false }
        if let direction = decision.verticalDirection {
            Self.redirectHorizontalScrollToVertical(event, multiplier: Int64(direction) * (delta > 0 ? 1 : -1))
            return false // Continue through the ordinary main-wheel settings.
        }
        if let action = decision.action { actionExecutor(action, event.location) }
        event.setIntegerValueField(.scrollWheelEventDeltaAxis2, value: 0)
        event.setIntegerValueField(.scrollWheelEventPointDeltaAxis2, value: 0)
        event.setDoubleValueField(.scrollWheelEventFixedPtDeltaAxis2, value: 0)
        let spi = HIDEventBridge.shared
        if let hid = spi.copyHIDEvent(from: event) {
            spi.setFloatValue(hid, field: ioHIDEventFieldScrollX, value: 0)
            spi.releaseHIDEvent(hid)
        }
        DiagnosticLog.shared.writeEvent("horizontal mapping delta=\(delta) action=\(decision.action ?? "<suppressed>")")
        return event.getIntegerValueField(.scrollWheelEventDeltaAxis1) == 0
            && event.getIntegerValueField(.scrollWheelEventPointDeltaAxis1) == 0
            && event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis1) == 0
            && event.getIntegerValueField(.scrollWheelEventDeltaAxis3) == 0
            && event.getIntegerValueField(.scrollWheelEventPointDeltaAxis3) == 0
            && event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis3) == 0
    }

    /// Move the original X distance into Y in the same units, keeping existing Y/Z.
    /// No synthetic key presses, guessed line/pixel ratio, or action cooldown.
    static func redirectHorizontalScrollToVertical(_ event: CGEvent, multiplier: Int64) {
        let line = event.getIntegerValueField(.scrollWheelEventDeltaAxis1)
            + multiplier * event.getIntegerValueField(.scrollWheelEventDeltaAxis2)
        let point = event.getIntegerValueField(.scrollWheelEventPointDeltaAxis1)
            + multiplier * event.getIntegerValueField(.scrollWheelEventPointDeltaAxis2)
        let fixed = event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis1)
            + Double(multiplier) * event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis2)
        let spi = HIDEventBridge.shared
        let hid = spi.copyHIDEvent(from: event)
        defer { if let hid { spi.releaseHIDEvent(hid) } }
        let hidX = hid.flatMap { spi.floatValue($0, field: ioHIDEventFieldScrollX) } ?? 0
        let hidY = hid.flatMap { spi.floatValue($0, field: ioHIDEventFieldScrollY) } ?? 0
        event.setIntegerValueField(.scrollWheelEventDeltaAxis2, value: 0)
        event.setIntegerValueField(.scrollWheelEventPointDeltaAxis2, value: 0)
        event.setDoubleValueField(.scrollWheelEventFixedPtDeltaAxis2, value: 0)
        event.setIntegerValueField(.scrollWheelEventDeltaAxis1, value: line)
        // Keep the most precise encoding authoritative for the original event unit.
        if event.getIntegerValueField(.scrollWheelEventIsContinuous) != 0 {
            event.setDoubleValueField(.scrollWheelEventFixedPtDeltaAxis1, value: fixed)
            event.setIntegerValueField(.scrollWheelEventPointDeltaAxis1, value: point)
        } else {
            event.setIntegerValueField(.scrollWheelEventPointDeltaAxis1, value: point)
            event.setDoubleValueField(.scrollWheelEventFixedPtDeltaAxis1, value: fixed)
        }
        if let hid {
            spi.setFloatValue(hid, field: ioHIDEventFieldScrollX, value: 0)
            spi.setFloatValue(hid, field: ioHIDEventFieldScrollY, value: hidY + Double(multiplier) * hidX)
        }
    }

    private func transformScrollInPlace(_ event: CGEvent, config: AppConfig, continuous: Bool) {
        guard config.reverseVerticalScroll || config.reverseHorizontalScroll || config.scrollLines > 0 else { return }
        let spi = HIDEventBridge.shared
        let hidEvent = (config.reverseVerticalScroll || config.reverseHorizontalScroll) ? spi.copyHIDEvent(from: event) : nil
        defer { if let hidEvent { spi.releaseHIDEvent(hidEvent) } }
        let beforeAxis1 = event.getIntegerValueField(.scrollWheelEventDeltaAxis1)
        let beforePoint1 = event.getIntegerValueField(.scrollWheelEventPointDeltaAxis1)
        let beforeFixed1 = event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis1)
        let beforeAxis2 = event.getIntegerValueField(.scrollWheelEventDeltaAxis2)
        let beforePoint2 = event.getIntegerValueField(.scrollWheelEventPointDeltaAxis2)
        let beforeFixed2 = event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis2)
        let beforeHIDY = hidEvent.flatMap { spi.floatValue($0, field: ioHIDEventFieldScrollY) }
        let beforeHIDX = hidEvent.flatMap { spi.floatValue($0, field: ioHIDEventFieldScrollX) }
        let vertical = ScrollTransform.vertical(
            axis: beforeAxis1,
            point: beforePoint1,
            fixed: beforeFixed1,
            continuous: continuous,
            reverse: config.reverseVerticalScroll,
            lines: config.scrollLines
        )
        if let vertical {
            event.setIntegerValueField(.scrollWheelEventDeltaAxis1, value: vertical.axis)
            if let fixed = vertical.fixed {
                event.setDoubleValueField(.scrollWheelEventFixedPtDeltaAxis1, value: fixed)
            }
            if let point = vertical.point {
                event.setIntegerValueField(.scrollWheelEventPointDeltaAxis1, value: point)
            }
            if !vertical.adjustsDiscreteStep, let hidEvent {
                spi.setFloatValue(hidEvent, field: ioHIDEventFieldScrollY, value: -(beforeHIDY ?? 0))
            }
        }
        if config.reverseHorizontalScroll {
            event.setIntegerValueField(
                .scrollWheelEventDeltaAxis2,
                value: -beforeAxis2
            )
            event.setDoubleValueField(
                .scrollWheelEventFixedPtDeltaAxis2,
                value: -beforeFixed2
            )
            event.setIntegerValueField(
                .scrollWheelEventPointDeltaAxis2,
                value: -beforePoint2
            )
            if let hidEvent {
                spi.setFloatValue(hidEvent, field: ioHIDEventFieldScrollX, value: -(beforeHIDX ?? 0))
            }
        }
        let afterHIDY = hidEvent.flatMap { spi.floatValue($0, field: ioHIDEventFieldScrollY) }
        DiagnosticLog.shared.writeEvent(
            "scroll transformed hid=\(hidEvent != nil) " +
            "axis1=\(beforeAxis1)->\(event.getIntegerValueField(.scrollWheelEventDeltaAxis1)) " +
            "point1=\(beforePoint1)->\(event.getIntegerValueField(.scrollWheelEventPointDeltaAxis1)) " +
            "fixed1=\(beforeFixed1)->\(event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis1)) " +
            "hidY=\(beforeHIDY.map { String($0) } ?? "nil")->\(afterHIDY.map { String($0) } ?? "nil") " +
            "scrollLines=\(config.scrollLines) discreteAdjusted=\(vertical?.adjustsDiscreteStep ?? false)"
        )
    }

    private func reportActivity() {
        guard DiagnosticLog.verboseEvents else { return }
        let scrolls = scrollEventCount
        let buttons = buttonEventCount
        DispatchQueue.main.async { [weak self] in self?.onActivity?(scrolls, buttons) }
    }
}

// Scroll Reverser also updates the IOHID payload underneath CGEvent. These SPI
// symbols are present in macOS but are not part of the public SDK.
private let ioHIDEventFieldScrollX: UInt32 = UInt32(6 << 16)
private let ioHIDEventFieldScrollY: UInt32 = UInt32(6 << 16) | 1


private let eventTapCallback: CGEventTapCallBack = { _, type, event, userInfo in
    guard let userInfo else { return Unmanaged.passUnretained(event) }
    return Unmanaged<EventTapController>.fromOpaque(userInfo).takeUnretainedValue().handle(type: type, event: event)
}
