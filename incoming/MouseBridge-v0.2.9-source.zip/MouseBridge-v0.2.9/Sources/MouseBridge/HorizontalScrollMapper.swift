// SPDX-License-Identifier: GPL-3.0-or-later
// Adapted from OpenLogi's per-direction discrete-action cooldown strategy.
// Copyright (c) 2026 AprilNEA. MIT license: LICENSES/OpenLogi-MIT.txt.
// See docs/OPENLOGI-REFERENCE.md for the pinned source and macOS adaptation.

import Foundation

struct HorizontalScrollMapper {
    struct Decision: Equatable {
        let action: String? // nil consumes the axis without sending a shortcut.
        var verticalDirection: Int? = nil // +1 up, -1 down; preserves the incoming distance.
    }
    static func isValidAction(_ action: String) -> Bool {
        verticalDirection(for: action) != nil || ShortcutExecutor.isValid(action)
    }

    private static func verticalDirection(for action: String) -> Int? {
        switch action.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
        case "scroll up": return 1
        case "scroll down": return -1
        default: return nil
        }
    }

    private struct Direction {
        var binding = ""
        var lastExecution: Double?

        mutating func process(action: String, now: Double) -> Decision? {
            if binding != action { binding = action; lastExecution = nil }
            // Like OpenLogi's scroll bindings, scrolling tracks every packet and
            // its distance; only discrete keyboard/click actions use a cooldown.
            if let direction = HorizontalScrollMapper.verticalDirection(for: action) {
                lastExecution = nil
                return Decision(action: nil, verticalDirection: direction)
            }
            guard !action.isEmpty, ShortcutExecutor.isValid(action) else { return nil }
            guard action != "none" else { lastExecution = nil; return Decision(action: nil) }
            // OpenLogi's ACTION_COOLDOWN: each direction has its own 200 ms gate.
            if let lastExecution, now >= lastExecution, now - lastExecution < 0.2 {
                return Decision(action: nil)
            }
            lastExecution = now
            return Decision(action: action)
        }
    }
    private var left = Direction()
    private var right = Direction()
    private var bindings: [String] = []

    mutating func reset() { left = Direction(); right = Direction(); bindings = [] }

    mutating func process(delta: Double, config: AppConfig, now: Double) -> Decision? {
        let current = [config.horizontalLeftAction, config.horizontalRightAction]
        if current != bindings { reset(); bindings = current }
        guard delta.isFinite, delta != 0 else { return nil }
        // CoreGraphics positive X is scroll-left, unlike OpenLogi's abstract X.
        return delta > 0 ? left.process(action: config.horizontalLeftAction, now: now)
            : right.process(action: config.horizontalRightAction, now: now)
    }
}
