# MouseBridge for macOS

English | [简体中文](README.zh-CN.md)

MouseBridge is a GPL-3.0-or-later native macOS foundation for mouse button
mapping, trackpad multi-finger shortcuts, mouse-only wheel control, and
Logitech HID++ hardware DPI configuration. It was created for people who only
need a few input features and do not want to keep a large vendor suite running
in the background.

The project deliberately exposes useful low-level capabilities through a small
AppKit UI, a versioned JSON file, and a CLI. This makes it practical for users,
scripts, and coding agents such as Codex to extend without first replacing a
large framework.

[Download the latest release](https://github.com/gmch1/mousebridge-releases/releases)

## Settings preview

<p align="center">
  <img src="docs/images/settings-mouse.png" alt="MouseBridge interactive mouse diagram and button bindings" width="640">
</p>

Settings are grouped into Mouse, Trackpad and General pages. Inspired by
[OpenLogi](https://github.com/AprilNEA/OpenLogi), the mouse schematic selects button
and thumb-wheel editors, with paired presets and custom shortcuts. The menu keeps status, Settings, Pause, Check for
Updates and Quit; permission details and automatic updates live in General.
[Horizontal wheel](docs/images/settings-horizontal.png) · [Pointer settings](docs/images/settings-pointer.png) · [Trackpad settings](docs/images/settings-trackpad.png) · [General settings](docs/images/settings-general.png) · [Dark mode](docs/images/settings-general-dark.png)

## Project goals

- Stay small, native, understandable, and easy to modify.
- Provide reliable button, wheel, and hardware DPI primitives.
- Keep configuration local and automation-friendly.
- Make support for another mouse start with a device profile instead of a UI
  rewrite.
- Avoid accounts, cloud services, telemetry, and Electron, Qt, or Python
  runtimes.

MouseBridge is not intended to reproduce every feature in Logitech Options+.
Beyond its focused multi-finger trackpad binding, it currently does not manage
gesture sequences, per-application profiles, Flow, firmware updates, battery
reporting, or Logitech cameras and keyboards.

## Current features

- Map middle, back, and forward buttons to shortcuts such as `cmd+r`.
- Combine modifiers with `left click`, `right click`, or `middle click`. For example,
  map the middle button to `cmd+left click` to Command-click links, usually opening
  a background tab (depending on browser settings).
- Disable a button with `none`, or leave it empty to pass it through.
- Map a 2–5-finger trackpad physical click to any supported shortcut, with an
  optional short-tap trigger and exact/at-least finger matching.
- Reverse vertical and horizontal mouse scrolling without changing trackpad
  scrolling.
- Set a discrete-wheel amount from 0–20 (`0` keeps the macOS default).
- Query DPI values reported by Logitech HID++ feature `0x2201` and select them
  through a 0–100% slider.
- Show mouse connection and privacy-permission status, with direct links to the
  Accessibility and Input Monitoring settings panes.
- Pause and resume all mappings from the menu bar without quitting the app.
- Reload JSON configuration after scripts or coding agents edit it.
- Start at login through `SMAppService`.
- Check for updates from the menu bar or automatically once a day using Sparkle.
  Downloads and the update feed are signed; installation requires your confirmation.
- Write local diagnostics to `~/Library/Logs/MouseBridge.log`.

## Tested hardware and environment

The following Bluetooth profiles have physical-device coverage on Apple silicon:

| Mouse | VID / PID | Device-reported DPI | Environment | Verified behavior |
| --- | --- | --- | --- | --- |
| Logitech Signature Plus M750 L | `046D:B02C` | 400–4000, step 100 (37 values) | macOS 26.5.2, MouseBridge 0.2.0 | Discovery, side buttons, vertical scroll reversal, DPI read/write |
| Logitech MX Master 3S | `046D:B034` | 200–8000, step 50 (157 values) | macOS 26.6.2, MouseBridge 0.2.3 | Discovery, DPI capabilities, 3000-DPI write and readback |

M750 retains its existing transport, but has not been physically retested with
0.2.3. MX Master 3S button and wheel actions have not all been manually exercised.
The app manages one supported mouse at a time. Bolt receivers, Intel Macs, other
mouse models and every supported macOS release have not been validated. Please
include the product name, connection type, VID/PID, macOS version and diagnostic
log when reporting compatibility results.

## Permissions

Accessibility permission is required to intercept mouse buttons, modify scroll
events, and post shortcuts. It is also required for the trackpad binding to post
its shortcut. Input Monitoring is strongly recommended for reliable
mouse-versus-trackpad scroll classification and was enabled in the tested
environment. macOS requires the user to approve privacy permissions manually;
an application cannot silently grant them to itself.

The settings window links directly to the relevant System Settings panes.

## Installation

Users of 0.2.4 or earlier must install 0.2.5 manually once to enable in-app updates.

Download the ZIP from [GitHub Releases](https://github.com/gmch1/mousebridge-releases/releases),
extract it, and move `MouseBridge.app` to `/Applications`.

Releases labeled **Pre-release** are ad-hoc signed and may require manual
Gatekeeper approval. Developer ID signed and notarized builds are published as
regular releases.

## Development (contributors)

```bash
zsh build-app.sh
open dist/MouseBridge.app
```

The build script uses `/Applications/Xcode.app` when available, runs XCTest and
the binary self-test, builds a release executable, and assembles the app bundle.
Its default ad-hoc signature is intended only for local contributor builds.

For a Developer ID build:

```bash
SIGN_IDENTITY="Developer ID Application: Example (TEAMID)" \
VERSION=0.2.1 BUILD_NUMBER=2 zsh build-app.sh
NOTARY_PROFILE=mousebridge-notary zsh scripts/notarize.sh
```

## Release maintenance

Pushing a semantic version tag such as `v0.2.1` verifies that the tag matches
`Info.plist`, runs all tests, builds the app, creates a ZIP and SHA-256 checksum,
and publishes a GitHub Release. Without Apple signing secrets, the workflow
publishes an explicitly labeled pre-release.

See [docs/RELEASING.md](docs/RELEASING.md) for the complete procedure.

## Configuration and CLI

Configuration is stored at:

```text
~/Library/Application Support/MouseBridge/config.json
```

```bash
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config get
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set middle "cmd+left click"
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set back cmd+r
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set trackpad-enabled true
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set trackpad-fingers 3
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set trackpad-action cmd+w
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set scroll-lines 4
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set dpi 1200
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge launch-at-login status
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge launch-at-login enable
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge diagnose
```

An already-running app watches the configuration directory and applies valid
external changes automatically.

Alternatively, choose the background-link preset under Mouse → Middle Button, then save.
Quote actions containing spaces on the command line. This mapping applies in every
app; choose the default behavior to restore the native middle button. Click actions send one
click, not a hold or drag. Background opening depends on the browser and webpage.
In Safari's Tabs settings, enable “⌘-click opens a link in a new tab” and disable
“When a new tab or window opens, make it active.”

## MX Master horizontal thumb wheel

Select the ↔ hotspot on the Mouse page. Choose the vertical-scrolling preset to
use the side wheel like the main wheel; a reversed preset and Swap are available.
This preserves the incoming distance, follows main-wheel reversal/line settings,
and bypasses the discrete-action cooldown. Other paired presets cover tabs, browser
history, undo/redo, desktops and zoom. Custom mode assigns each direction a
shortcut, click, native behavior or disabled action; Swap exchanges the bindings.
Click Save and Apply when finished.

```bash
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set horizontal-left 'ctrl+shift+tab'
/Applications/MouseBridge.app/Contents/MacOS/MouseBridge config set horizontal-right 'ctrl+tab'
```

For vertical scrolling via CLI, set `horizontal-left` to `"scroll up"` and
`horizontal-right` to `"scroll down"`. These actions are specific to wheel bindings.

Schema 4 migration preserves native horizontal scrolling by default. Directions
follow delivered macOS X-axis scroll events; Natural Scrolling may change their
physical interpretation. Horizontal reversal applies only to unbound scrolling.
Keyboard/click actions have a 200 ms cooldown per direction. Bindings also affect other horizontal/tilt
mouse wheels, without per-device profiles. Continuous devices require Input
Monitoring; the existing trackpad classifier is retained. Synthetic-event tests
pass in CI; physical MX Master wheel behavior still needs validation. See
[OpenLogi reference and adaptation notes](docs/OPENLOGI-REFERENCE.md).

## Architecture and extension points

- `AppConfig` and `ConfigStore`: versioned JSON, validation, atomic writes, and
  directory watching.
- `EventTapController`: button interception, source classification, and wheel
  transformation.
- `MultitouchController` and `MultitouchGestureRecognizer`: native private-
  framework device callbacks plus an allocation-free, independently tested
  gesture state machine. No device callback stays registered while the feature
  is disabled or MouseBridge is paused.
- `ScrollTransform`: pure and tested discrete-scroll calculations.
- `ShortcutExecutor`: compact shortcut parser and Quartz event injection.
- `HIDPPController`: profile-based IOKit transport, DPI discovery, serialized
  requests, disconnect-safe cleanup, and best-effort DPI restoration.
- `SettingsWindowController`: small AppKit configuration UI.
- `CommandLineInterface`: automation surface for scripts and coding agents.

Adding a device begins with `MouseDeviceProfile`; the transport layer does not
need to know the product's marketing name.

## Open-source foundations

MouseBridge builds on interoperability knowledge and implementation patterns
from:

- [OpenLogi](https://github.com/AprilNEA/OpenLogi) (MIT): mouse-control interaction,
  paired thumb-wheel presets and independent direction cooldowns.
- [Scroll Reverser](https://github.com/pilotmoon/Scroll-Reverser) (Apache-2.0):
  its public implementation helped explain trackpad/mouse gesture timing and
  why reliable reversal updates both Quartz and the underlying IOHID scroll
  payload.
- [Solaar](https://github.com/pwr-Solaar/Solaar) (GPL-2.0-or-later): its HID++
  adjustable-DPI list decoding informed the corresponding MouseBridge logic.
- [TapBind](https://github.com/gmch1/TapBind), derived from
  [MiddleClick](https://github.com/artginzburg/MiddleClick) (GPL-3.0): its
  MultitouchSupport declarations and behavior informed MouseBridge's separately
  implemented configurable trackpad state machine.

The combined MouseBridge work is distributed under GPL-3.0-or-later. Original
third-party portions retain their notices and license history. See
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) and [LICENSES](LICENSES/).

## Compatibility and distribution note

For reliable scroll reversal, MouseBridge dynamically loads the private IOHID
bridge also documented by Scroll Reverser. Multi-finger contact counts use
Apple's private MultitouchSupport framework. The scroll path falls back to
public Quartz fields when its private symbols are unavailable; multi-finger
bindings are unavailable if MultitouchSupport changes incompatibly. Because
private API behavior can change between macOS releases, both paths need
regression testing on new macOS versions. This also makes direct distribution
more appropriate than the Mac App Store.

## License

MouseBridge is free software distributed under
[GPL-3.0-or-later](LICENSE). Corresponding source is available in this
repository and with each GitHub Release. See [SOURCE.md](SOURCE.md).

## MX Master 3S Bluetooth support (0.2.3)

This build adds the MX Master 3S profile (`046D:B034`) with HID++ output-element
transport, keeping the existing M750 transport. DPI selection follows the values
reported by the device; configuration accepts 100–8000 DPI and writes are checked
by reading back the sensor. Schema 3 settings and trackpad features are preserved.

`MouseBridge device status` queries hardware without loading/saving configuration
or writing/restoring DPI. macOS may attribute a CLI invocation to its terminal or
automation host: that host's Input Monitoring permission is separate from the GUI
app's permission. If CLI access is denied, the GUI's confirmed apply result and
local diagnostic log remain available; no additional permission is needed to use
the already-authorized GUI app.

Protocol behavior was cross-checked against [Solaar](https://github.com/pwr-Solaar/Solaar)
and the macOS BLE transport in [Lazy Mouse](https://github.com/RRY/lazy-mouse).
Neither project is installed or required at runtime.
