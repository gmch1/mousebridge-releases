# Changelog

## 0.2.9 — 2026-11-01

- Label the native mouse button action as “默认行为（不设置）” to make
  clearing a shortcut mapping easier to find.
- Explain the difference between preserving the original button action and
  disabling the button in the middle and side button settings.

## 0.2.8 — 2026-10-30

- Prevent external mouse clicks from triggering trackpad multi-finger shortcuts
  while fingers rest on the trackpad. Resolve click origin using the HID sender
  and device identity, following OpenLogi's implementation. Unknown sources pass
  through without consuming the armed trackpad gesture.
- Preserve successfully loaded settings when the startup configuration rewrite
  fails. Distinguish write/read errors from malformed JSON; only malformed JSON
  is moved to a corrupt-config backup.
- Include the OpenLogi MIT license in the application bundle.

- Validation: 47 macOS XCTest cases and 13 publication tests pass. Built-in and
  external trackpad click attribution still needs hardware regression testing.

## 0.2.7 — 2026-10-30

- Add normal and reversed vertical-scrolling presets for the horizontal thumb
  wheel, with per-direction scroll actions in the custom editor and CLI.
- Preserve wheel distance and event units while moving X into Y, without the
  shortcut cooldown; apply the existing main-wheel reversal and line settings.

- Validation: 41 macOS XCTest cases and 13 publication tests pass. Physical
  MX Master wheel behavior still needs validation on real hardware.

## 0.2.6 — 2026-10-30

- Add an interactive mouse schematic with selectable middle/side buttons and
  a horizontal thumb-wheel editor, referencing OpenLogi's control-selection UI.
- Add paired horizontal-wheel presets (tabs, browser history, undo/redo,
  desktops and zoom), per-direction custom shortcuts and a swap action.
- Map mouse X-axis scroll events with independent 200 ms direction cooldowns;
  preserve unbound native scrolling, vertical deltas and existing trackpad filtering.
- Migrate to config schema 4 with native horizontal scrolling as the default;
  add `horizontal-left` and `horizontal-right` CLI configuration keys.

- Group settings into Mouse, Trackpad and General pages with native cards,
  scrollable content and a resizable window.
- Offer readable action presets while preserving custom shortcut strings.
- Simplify the menu to device status, Settings, Pause, Check for Updates and Quit;
  move automatic update preferences, permission details and About into General.
- Open General on first settings access when Accessibility permission is missing.

- Validation: 35 macOS XCTest cases and 13 publication tests pass. Physical
  MX Master thumb-wheel behavior still needs validation on real hardware.

## 0.2.5 — 2026-10-29

- Integrate Sparkle 2.9.4 with menu-bar update checks and a daily automatic-check
  toggle. Installation uses Sparkle's download, signature verification and restart UI.
- Bundle and sign the updater framework and helpers, and verify signed update
  archives and feeds in CI.
- Publish verified update archives and a signed rolling feed through the public
  download repository, without exposing credentials or private repository history.
- Use version-derived build numbers so update ordering is stable across workflow reruns.

## 0.2.4 — 2026-10-29

- Support modifier-click actions such as `cmd+left click` for opening browser links
  in background tabs, plus right and middle clicks.
- Preserve the triggering mouse position and prevent injected clicks from
  triggering trackpad gestures or being remapped recursively.
- Share shortcut validation and execution parsing, accept whitespace around `+`,
  and reject empty shortcut components.

## 0.2.3 — 2026-10-28

- Add MX Master 3S Bluetooth (`046D:B034`) discovery and HID++ output-element transport.
- Use device-reported DPI steps, allow configurations up to 8000 DPI, and confirm writes by reading the sensor back.
- Show the connected mouse name and the confirmed DPI; preserve the M750 transport and existing trackpad settings.
- Add `MouseBridge device status`, which reads hardware without loading or rewriting configuration and uses a separate HID++ client ID.
- Retry transient Bluetooth handshakes and isolate requests and UI results across reconnections.
- Reject malformed DPI ranges and decode multi-page lists without including report padding.
- Refresh confirmed DPI in the settings slider and allow retrying an unchanged setting.

## 0.2.2 — 2026-10-18

- Add configurable 2–5-finger trackpad shortcut mapping for physical clicks
  and optional taps.
- Add native MultitouchSupport device handling with an allocation-free frame
  callback and no active listener while the feature is disabled or paused.
- Create the AppKit settings window lazily on first use instead of retaining
  all controls for the entire menu-bar session.
- Add schema-v3 JSON fields, CLI controls, AppKit settings, and gesture-state
  tests for the trackpad feature.

## 0.2.1 — 2026-07-12

- Relicense the combined project under GPL-3.0-or-later.
- Record Scroll Reverser and Solaar provenance without absolute non-copying claims.
- Bundle GPL, Apache, upstream NOTICE, and corresponding-source information in the app.

## 0.2.0 — 2026-07-12

First public preview of MouseBridge.

- Native AppKit menu-bar application for macOS 13 and newer.
- Logitech Signature Plus M750 L support over Bluetooth.
- Middle, back, and forward button shortcut mapping.
- Mouse-only vertical and horizontal scroll reversal.
- Configurable scroll amount from system default through 20 lines.
- Device-reported hardware DPI range and 0–100% DPI slider.
- Versioned JSON configuration, live reload, diagnostics, and CLI controls.
- Accessibility and Input Monitoring permission diagnostics.
- Login-at-launch support through `SMAppService`.
- XCTest coverage, warning-clean release builds, and automated release packaging.
