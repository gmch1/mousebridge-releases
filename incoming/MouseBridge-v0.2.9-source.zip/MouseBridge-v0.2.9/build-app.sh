#!/bin/zsh
set -eu

ROOT=${0:A:h}
APP="$ROOT/dist/MouseBridge.app"
CONTENTS="$APP/Contents"
VERSION=${VERSION:-$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$ROOT/Info.plist")}
BUILD_NUMBER=${BUILD_NUMBER:-$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$ROOT/Info.plist")}
SIGN_IDENTITY=${SIGN_IDENTITY:--}
export SWIFTPM_MODULECACHE_OVERRIDE="$ROOT/.module-cache"
export CLANG_MODULE_CACHE_PATH="$ROOT/.module-cache"

if [[ -n ${DEVELOPER_DIR:-} ]]; then
    SWIFT_BIN=$(xcrun --find swift)
elif [[ -d /Applications/Xcode.app/Contents/Developer ]]; then
    export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
    unset SDKROOT
    SWIFT_BIN=$(xcrun --find swift)
else
    SWIFT_BIN=$(command -v swift)
    COMPAT_SDK=/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk
    [[ -d "$COMPAT_SDK" ]] && export SDKROOT="$COMPAT_SDK"
fi

"$SWIFT_BIN" test --disable-sandbox --package-path "$ROOT"
"$SWIFT_BIN" build -c release --disable-sandbox --package-path "$ROOT"
"$ROOT/.build/release/MouseBridge" --self-test
rm -rf "$APP"
mkdir -p "$CONTENTS/MacOS" "$CONTENTS/Resources/Legal"
cp "$ROOT/.build/release/MouseBridge" "$CONTENTS/MacOS/MouseBridge"
sparkle_frameworks=("$ROOT"/.build/artifacts/**/Sparkle.framework(N/))
if (( ${#sparkle_frameworks} != 1 )); then
    echo "Expected one Sparkle.framework in SwiftPM artifacts" >&2
    exit 1
fi
mkdir -p "$CONTENTS/Frameworks"
ditto "$sparkle_frameworks[1]" "$CONTENTS/Frameworks/Sparkle.framework"
cp "$ROOT/Info.plist" "$CONTENTS/Info.plist"
cp "$ROOT/LICENSE" "$CONTENTS/Resources/Legal/GPL-3.0.txt"
cp "$ROOT/COPYRIGHT" "$CONTENTS/Resources/Legal/COPYRIGHT"
cp "$ROOT/THIRD_PARTY_NOTICES.md" "$CONTENTS/Resources/Legal/THIRD_PARTY_NOTICES.md"
cp "$ROOT/SOURCE.md" "$CONTENTS/Resources/Legal/SOURCE.md"
cp "$ROOT/LICENSES/Apache-2.0.txt" "$CONTENTS/Resources/Legal/Apache-2.0.txt"
cp "$ROOT/LICENSES/GPL-2.0.txt" "$CONTENTS/Resources/Legal/GPL-2.0.txt"
cp "$ROOT/LICENSES/Scroll-Reverser-NOTICE.txt" "$CONTENTS/Resources/Legal/Scroll-Reverser-NOTICE.txt"
cp "$ROOT/LICENSES/Sparkle.txt" "$CONTENTS/Resources/Legal/Sparkle.txt"
cp "$ROOT/LICENSES/OpenLogi-MIT.txt" "$CONTENTS/Resources/Legal/OpenLogi-MIT.txt"
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $VERSION" "$CONTENTS/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $BUILD_NUMBER" "$CONTENTS/Info.plist"

# Sign nested code from the inside out, then sign the containing app. Keep
# Downloader's entitlements if Sparkle changes them in a future release.
sparkle="$CONTENTS/Frameworks/Sparkle.framework/Versions/B"
nested_signing=(--force --sign "$SIGN_IDENTITY")
if [[ "$SIGN_IDENTITY" != "-" ]]; then
    nested_signing+=(--options runtime --timestamp)
fi
codesign "${nested_signing[@]}" "$sparkle/XPCServices/Installer.xpc"
codesign "${nested_signing[@]}" --preserve-metadata=entitlements "$sparkle/XPCServices/Downloader.xpc"
codesign "${nested_signing[@]}" "$sparkle/Autoupdate"
codesign "${nested_signing[@]}" "$sparkle/Updater.app"
codesign "${nested_signing[@]}" "$CONTENTS/Frameworks/Sparkle.framework"

if [[ "$SIGN_IDENTITY" == "-" ]]; then
    # Development only. A stable local requirement prevents every rebuild from
    # creating a new TCC identity, but is not suitable for distribution.
    codesign --force --sign - \
        --identifier io.github.mousebridge.macos \
        --requirements '=designated => identifier "io.github.mousebridge.macos"' \
        "$APP"
else
    codesign --force --options runtime --timestamp \
        --identifier io.github.mousebridge.macos \
        --sign "$SIGN_IDENTITY" \
        "$APP"
fi
codesign --verify --deep --strict "$APP"
# Verify the packaged executable resolves Sparkle from the app bundle too.
"$CONTENTS/MacOS/MouseBridge" --self-test
echo "$APP"
