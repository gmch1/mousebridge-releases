// SPDX-License-Identifier: GPL-3.0-or-later

import XCTest
@testable import MouseBridge

final class ConfigTests: XCTestCase {
    func testDPIClampsToSupportedConfigurationRange() {
        XCTAssertEqual(AppConfig.clampDPI(0), 100)
        XCTAssertEqual(AppConfig.clampDPI(100), 100)
        XCTAssertEqual(AppConfig.clampDPI(1200), 1200)
        XCTAssertEqual(AppConfig.clampDPI(8000), 8000)
        XCTAssertEqual(AppConfig.clampDPI(9000), 8000)
    }

    func testShortcutValidation() {
        XCTAssertTrue(ShortcutExecutor.isValid("cmd+r"))
        XCTAssertTrue(ShortcutExecutor.isValid("shift+cmd+z"))
        XCTAssertTrue(ShortcutExecutor.isValid("none"))
        XCTAssertTrue(ShortcutExecutor.isValid(""))
        XCTAssertFalse(ShortcutExecutor.isValid("cmd+not-a-key"))
    }

    func testConfigNormalization() {
        let config = AppConfig(
            backAction: " CMD+R ",
            scrollLines: 99,
            primaryDPI: 9999,
            trackpadFingerCount: 9,
            trackpadAction: " CMD+W ",
            trackpadTapMaxMilliseconds: 5,
            trackpadTapMaxMovement: 2
        )
        XCTAssertEqual(config.backAction, "cmd+r")
        XCTAssertEqual(config.primaryDPI, 8000)
        XCTAssertEqual(config.scrollLines, 20)
        XCTAssertEqual(config.trackpadFingerCount, 5)
        XCTAssertEqual(config.trackpadAction, "cmd+w")
        XCTAssertEqual(config.trackpadTapMaxMilliseconds, 50)
        XCTAssertEqual(config.trackpadTapMaxMovement, 0.5)
    }

    func testLegacyConfigMigratesWithDefaults() throws {
        let data = Data(#"{"backAction":" CMD+R ","primaryDPI":1200,"secondaryDPI":400,"dpiButtonAction":"dpi:cycle"}"#.utf8)
        let config = try JSONDecoder().decode(AppConfig.self, from: data)
        XCTAssertEqual(config.schemaVersion, AppConfig.currentSchemaVersion)
        XCTAssertEqual(config.backAction, "cmd+r")
        XCTAssertEqual(config.primaryDPI, 1200)
        XCTAssertEqual(config.scrollLines, 0)
        XCTAssertFalse(config.trackpadGestureEnabled)
        XCTAssertEqual(config.trackpadFingerCount, 3)
        XCTAssertEqual(config.trackpadAction, "cmd+w")
    }

    func testThreeFingerTapTriggers() {
        let recognizer = MultitouchGestureRecognizer(settings: trackpadSettings())
        XCTAssertFalse(recognizer.processFrame(points: points(3, x: 0.2), timestamp: 10))
        XCTAssertFalse(recognizer.processFrame(points: points(3, x: 0.205), timestamp: 10.1))
        XCTAssertTrue(recognizer.processFrame(points: [], timestamp: 10.2))
    }

    func testTapRejectsMovementTimeoutAndExtraFinger() {
        var recognizer = MultitouchGestureRecognizer(settings: trackpadSettings())
        XCTAssertFalse(recognizer.processFrame(points: points(3, x: 0.2), timestamp: 10))
        XCTAssertFalse(recognizer.processFrame(points: points(3, x: 0.3), timestamp: 10.1))
        XCTAssertFalse(recognizer.processFrame(points: [], timestamp: 10.2))

        recognizer = MultitouchGestureRecognizer(settings: trackpadSettings())
        XCTAssertFalse(recognizer.processFrame(points: points(3, x: 0.2), timestamp: 20))
        XCTAssertFalse(recognizer.processFrame(points: [], timestamp: 20.31))

        recognizer = MultitouchGestureRecognizer(settings: trackpadSettings())
        XCTAssertFalse(recognizer.processFrame(points: points(3, x: 0.2), timestamp: 30))
        XCTAssertFalse(recognizer.processFrame(points: points(4, x: 0.2), timestamp: 30.1))
        XCTAssertFalse(recognizer.processFrame(points: [], timestamp: 30.2))
    }

    func testPhysicalClickTriggersOnceAndSuppressesTapDuplicate() {
        let recognizer = MultitouchGestureRecognizer(settings: trackpadSettings())
        XCTAssertFalse(recognizer.processFrame(points: points(3, x: 0.2), timestamp: 10))
        XCTAssertTrue(recognizer.isPhysicalClickArmed)
        XCTAssertTrue(recognizer.consumePhysicalClickIfArmed())
        XCTAssertFalse(recognizer.consumePhysicalClickIfArmed())
        XCTAssertFalse(recognizer.processFrame(points: [], timestamp: 10.1))
    }

    func testAllowMoreFingersArmsPhysicalClick() {
        var settings = trackpadSettings()
        settings.allowMoreFingers = true
        let recognizer = MultitouchGestureRecognizer(settings: settings)
        XCTAssertFalse(recognizer.processFrame(points: points(4, x: 0.2), timestamp: 10))
        XCTAssertTrue(recognizer.consumePhysicalClickIfArmed())
    }

    func testDPIRangeEncodingDecodes() {
        let values = HIDPPController.decodeDPIList([0x01, 0x90, 0xE0, 0x64, 0x0F, 0xA0, 0, 0])
        XCTAssertEqual(values.first, 400)
        XCTAssertEqual(values.last, 4000)
        XCTAssertEqual(values.count, 37)
    }

    func testMXMaster3SDPIRangeEncodingDecodes() {
        let values = HIDPPController.decodeDPIList([0x00, 0xC8, 0xE0, 0x32, 0x1F, 0x40, 0, 0])
        XCTAssertEqual(values, Array(stride(from: 200, through: 8000, by: 50)))
    }

    func testMXDPIAndTrackpadConfigRoundTrip() throws {
        for dpi in [100, 8000] {
            let original = AppConfig(
                primaryDPI: dpi,
                trackpadGestureEnabled: true,
                trackpadFingerCount: 4,
                trackpadAction: "cmd+w",
                trackpadTapEnabled: false
            )
            let decoded = try JSONDecoder().decode(AppConfig.self, from: original.prettyJSONData())
            XCTAssertEqual(decoded, original)
            XCTAssertEqual(decoded.schemaVersion, AppConfig.currentSchemaVersion)
        }
    }

    func testDPIPagePaddingDoesNotCorruptTheNextPage() {
        let first = HIDPPController.dpiPageEntries([0, 0, 200, 0, 250, 0x01, 0x2C, 0x01, 0x5E, 0x01, 0x90, 0x01, 0xC2, 0x01, 0xF4, 0])
        XCTAssertEqual(first?.count, 14)
        let next = HIDPPController.dpiPageEntries([0, 0x02, 0x26, 0, 0, 0])
        XCTAssertEqual(next, [0x02, 0x26, 0, 0])
        XCTAssertEqual(HIDPPController.decodeDPIList((first ?? []) + (next ?? [])),
                       Array(stride(from: 200, through: 550, by: 50)))
        XCTAssertNil(HIDPPController.dpiPageEntries([1, 0, 200]))
        XCTAssertNil(HIDPPController.dpiPageEntries([0]))
    }

    func testMalformedDPIRangesAreRejected() {
        XCTAssertEqual(HIDPPController.decodeDPIList([0, 200, 0xE0, 0, 0x1F, 0x40]), [])
        XCTAssertEqual(HIDPPController.decodeDPIList([0, 200, 0xE0, 50]), [])
        XCTAssertEqual(HIDPPController.decodeDPIList([0, 200, 0xE0, 50, 0, 100]), [])
        XCTAssertEqual(HIDPPController.decodeDPIList([0, 200, 0xFF, 0xFE]), [])
    }

    func testBluetoothDPIWriteReportLayout() {
        let report = HIDPPController.outputReport(feature: 0x12, function: 3,
                                                 parameters: [0, 0x0B, 0xB8], softwareID: 0x0A)
        XCTAssertEqual(report.count, 20)
        XCTAssertEqual(Array(report.prefix(7)), [0x11, 0xFF, 0x12, 0x3A, 0, 0x0B, 0xB8])
        XCTAssertEqual(Array(report.dropFirst()).count, 19)
        XCTAssertTrue(report.dropFirst(7).allSatisfy { $0 == 0 })
    }

    func testHIDRepliesMatchTheCallingClientAndFunction() {
        let message = HIDPPController.parse([0x11, 0, 0x12, 0x2A, 0, 0x0B, 0xB8])!
        XCTAssertEqual(HIDPPController.classifyResponse(message, feature: 0x12, function: 2,
                                                      softwareID: 0x0A, legacyFunctionReply: false), .success)
        XCTAssertEqual(HIDPPController.classifyResponse(message, feature: 0x12, function: 2,
                                                      softwareID: 0x0B, legacyFunctionReply: false), .unrelated)
        XCTAssertEqual(HIDPPController.classifyResponse(message, feature: 0x12, function: 1,
                                                      softwareID: 0x0A, legacyFunctionReply: false), .unrelated)
        XCTAssertEqual(HIDPPController.classifyResponse(message, feature: 0x12, function: 1,
                                                      softwareID: 0x0A, legacyFunctionReply: true), .success)
        XCTAssertNil(HIDPPController.parse([1, 0, 0, 0]))
        XCTAssertNil(HIDPPController.parse([0x11, 0xFF, 0x12]))
    }

    func testHIDErrorRepliesWakeOnlyTheMatchingRequest() {
        let message = HIDPPController.parse([0x11, 0xFF, 0xFF, 0x12, 0x3A, 2, 0])!
        XCTAssertEqual(HIDPPController.classifyResponse(message, feature: 0x12, function: 3,
                                                      softwareID: 0x0A, legacyFunctionReply: false), .deviceError(2))
        XCTAssertEqual(HIDPPController.classifyResponse(message, feature: 0x12, function: 3,
                                                      softwareID: 0x0B, legacyFunctionReply: false), .unrelated)
        XCTAssertEqual(HIDPPController.classifyResponse(message, feature: 0x13, function: 3,
                                                      softwareID: 0x0A, legacyFunctionReply: false), .unrelated)
    }

    func testVerticalScrollTransform() {
        let reversed = ScrollTransform.vertical(axis: 1, point: 11, fixed: 1.1, continuous: false, reverse: true, lines: 0)
        XCTAssertEqual(reversed?.axis, -1)
        XCTAssertEqual(reversed?.point, -11)
        XCTAssertEqual(reversed?.fixed, -1.1)

        let stepped = ScrollTransform.vertical(axis: -1, point: -1, fixed: -0.1, continuous: false, reverse: true, lines: 4)
        XCTAssertEqual(stepped?.axis, 4)
        XCTAssertNil(stepped?.point)
        XCTAssertEqual(stepped?.adjustsDiscreteStep, true)
    }

    private func trackpadSettings() -> MultitouchGestureRecognizer.Settings {
        MultitouchGestureRecognizer.Settings(
            enabled: true,
            fingerCount: 3,
            tapEnabled: true,
            allowMoreFingers: false,
            maximumTapDuration: 0.3,
            maximumTapMovement: 0.05
        )
    }

    private func points(_ count: Int, x: Double) -> [TrackpadTouchPoint] {
        (0..<count).map { index in
            TrackpadTouchPoint(x: x + Double(index) * 0.01, y: 0.4)
        }
    }
}
