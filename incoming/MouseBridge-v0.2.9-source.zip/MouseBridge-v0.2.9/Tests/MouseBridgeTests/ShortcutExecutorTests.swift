// SPDX-License-Identifier: GPL-3.0-or-later

import ApplicationServices
import XCTest
@testable import MouseBridge

final class ShortcutExecutorTests: XCTestCase {
    func testClickValidation() {
        for action in ["cmd+left click", " CMD + LEFT CLICK ", "command+left click",
                       "shift+cmd+right click", "ctrl+middle click", "left click"] {
            XCTAssertTrue(ShortcutExecutor.isValid(action), action)
        }
        for action in ["cmd+click", "cmd+left click+r", "meta+left click",
                       "cmd++left click", "+left click", "cmd+left click+", "cmd+"] {
            XCTAssertFalse(ShortcutExecutor.isValid(action), action)
            XCTAssertNil(ShortcutExecutor.makeEvents(action), action)
        }
    }

    func testCommandClickCreatesOnePairAtTriggerLocation() throws {
        // Negative coordinates also occur on secondary displays.
        let point = CGPoint(x: -200, y: 350)
        let events = try XCTUnwrap(ShortcutExecutor.makeEvents(" CMD + LEFT CLICK ", at: point))
        XCTAssertEqual(events.map(\.type), [.leftMouseDown, .leftMouseUp])
        for event in events {
            XCTAssertEqual(event.location, point)
            XCTAssertEqual(event.flags, .maskCommand)
            XCTAssertEqual(event.getIntegerValueField(.mouseEventButtonNumber), 0)
            XCTAssertEqual(event.getIntegerValueField(.mouseEventClickState), 1)
            XCTAssertEqual(event.getIntegerValueField(.eventSourceUserData), ShortcutExecutor.injectedMarker)
        }
    }

    func testOtherClickButtonsAndModifiers() throws {
        let cases: [(String, [CGEventType], Int64)] = [
            ("right click", [.rightMouseDown, .rightMouseUp], 1),
            ("middle click", [.otherMouseDown, .otherMouseUp], 2),
        ]
        for (action, types, button) in cases {
            let events = try XCTUnwrap(ShortcutExecutor.makeEvents("control+option+shift+" + action, at: .zero))
            XCTAssertEqual(events.map(\.type), types)
            for event in events {
                XCTAssertEqual(event.getIntegerValueField(.mouseEventButtonNumber), button)
                XCTAssertEqual(event.flags, [.maskControl, .maskAlternate, .maskShift])
            }
        }
    }

    func testKeyboardShortcutsAndDisabledActionsStillWork() throws {
        let cases: [(String, Int64)] = [("cmd+r", 15), ("ctrl+left", 123)]
        for (action, key) in cases {
            let events = try XCTUnwrap(ShortcutExecutor.makeEvents(action))
            XCTAssertEqual(events.map(\.type), [.keyDown, .keyUp])
            for event in events {
                XCTAssertEqual(event.getIntegerValueField(.keyboardEventKeycode), key)
                XCTAssertEqual(event.flags, action == "cmd+r" ? .maskCommand : .maskControl)
            }
        }
        for action in ["", "none", " NONE "] {
            XCTAssertTrue(ShortcutExecutor.isValid(action))
            XCTAssertEqual(try XCTUnwrap(ShortcutExecutor.makeEvents(action)).count, 0)
        }
    }

    func testInjectedClicksPassThroughWithoutRetriggeringMappings() throws {
        var trackpadCalls = 0
        let controller = EventTapController(
            configProvider: { AppConfig(middleAction: "none", trackpadGestureEnabled: true) },
            enabledProvider: { true },
            trackpadClickHandler: { trackpadCalls += 1; return true },
            clickSourceProvider: { _ in .trackpad }
        )
        for action in ["cmd+left click", "right click", "middle click"] {
            let events = try XCTUnwrap(ShortcutExecutor.makeEvents(action, at: .zero))
            for event in events {
                let result = try XCTUnwrap(controller.handle(type: event.type, event: event))
                XCTAssertTrue(result.takeUnretainedValue() === event)
            }
        }
        XCTAssertEqual(trackpadCalls, 0)

        // A click identified as trackpad input still reaches the gesture handler.
        let physical = try XCTUnwrap(CGEvent(mouseEventSource: nil, mouseType: .leftMouseDown,
                                            mouseCursorPosition: .zero, mouseButton: .left))
        XCTAssertNotNil(controller.handle(type: .leftMouseDown, event: physical))
        XCTAssertEqual(trackpadCalls, 1)
    }

    func testMappedMiddleReleaseIsSuppressedButUnmappedReleasePassesThrough() throws {
        let release = try XCTUnwrap(CGEvent(mouseEventSource: nil, mouseType: .otherMouseUp,
                                           mouseCursorPosition: .zero, mouseButton: .center))
        for action in ["cmd+left click", "none", ""] {
            let controller = EventTapController(
                configProvider: { AppConfig(middleAction: action) }, enabledProvider: { true }
            )
            XCTAssertEqual(controller.handle(type: .otherMouseUp, event: release) == nil, !action.isEmpty)
        }
    }

    func testClickConfigurationRoundTripsWithoutSchemaChange() throws {
        let config = AppConfig(middleAction: " CMD+LEFT CLICK ")
        let decoded = try JSONDecoder().decode(AppConfig.self, from: JSONEncoder().encode(config))
        XCTAssertEqual(decoded, config)
        XCTAssertEqual(decoded.middleAction, "cmd+left click")
        XCTAssertTrue(ShortcutExecutor.isValid(decoded.middleAction))
    }
}
