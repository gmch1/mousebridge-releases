import Foundation
import XCTest
@testable import MouseBridge

final class ConfigStoreRecoveryTests: XCTestCase {
    func testReadableSettingsSurviveCanonicalWriteFailureAndCanBeSavedAfterRecovery() async throws {
        try await MainActor.run {
            let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            defer {
                try? FileManager.default.setAttributes([.posixPermissions: 0o755], ofItemAtPath: directory.path)
                try? FileManager.default.removeItem(at: directory)
            }
            let file = directory.appendingPathComponent("config.json")
            let data = Data(#"{"schemaVersion":3,"middleAction":"cmd+left click","primaryDPI":2150}"#.utf8)
            try data.write(to: file)
            try FileManager.default.setAttributes([.posixPermissions: 0o555], ofItemAtPath: directory.path)
            let store = ConfigStore(directoryURL: directory)
            XCTAssertEqual(store.config.middleAction, "cmd+left click")
            XCTAssertEqual(store.config.primaryDPI, 2150)
            XCTAssertEqual(try Data(contentsOf: file), data)
            XCTAssertEqual(try FileManager.default.contentsOfDirectory(atPath: directory.path), ["config.json"])
            guard let error = store.lastError as? ConfigStoreError, case .write = error else {
                return XCTFail("Expected a write error, not a decoding error")
            }
            try FileManager.default.setAttributes([.posixPermissions: 0o755], ofItemAtPath: directory.path)
            try store.save(store.config)
            XCTAssertNil(store.lastError)
            XCTAssertEqual(try JSONDecoder().decode(AppConfig.self, from: Data(contentsOf: file)), store.config)
        }
    }

    func testMalformedJSONIsBackedUpButReadFailureIsNotRenamed() async throws {
        try await MainActor.run {
            let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            defer { try? FileManager.default.removeItem(at: directory) }
            let file = directory.appendingPathComponent("config.json")
            let invalid = Data("{ invalid JSON".utf8)
            try invalid.write(to: file)
            let malformed = ConfigStore(directoryURL: directory)
            guard let error = malformed.lastError as? ConfigStoreError, case .decode = error else {
                return XCTFail("Expected a decoding error")
            }
            let backup = try XCTUnwrap(FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil).first)
            XCTAssertTrue(backup.lastPathComponent.hasPrefix("config.corrupt-"))
            XCTAssertEqual(try Data(contentsOf: backup), invalid)
            try FileManager.default.removeItem(at: backup)
            // A directory at the config path causes a read error, not malformed JSON.
            try FileManager.default.createDirectory(at: file, withIntermediateDirectories: true)
            let unreadable = ConfigStore(directoryURL: directory)
            guard let error = unreadable.lastError as? ConfigStoreError, case .read = error else {
                return XCTFail("Expected a read error")
            }
            XCTAssertEqual(try FileManager.default.contentsOfDirectory(atPath: directory.path), ["config.json"])
        }
    }
}
