import ApplicationServices
import XCTest
@testable import MouseBridge

final class InputSourceTests: XCTestCase {
    private func click(_ type: CGEventType = .leftMouseDown) throws -> CGEvent {
        try XCTUnwrap(CGEvent(mouseEventSource: nil, mouseType: type,
            mouseCursorPosition: CGPoint(x: 20, y: 30), mouseButton: type == .rightMouseDown ? .right : .left))
    }

    func testMouseAndUnknownClicksLeaveArmedGestureForTrackpadClick() throws {
        for clickType: CGEventType in [.leftMouseDown, .rightMouseDown] {
            let recognizer = MultitouchGestureRecognizer(settings: .init(
                enabled: true, fingerCount: 3, tapEnabled: false, allowMoreFingers: false,
                maximumTapDuration: 0.3, maximumTapMovement: 0.05))
            _ = recognizer.processFrame(points: Array(repeating: .init(x: 0.2, y: 0.3), count: 3), timestamp: 10)
            var source = EventDeviceResolver.Kind.other
            var calls = 0
            let controller = EventTapController(
                configProvider: { AppConfig(trackpadGestureEnabled: true) }, enabledProvider: { true },
                trackpadClickHandler: { calls += 1; return recognizer.consumePhysicalClickIfArmed() },
                clickSourceProvider: { _ in source })
            for ignored: EventDeviceResolver.Kind in [.other, .unknown] {
                source = ignored
                let event = try click(clickType)
                let result = try XCTUnwrap(controller.handle(type: clickType, event: event))
                XCTAssertTrue(result.takeUnretainedValue() === event)
                XCTAssertTrue(recognizer.isPhysicalClickArmed)
                XCTAssertEqual(calls, 0)
            }
            source = .trackpad
            let event = try click(clickType)
            XCTAssertNotNil(controller.handle(type: clickType, event: event))
            XCTAssertEqual(calls, 1)
            XCTAssertFalse(recognizer.isPhysicalClickArmed)
        }
    }

    func testDisabledPausedAndInjectedClicksBypassSourceLookup() throws {
        var enabled = true
        var config = AppConfig(trackpadGestureEnabled: false)
        var lookups = 0
        var calls = 0
        let controller = EventTapController(configProvider: { config }, enabledProvider: { enabled },
            trackpadClickHandler: { calls += 1; return true },
            clickSourceProvider: { _ in lookups += 1; return .trackpad })
        XCTAssertNotNil(controller.handle(type: .leftMouseDown, event: try click()))
        config.trackpadGestureEnabled = true
        enabled = false
        XCTAssertNotNil(controller.handle(type: .leftMouseDown, event: try click()))
        enabled = true
        let injected = try click()
        injected.setIntegerValueField(.eventSourceUserData, value: ShortcutExecutor.injectedMarker)
        XCTAssertNotNil(controller.handle(type: .leftMouseDown, event: injected))
        XCTAssertEqual(lookups, 0)
        XCTAssertEqual(calls, 0)
    }

    func testSyntheticClickWithoutHIDOriginRemainsUnknown() throws {
        // Exercise the real dynamically loaded bridge, not the injected resolver.
        XCTAssertEqual(EventDeviceResolver().kind(for: try click()), .unknown)
    }

    func testRegistryFactsAreCachedPerSenderAndUnknownLookupsCanRecover() throws {
        var sender: UInt64? = nil
        var products: [UInt64: String] = [1: "Apple Internal Keyboard / Trackpad", 2: "MX Master 3S", 3: "Magic Trackpad"]
        var lookups = 0
        let resolver = EventDeviceResolver(senderID: { _ in sender }, productName: {
            lookups += 1; return products[$0]
        })
        let event = try click()
        XCTAssertEqual(resolver.kind(for: event), .unknown)
        sender = 0
        XCTAssertEqual(resolver.kind(for: event), .unknown)
        XCTAssertEqual(lookups, 0)
        let devices: [(UInt64, EventDeviceResolver.Kind)] = [(1, .trackpad), (2, .other), (3, .trackpad)]
        for (id, expected) in devices {
            sender = id
            XCTAssertEqual(resolver.kind(for: event), expected)
            XCTAssertEqual(resolver.kind(for: event), expected)
        }
        XCTAssertEqual(lookups, 3)
        sender = 4
        XCTAssertEqual(resolver.kind(for: event), .unknown)
        products[4] = "Magic Trackpad"
        XCTAssertEqual(resolver.kind(for: event), .trackpad)
        XCTAssertEqual(lookups, 5)
        sender = 5
        products[5] = "Magic Mouse"
        XCTAssertEqual(resolver.kind(for: event), .other)
    }
}
