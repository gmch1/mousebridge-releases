// SPDX-License-Identifier: GPL-3.0-or-later

import AppKit
import XCTest
@testable import MouseBridge

final class SettingsUITests: XCTestCase {
    func testActionPresetsAndCustomShortcutsRoundTrip() async throws {
        await MainActor.run {
            _ = NSApplication.shared
            let field = ShortcutActionField(label: "测试按键")
            field.stringValue = "shift+cmd+z"
            XCTAssertEqual(field.popup.titleOfSelectedItem, "自定义快捷键…")
            field.isEnabled = false
            XCTAssertFalse(field.popup.isEnabled)
            field.isEnabled = true
            XCTAssertEqual(field.stringValue, "shift+cmd+z")
            field.popup.selectItem(withTitle: "后台打开链接（⌘ + 点击）")
            NSApp.sendAction(field.popup.action!, to: field.popup.target, from: field.popup)
            XCTAssertEqual(field.stringValue, "cmd+left click")
            field.popup.selectItem(withTitle: "自定义快捷键…")
            NSApp.sendAction(field.popup.action!, to: field.popup.target, from: field.popup)
            XCTAssertEqual(field.stringValue, "shift+cmd+z")
            field.stringValue = "none"
            XCTAssertEqual(field.popup.titleOfSelectedItem, "不执行任何操作")
            field.stringValue = ""
            XCTAssertEqual(field.popup.titleOfSelectedItem, "默认行为")
        }
    }

    func testPagesPreserveEditsAndFitResizableWindow() async throws {
        try await MainActor.run {
            _ = NSApplication.shared
            let controller = SettingsWindowController(initialConfig: AppConfig(
                middleAction: "cmd+left click", horizontalLeftAction: "ctrl+shift+tab", horizontalRightAction: "ctrl+tab", reverseVerticalScroll: true, scrollLines: 4,
                primaryDPI: 2150, trackpadGestureEnabled: true, trackpadFingerCount: 4
            ))
            let window = try XCTUnwrap(controller.window)
            defer { window.close() }
            window.appearance = NSAppearance(named: .aqua)
            controller.setConnected(true, deviceName: "MX Master 3S")
            controller.setDPICapabilities(.init(values: Array(stride(from: 200, through: 8000, by: 50)), cameFromDevice: true))
            controller.setPermissionStatus(accessibilityGranted: true, inputMonitoringGranted: true)
            controller.setInputStatus("按键与滚轮：运行中", ready: true)
            controller.onCheckForUpdates = {}
            controller.onAutomaticUpdatesChanged = { _ in }
            controller.configureUpdates(automaticChecks: true, canCheck: true)
            let root = try XCTUnwrap(window.contentView)
            let picker = try XCTUnwrap(Self.descendants(root).compactMap { $0 as? NSSegmentedControl }.first)
            let tabs = try XCTUnwrap(Self.descendants(root).compactMap { $0 as? NSTabView }.first)
            window.orderFront(nil)
            root.layoutSubtreeIfNeeded()
            let mapping = try XCTUnwrap(Self.descendants(root).compactMap { $0 as? MouseMappingView }.first)
            let action = mapping.middleField
            mapping.horizontalRightField.stringValue = "option+right"
            for control in MouseMappingView.Control.allCases {
                mapping.controlPicker.selectItem(at: control.rawValue)
                NSApp.sendAction(mapping.controlPicker.action!, to: mapping.controlPicker.target, from: mapping.controlPicker)
                XCTAssertEqual(mapping.selectedControl, control)
            }
            // Hotspots are native buttons, so mouse and keyboard activation share a path.
            let hotspot = try XCTUnwrap(Self.descendants(mapping).compactMap { $0 as? NSButton }.first { $0.toolTip == "滚轮中键" })
            hotspot.performClick(nil)
            XCTAssertEqual(mapping.selectedControl, .middle)
            XCTAssertEqual(mapping.horizontalRightField.stringValue, "option+right")
            mapping.horizontalRightField.stringValue = "ctrl+tab"
            mapping.select(.horizontal)
            XCTAssertEqual(mapping.wheelPresetPicker.titleOfSelectedItem, "上一个 / 下一个标签页")
            mapping.wheelPresetPicker.selectItem(withTitle: "撤销 / 重做")
            NSApp.sendAction(mapping.wheelPresetPicker.action!, to: mapping.wheelPresetPicker.target, from: mapping.wheelPresetPicker)
            XCTAssertEqual(mapping.horizontalLeftField.stringValue, "cmd+z")
            XCTAssertEqual(mapping.horizontalRightField.stringValue, "shift+cmd+z")
            mapping.horizontalLeftField.stringValue = "ctrl+shift+tab"
            mapping.horizontalRightField.stringValue = "ctrl+tab"
            mapping.select(.middle)
            action.stringValue = "option+shift+left click"
            for size in [NSSize(width: 820, height: 680), NSSize(width: 720, height: 620)] {
                window.setContentSize(size)
                for index in 0..<3 {
                    picker.selectedSegment = index
                    NSApp.sendAction(picker.action!, to: picker.target, from: picker)
                    root.layoutSubtreeIfNeeded()
                    XCTAssertEqual(tabs.indexOfTabViewItem(tabs.selectedTabViewItem!), index)
                    let page = try XCTUnwrap(tabs.selectedTabViewItem?.view as? NSScrollView)
                    let document = try XCTUnwrap(page.documentView)
                    XCTAssertGreaterThan(document.frame.height, 0)
                    XCTAssertEqual(document.frame.width, page.contentView.bounds.width, accuracy: 1)
                    // Check horizontal clipping; long pages can scroll vertically.
                    for control in Self.descendants(document).compactMap({ $0 as? NSControl }) where !control.isHiddenOrHasHiddenAncestor {
                        let frame = document.convert(control.bounds, from: control)
                        XCTAssertGreaterThanOrEqual(frame.minX, -1, "\(type(of: control)) clipped on left")
                        XCTAssertLessThanOrEqual(frame.maxX, document.bounds.width + 1, "\(type(of: control)) clipped on right")
                    }
                    if index == 0 {
                        for control in MouseMappingView.Control.allCases {
                            mapping.select(control)
                            root.layoutSubtreeIfNeeded()
                            for field in Self.descendants(document).compactMap({ $0 as? NSControl }) where !field.isHiddenOrHasHiddenAncestor {
                                let frame = document.convert(field.bounds, from: field)
                                XCTAssertGreaterThanOrEqual(frame.minX, -1)
                                XCTAssertLessThanOrEqual(frame.maxX, document.bounds.width + 1)
                            }
                        }
                        if size.width == 820 { try Self.snapshot(root, name: "horizontal") }
                        let mousePicker = try XCTUnwrap(Self.descendants(document).compactMap { $0 as? NSSegmentedControl }.first)
                        mousePicker.selectedSegment = 1
                        NSApp.sendAction(mousePicker.action!, to: mousePicker.target, from: mousePicker)
                        root.layoutSubtreeIfNeeded()
                        let sliders = Self.descendants(document).compactMap { $0 as? NSSlider }.filter { !$0.isHiddenOrHasHiddenAncestor }
                        XCTAssertEqual(sliders.count, 2)
                        if size.width == 820 { try Self.snapshot(root, name: "pointer") }
                        mousePicker.selectedSegment = 0
                        NSApp.sendAction(mousePicker.action!, to: mousePicker.target, from: mousePicker)
                        mapping.select(.middle)
                    }
                    XCTAssertEqual(action.stringValue, "option+shift+left click")
                    if size.width == 820 {
                        action.stringValue = "cmd+left click"
                        // XCTest's bundle reports Xcode's version, so use sample data.
                        for label in Self.descendants(root).compactMap({ $0 as? NSTextField }) where label.stringValue.hasPrefix("版本 ") {
                            label.stringValue = "版本 0.2.5"
                        }
                        root.layoutSubtreeIfNeeded()
                        try Self.snapshot(root, name: ["mouse", "trackpad", "general"][index])
                        action.stringValue = "option+shift+left click"
                    }
                }
            }
            window.setContentSize(NSSize(width: 820, height: 680))
            window.appearance = NSAppearance(named: .darkAqua)
            root.layoutSubtreeIfNeeded()
            try Self.snapshot(root, name: "general-dark")
            picker.selectedSegment = 0
            NSApp.sendAction(picker.action!, to: picker.target, from: picker)
            mapping.select(.horizontal)
            root.layoutSubtreeIfNeeded()
            try Self.snapshot(root, name: "mouse-dark")
        }
    }

    @MainActor private static func descendants(_ view: NSView) -> [NSView] {
        view.subviews.flatMap { [$0] + descendants($0) }
    }

    @MainActor private static func snapshot(_ view: NSView, name: String) throws {
        guard let directory = ProcessInfo.processInfo.environment["MOUSEBRIDGE_PREVIEW_DIR"] else { return }
        let url = URL(fileURLWithPath: directory, isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        for child in descendants(view) { child.needsDisplay = true }
        view.needsDisplay = true
        view.displayIfNeeded()
        let bitmap = try XCTUnwrap(view.bitmapImageRepForCachingDisplay(in: view.bounds))
        view.cacheDisplay(in: view.bounds, to: bitmap)
        // cacheDisplay captures content only; the window's background is outside
        // this view. Composite it explicitly so exported PNGs remain opaque.
        let output = try XCTUnwrap(NSBitmapImageRep(
            bitmapDataPlanes: nil, pixelsWide: bitmap.pixelsWide, pixelsHigh: bitmap.pixelsHigh,
            bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false,
            colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0
        ))
        output.size = view.bounds.size
        NSGraphicsContext.saveGraphicsState()
        defer { NSGraphicsContext.restoreGraphicsState() }
        NSGraphicsContext.current = try XCTUnwrap(NSGraphicsContext(bitmapImageRep: output))
        view.effectiveAppearance.performAsCurrentDrawingAppearance {
            NSColor.windowBackgroundColor.setFill()
            NSRect(origin: .zero, size: view.bounds.size).fill()
            bitmap.draw(in: NSRect(origin: .zero, size: view.bounds.size),
                        from: .zero, operation: .sourceOver, fraction: 1,
                        respectFlipped: false, hints: nil)
        }
        let png = try XCTUnwrap(output.representation(using: .png, properties: [:]))
        try png.write(to: url.appendingPathComponent(name + ".png"))
    }
}
