// SPDX-License-Identifier: GPL-3.0-or-later

import ApplicationServices
import XCTest
@testable import MouseBridge

final class HorizontalScrollTests: XCTestCase {
    func testOldSettingsKeepNativeHorizontalScrollingAndRoundTripNewBindings() throws {
        let legacy = try JSONDecoder().decode(AppConfig.self, from: Data(#"{"schemaVersion":3,"middleAction":"cmd+left click","primaryDPI":2150}"#.utf8))
        XCTAssertEqual(legacy.horizontalLeftAction, "")
        XCTAssertEqual(legacy.horizontalRightAction, "")
        XCTAssertEqual(legacy.middleAction, "cmd+left click")
        XCTAssertEqual(legacy.primaryDPI, 2150)
        XCTAssertEqual(legacy.schemaVersion, 4)
        let configured = AppConfig(horizontalLeftAction: " CTRL+SHIFT+TAB ", horizontalRightAction: " CTRL+TAB ")
        XCTAssertEqual(configured.horizontalLeftAction, "ctrl+shift+tab")
        XCTAssertEqual(try JSONDecoder().decode(AppConfig.self, from: configured.prettyJSONData()), configured)
    }

    func testDirectionsHaveIndependentCooldownsWithoutDelayedBacklog() {
        var mapper = HorizontalScrollMapper()
        let config = AppConfig(horizontalLeftAction: "ctrl+shift+tab", horizontalRightAction: "ctrl+tab")
        XCTAssertEqual(mapper.process(delta: 0.1, config: config, now: 10)?.action, "ctrl+shift+tab")
        XCTAssertEqual(mapper.process(delta: -0.1, config: config, now: 10)?.action, "ctrl+tab")
        for index in 1...19 {
            let decision = mapper.process(delta: index % 2 == 0 ? 1 : -1, config: config, now: 10 + Double(index) / 100)
            XCTAssertNotNil(decision)
            XCTAssertNil(decision?.action)
        }
        XCTAssertEqual(mapper.process(delta: -0.1, config: config, now: 10.25)?.action, "ctrl+tab")
        XCTAssertNil(mapper.process(delta: 0, config: config, now: 11))
        XCTAssertEqual(mapper.process(delta: 1, config: config, now: 12)?.action, "ctrl+shift+tab")
    }

    func testPairPresetsRecognizeOnlyExactPairs() {
        for preset in HorizontalWheelPreset.allCases {
            XCTAssertEqual(HorizontalWheelPreset.recognize(left: preset.pair.left, right: preset.pair.right), preset)
            XCTAssertTrue(ShortcutExecutor.isValid(preset.pair.left))
            XCTAssertTrue(ShortcutExecutor.isValid(preset.pair.right))
        }
        XCTAssertNil(HorizontalWheelPreset.recognize(left: "ctrl+tab", right: "ctrl+shift+tab"))
        XCTAssertNil(HorizontalWheelPreset.recognize(left: "cmd+r", right: "cmd+w"))
    }

    func testDefaultsDisableInvalidAndSettingsChange() {
        var mapper = HorizontalScrollMapper()
        var config = AppConfig(horizontalLeftAction: "none")
        XCTAssertNotNil(mapper.process(delta: 1, config: config, now: 1))
        XCTAssertNil(mapper.process(delta: -1, config: config, now: 1))
        config.horizontalLeftAction = "not-a-shortcut"
        XCTAssertNil(mapper.process(delta: 1, config: config, now: 1))
        config.horizontalLeftAction = "cmd+r"
        XCTAssertEqual(mapper.process(delta: 1, config: config, now: 1)?.action, "cmd+r")
        config.horizontalLeftAction = "cmd+w"
        XCTAssertEqual(mapper.process(delta: 1, config: config, now: 1.01)?.action, "cmd+w")
        mapper.reset()
        XCTAssertEqual(mapper.process(delta: 1, config: config, now: 1.02)?.action, "cmd+w")
    }

    func testMappedAxisIsRemovedWhileVerticalScrollAndReversalSurvive() throws {
        var actions: [String] = []
        let controller = EventTapController(
            configProvider: { AppConfig(horizontalLeftAction: "cmd+[", reverseVerticalScroll: true, reverseHorizontalScroll: true) },
            enabledProvider: { true }, actionExecutor: { action, _ in actions.append(action) }
        )
        let event = try wheel(x: 1, y: 2)
        let result = try XCTUnwrap(controller.handle(type: .scrollWheel, event: event))
        XCTAssertTrue(result.takeUnretainedValue() === event)
        XCTAssertEqual(actions, ["cmd+["])
        XCTAssertEqual(event.getIntegerValueField(.scrollWheelEventDeltaAxis1), -2)
        XCTAssertEqual(event.getIntegerValueField(.scrollWheelEventDeltaAxis2), 0)
        XCTAssertEqual(event.getIntegerValueField(.scrollWheelEventPointDeltaAxis2), 0)
        XCTAssertEqual(event.getDoubleValueField(.scrollWheelEventFixedPtDeltaAxis2), 0)
    }

    func testHighResolutionDirectionLocationAndRateLimitThroughEventHandler() throws {
        var actions: [String] = []
        var locations: [CGPoint] = []
        var time = 10.0
        let controller = EventTapController(
            configProvider: { AppConfig(horizontalLeftAction: "cmd+left click", horizontalRightAction: "cmd+]") },
            enabledProvider: { true },
            actionExecutor: { actions.append($0); locations.append($1) }, uptime: { time }
        )
        for index in 0..<3 {
            let event = try wheel(x: 0)
            event.setDoubleValueField(.scrollWheelEventFixedPtDeltaAxis2, value: index == 2 ? -0.25 : 0.25)
            event.location = CGPoint(x: -100, y: 400)
            time = index == 2 ? 10.5 : 10 + Double(index) * 0.01
            XCTAssertNil(controller.handle(type: .scrollWheel, event: event))
        }
        XCTAssertEqual(actions, ["cmd+left click", "cmd+]"])
        XCTAssertEqual(locations, [CGPoint(x: -100, y: 400), CGPoint(x: -100, y: 400)])
    }

    func testUnmappedTrackpadInjectedAndPausedEventsPassThrough() throws {
        var enabled = true
        var calls = 0
        let controller = EventTapController(
            configProvider: { AppConfig(horizontalLeftAction: "cmd+[") }, enabledProvider: { enabled },
            actionExecutor: { _, _ in calls += 1 }
        )
        let right = try wheel(x: -1)
        XCTAssertNotNil(controller.handle(type: .scrollWheel, event: right))
        XCTAssertEqual(right.getIntegerValueField(.scrollWheelEventDeltaAxis2), -1)
        let trackpad = try wheel(x: 1)
        trackpad.setIntegerValueField(.scrollWheelEventIsContinuous, value: 1)
        XCTAssertNotNil(controller.handle(type: .scrollWheel, event: trackpad))
        let injected = try wheel(x: 1)
        injected.setIntegerValueField(.eventSourceUserData, value: ShortcutExecutor.injectedMarker)
        XCTAssertNotNil(controller.handle(type: .scrollWheel, event: injected))
        enabled = false
        XCTAssertNotNil(controller.handle(type: .scrollWheel, event: try wheel(x: 1)))
        XCTAssertEqual(calls, 0)
        enabled = true
        XCTAssertNil(controller.handle(type: .scrollWheel, event: try wheel(x: 1)))
        XCTAssertEqual(calls, 1)
    }

    func testDisabledHorizontalDirectionConsumesWithoutExecuting() throws {
        var calls = 0
        let controller = EventTapController(
            configProvider: { AppConfig(horizontalRightAction: "none") }, enabledProvider: { true },
            actionExecutor: { _, _ in calls += 1 }
        )
        XCTAssertNil(controller.handle(type: .scrollWheel, event: try wheel(x: -1)))
        XCTAssertEqual(calls, 0)
    }

    private func wheel(x: Int32, y: Int32 = 0) throws -> CGEvent {
        try XCTUnwrap(CGEvent(scrollWheelEvent2Source: nil, units: .line, wheelCount: 2, wheel1: y, wheel2: x, wheel3: 0))
    }
}
