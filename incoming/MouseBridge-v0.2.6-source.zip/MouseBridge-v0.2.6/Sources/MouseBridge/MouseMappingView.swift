// SPDX-License-Identifier: GPL-3.0-or-later

import AppKit

/// A schematic, not a device photograph: all controls have keyboard-accessible alternatives.
@MainActor
final class MouseMappingView: NSView {
    enum Control: Int, CaseIterable {
        case middle, back, forward, horizontal
        var title: String {
            switch self {
            case .middle: return "滚轮中键"
            case .back: return "后退侧键"
            case .forward: return "前进侧键"
            case .horizontal: return "横向拇指滚轮"
            }
        }
        var number: String { self == .horizontal ? "↔" : String(rawValue + 1) }
    }

    let middleField = ShortcutActionField(label: "滚轮中键")
    let backField = ShortcutActionField(label: "后退侧键")
    let forwardField = ShortcutActionField(label: "前进侧键")
    let horizontalLeftField = ShortcutActionField(label: "横向滚轮向左")
    let horizontalRightField = ShortcutActionField(label: "横向滚轮向右")
    let controlPicker = NSPopUpButton(frame: .zero, pullsDown: false)
    private let diagram = MouseDiagramView()
    private let editor = NSStackView()
    let wheelPresetPicker = NSPopUpButton(frame: .zero, pullsDown: false)
    private var customWheelPanel: NSView!
    private let wheelSummary = NSTextField(wrappingLabelWithString: "")
    private var panels: [NSView] = []
    private(set) var selectedControl: Control = .middle

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        controlPicker.addItems(withTitles: Control.allCases.map { "\($0.number)  \($0.title)" })
        controlPicker.target = self
        controlPicker.action = #selector(controlChanged)
        controlPicker.setAccessibilityLabel("配置鼠标控件")
        diagram.onSelect = { [weak self] in self?.select($0) }
        let subtitle = label("点击鼠标上的标记，或从列表中选择。", small: true)
        editor.orientation = .vertical
        editor.alignment = .leading
        editor.spacing = 12
        editor.addArrangedSubview(controlPicker)
        editor.addArrangedSubview(subtitle)

        let clickHelp = "默认行为保留原来的按键功能。选择常用动作，也可以输入自定义快捷键。"
        panels = [
            panel([label("点击中键时"), middleField, label("选择“后台打开链接”可模拟 ⌘ + 点击，打开方式取决于浏览器设置。", small: true)]),
            panel([label("按下后退侧键时"), backField, label(clickHelp, small: true)]),
            panel([label("按下前进侧键时"), forwardField, label(clickHelp, small: true)]),
        ]
        wheelPresetPicker.addItems(withTitles: HorizontalWheelPreset.allCases.map(\.title) + ["自定义左右动作…"])
        wheelPresetPicker.target = self
        wheelPresetPicker.action = #selector(wheelPresetChanged)
        wheelPresetPicker.setAccessibilityLabel("横向滚轮动作预设")
        customWheelPanel = panel([label("向左滚动"), horizontalLeftField, label("向右滚动"), horizontalRightField])
        horizontalLeftField.onChange = { [weak self] in self?.refreshWheelPreset() }
        horizontalRightField.onChange = { [weak self] in self?.refreshWheelPreset() }
        wheelSummary.font = .systemFont(ofSize: 12)
        wheelSummary.textColor = .secondaryLabelColor
        let swap = NSButton(title: "交换左右动作", target: self, action: #selector(swapDirections))
        swap.bezelStyle = .rounded
        let horizontal = panel([
            label("滚动时执行"), wheelPresetPicker, wheelSummary, customWheelPanel, swap,
            label("支持 MX Master 拇指滚轮及其他鼠标横向滚轮。方向按系统滚动方向识别，连续滚动时自动限制重复触发。", small: true),
        ])
        panels.append(horizontal)
        for view in panels { editor.addArrangedSubview(view) }
        for view in editor.arrangedSubviews {
            view.widthAnchor.constraint(equalTo: editor.widthAnchor).isActive = true
        }
        let layout = NSStackView(views: [diagram, editor])
        layout.orientation = .horizontal
        layout.alignment = .top
        layout.spacing = 24
        layout.translatesAutoresizingMaskIntoConstraints = false
        addSubview(layout)
        NSLayoutConstraint.activate([
            layout.leadingAnchor.constraint(equalTo: leadingAnchor),
            layout.trailingAnchor.constraint(equalTo: trailingAnchor),
            layout.topAnchor.constraint(equalTo: topAnchor),
            layout.bottomAnchor.constraint(equalTo: bottomAnchor),
            diagram.widthAnchor.constraint(equalToConstant: 250),
            diagram.heightAnchor.constraint(equalToConstant: 320),
            editor.widthAnchor.constraint(greaterThanOrEqualToConstant: 280),
            editor.trailingAnchor.constraint(equalTo: trailingAnchor),
            diagram.leadingAnchor.constraint(equalTo: leadingAnchor),
        ])
        select(.middle)
    }

    convenience init() { self.init(frame: .zero) }
    required init?(coder: NSCoder) { nil }

    func select(_ control: Control) {
        window?.makeFirstResponder(nil)
        selectedControl = control
        controlPicker.selectItem(at: control.rawValue)
        for (index, panel) in panels.enumerated() { panel.isHidden = index != control.rawValue }
        diagram.selectedControl = control
        if control == .horizontal { refreshWheelPreset() }
    }

    @objc private func controlChanged() {
        if let control = Control(rawValue: controlPicker.indexOfSelectedItem) { select(control) }
    }
    @objc private func wheelPresetChanged() {
        if let preset = HorizontalWheelPreset(rawValue: wheelPresetPicker.indexOfSelectedItem) {
            horizontalLeftField.stringValue = preset.pair.left
            horizontalRightField.stringValue = preset.pair.right
            refreshWheelPreset()
        } else {
            customWheelPanel.isHidden = false
            wheelSummary.isHidden = true
        }
    }

    private func refreshWheelPreset() {
        guard customWheelPanel != nil else { return }
        let preset = HorizontalWheelPreset.recognize(left: horizontalLeftField.stringValue, right: horizontalRightField.stringValue)
        wheelPresetPicker.selectItem(at: preset?.rawValue ?? HorizontalWheelPreset.allCases.count)
        // Keep custom editors open while typing, even when a pair becomes a preset.
        let editing = window?.firstResponder is NSTextView
        if !editing { customWheelPanel.isHidden = preset != nil }
        wheelSummary.isHidden = !customWheelPanel.isHidden
        switch preset {
        case .native: wheelSummary.stringValue = "保留原来的横向滚动。"
        case .disabled: wheelSummary.stringValue = "左右两个方向都不执行操作。"
        case .some(let preset): wheelSummary.stringValue = "向左：\(preset.pair.left)\n向右：\(preset.pair.right)"
        case .none: wheelSummary.stringValue = ""
        }
    }
    @objc private func swapDirections() {
        let left = horizontalLeftField.stringValue
        horizontalLeftField.stringValue = horizontalRightField.stringValue
        horizontalRightField.stringValue = left
    }

    private func panel(_ views: [NSView]) -> NSStackView {
        let stack = NSStackView(views: views)
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 8
        for view in views { view.widthAnchor.constraint(equalTo: stack.widthAnchor).isActive = true }
        return stack
    }

    private func label(_ text: String, small: Bool = false) -> NSTextField {
        let field = NSTextField(wrappingLabelWithString: text)
        field.font = .systemFont(ofSize: small ? 11 : 12, weight: small ? .regular : .medium)
        field.textColor = small ? .secondaryLabelColor : .labelColor
        return field
    }
}

@MainActor
private final class MouseDiagramView: NSView {
    override var isFlipped: Bool { true }
    var onSelect: ((MouseMappingView.Control) -> Void)?
    var selectedControl: MouseMappingView.Control = .middle {
        didSet {
            for (index, button) in hotspots.enumerated() {
                button.contentTintColor = index == selectedControl.rawValue ? .controlAccentColor : .secondaryLabelColor
                button.setAccessibilityValue(index == selectedControl.rawValue ? "已选择" : "未选择")
            }
            needsDisplay = true
        }
    }
    private var hotspots: [NSButton] = []
    private let centers: [NSPoint] = [NSPoint(x: 151, y: 81), NSPoint(x: 56, y: 193), NSPoint(x: 59, y: 155), NSPoint(x: 79, y: 111)]

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        for control in MouseMappingView.Control.allCases {
            let button = NSButton(title: control.number, target: self, action: #selector(pressed(_:)))
            button.tag = control.rawValue
            button.bezelStyle = .circular
            button.font = .systemFont(ofSize: 12, weight: .semibold)
            button.setAccessibilityLabel(control.title)
            button.toolTip = control.title
            addSubview(button)
            hotspots.append(button)
        }
    }
    required init?(coder: NSCoder) { nil }

    override func layout() {
        super.layout()
        for (index, button) in hotspots.enumerated() {
            button.frame = NSRect(x: centers[index].x - 15, y: centers[index].y - 15, width: 30, height: 30)
        }
    }
    @objc private func pressed(_ button: NSButton) {
        if let control = MouseMappingView.Control(rawValue: button.tag) { onSelect?(control) }
    }

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        let body = NSBezierPath()
        body.move(to: NSPoint(x: 99, y: 21))
        body.curve(to: NSPoint(x: 211, y: 65), controlPoint1: NSPoint(x: 135, y: -1), controlPoint2: NSPoint(x: 204, y: 19))
        body.curve(to: NSPoint(x: 204, y: 260), controlPoint1: NSPoint(x: 228, y: 127), controlPoint2: NSPoint(x: 233, y: 211))
        body.curve(to: NSPoint(x: 64, y: 273), controlPoint1: NSPoint(x: 173, y: 301), controlPoint2: NSPoint(x: 105, y: 298))
        body.curve(to: NSPoint(x: 30, y: 212), controlPoint1: NSPoint(x: 15, y: 270), controlPoint2: NSPoint(x: 17, y: 244))
        body.curve(to: NSPoint(x: 68, y: 94), controlPoint1: NSPoint(x: 53, y: 171), controlPoint2: NSPoint(x: 56, y: 129))
        body.curve(to: NSPoint(x: 99, y: 21), controlPoint1: NSPoint(x: 74, y: 55), controlPoint2: NSPoint(x: 78, y: 33))
        body.close()
        NSColor.quaternaryLabelColor.setFill()
        body.fill()
        NSColor.separatorColor.setStroke()
        body.lineWidth = 1
        body.stroke()

        let seam = NSBezierPath()
        seam.move(to: NSPoint(x: 151, y: 20)); seam.line(to: NSPoint(x: 151, y: 125))
        seam.move(to: NSPoint(x: 85, y: 126)); seam.curve(to: NSPoint(x: 219, y: 138), controlPoint1: NSPoint(x: 134, y: 143), controlPoint2: NSPoint(x: 182, y: 148))
        seam.stroke()
        // Vertical wheel, horizontal thumbwheel, then the two side buttons.
        for rect in [NSRect(x: 137, y: 50, width: 28, height: 65),
                     NSRect(x: 55, y: 98, width: 49, height: 26),
                     NSRect(x: 43, y: 139, width: 32, height: 31),
                     NSRect(x: 40, y: 177, width: 32, height: 31)] {
            let part = NSBezierPath(roundedRect: rect, xRadius: 9, yRadius: 9)
            NSColor.controlBackgroundColor.setFill(); part.fill()
            NSColor.separatorColor.setStroke(); part.stroke()
        }
        let center = centers[selectedControl.rawValue]
        let ring = NSBezierPath(ovalIn: NSRect(x: center.x - 22, y: center.y - 22, width: 44, height: 44))
        NSColor.controlAccentColor.withAlphaComponent(0.18).setFill(); ring.fill()
        NSColor.controlAccentColor.setStroke(); ring.lineWidth = 1.5; ring.stroke()
        let caption = "按键示意 · 点击标记配置" as NSString
        caption.draw(at: NSPoint(x: 52, y: 304), withAttributes: [.font: NSFont.systemFont(ofSize: 11), .foregroundColor: NSColor.secondaryLabelColor])
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        needsDisplay = true
    }
}
