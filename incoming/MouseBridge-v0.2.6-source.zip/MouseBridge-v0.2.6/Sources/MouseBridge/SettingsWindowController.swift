// SPDX-License-Identifier: GPL-3.0-or-later

import AppKit

@MainActor
final class SettingsWindowController: NSWindowController {
    private let mouseMapping = MouseMappingView()
    private var middleField: ShortcutActionField { mouseMapping.middleField }
    private var backField: ShortcutActionField { mouseMapping.backField }
    private var forwardField: ShortcutActionField { mouseMapping.forwardField }
    private let reverseVertical = NSButton(checkboxWithTitle: "反向垂直滚动（仅鼠标）", target: nil, action: nil)
    private let reverseHorizontal = NSButton(checkboxWithTitle: "反向水平滚动（仅鼠标）", target: nil, action: nil)
    private let scrollLinesSlider = NSSlider(value: 0, minValue: 0, maxValue: 20, target: nil, action: nil)
    private let scrollLinesValue = NSTextField(labelWithString: "跟随系统")
    private let dpiSlider = NSSlider(value: 0, minValue: 0, maxValue: 100, target: nil, action: nil)
    private let dpiValue = NSTextField(labelWithString: "1000 DPI")
    private let dpiRange = NSTextField(labelWithString: "正在读取设备 DPI 范围…")
    private let trackpadEnabled = NSButton(checkboxWithTitle: "启用触控板多指快捷键", target: nil, action: nil)
    private let trackpadFingerPopup = NSPopUpButton(frame: .zero, pullsDown: false)
    private let trackpadActionField = ShortcutActionField(label: "触控板动作")
    private let trackpadTapEnabled = NSButton(checkboxWithTitle: "轻点也触发（关闭时仅物理按压）", target: nil, action: nil)
    private let trackpadAllowMoreFingers = NSButton(checkboxWithTitle: "允许多于设定手指数", target: nil, action: nil)
    private let connectionLabel = NSTextField(labelWithString: "鼠标：正在连接…")
    private let inputStatusLabel = NSTextField(labelWithString: "按键与滚轮：检查权限…")
    private let permissionStatusLabel = NSTextField(labelWithString: "权限：正在检查…")
    private let launchAtLogin = NSButton(checkboxWithTitle: "登录时自动启动", target: nil, action: nil)
    private let messageLabel = NSTextField(wrappingLabelWithString: "")
    private let automaticUpdates = NSButton(checkboxWithTitle: "每天自动检查更新", target: nil, action: nil)
    private let updateButton = NSButton(title: "检查更新…", target: nil, action: nil)
    private let saveButton = NSButton(title: "保存并应用", target: nil, action: nil)
    private let sectionPicker = NSSegmentedControl(labels: ["鼠标", "触控板", "通用"], trackingMode: .selectOne, target: nil, action: nil)
    private let pages = NSTabView()
    private let mouseSectionPicker = NSSegmentedControl(labels: ["按键与横向滚轮", "滚动与指针"], trackingMode: .selectOne, target: nil, action: nil)
    private var mouseSections: [NSView] = []
    var onDPIApplyRequested: (() -> Void)?
    var onCheckForUpdates: (() -> Void)?
    var onAutomaticUpdatesChanged: ((Bool) -> Void)?
    var onAboutRequested: (() -> Void)?
    private var dpiEdited = false
    private var dpiValues = Array(stride(from: 100, through: 8000, by: 50))

    init(initialConfig: AppConfig? = nil) {
        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 820, height: 680),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = "MouseBridge 设置"
        window.center()
        window.isReleasedWhenClosed = false
        window.contentMinSize = NSSize(width: 720, height: 620)
        super.init(window: window)
        buildUI()
        loadConfig(initialConfig)
        refreshLaunchAtLogin()
        if initialConfig == nil, let error = ConfigStore.shared.lastError {
            messageLabel.stringValue = error.localizedDescription
        }
    }

    required init?(coder: NSCoder) { nil }

    func setConnected(_ connected: Bool, deviceName: String?) {
        let name = deviceName ?? "鼠标"
        connectionLabel.stringValue = connected ? "\(name)：已连接" : "\(name)：未连接"
        connectionLabel.textColor = .secondaryLabelColor
        dpiSlider.isEnabled = connected
        messageLabel.stringValue = ""
        if !connected {
            dpiRange.stringValue = "连接支持的鼠标后可调节硬件 DPI"
            messageLabel.stringValue = ""
        }
    }

    func setDPICapabilities(_ capabilities: HIDPPController.DPICapabilities) {
        guard !capabilities.values.isEmpty else { return }
        dpiEdited = false
        dpiValues = capabilities.values
        let source = capabilities.cameFromDevice ? "设备报告" : "兼容范围"
        dpiRange.stringValue = "\(source)：\(capabilities.minimum)–\(capabilities.maximum) DPI · \(capabilities.values.count) 档"
        dpiSlider.doubleValue = percent(forDPI: ConfigStore.shared.config.primaryDPI)
        updateDPIValue()
    }

    func setInputStatus(_ text: String, ready: Bool) {
        inputStatusLabel.stringValue = text
        inputStatusLabel.textColor = ready ? .systemGreen : .systemOrange
    }

    func setDPIApplyResult(_ actualDPI: Int?, requested: Int) {
        if let actualDPI {
            // An external config change must not leave a stale slider that
            // would overwrite the confirmed DPI on the next Save.
            if !dpiEdited {
                dpiSlider.doubleValue = percent(forDPI: actualDPI)
                updateDPIValue()
            }
            messageLabel.textColor = .systemGreen
            messageLabel.stringValue = actualDPI == requested
                ? "已应用并确认 \(actualDPI) DPI"
                : "已按设备支持档位应用 \(actualDPI) DPI（设置值 \(requested)）"
        } else {
            messageLabel.textColor = .systemRed
            messageLabel.stringValue = "配置已保存，但未能确认 \(requested) DPI 已生效"
        }
    }

    func setPermissionStatus(accessibilityGranted: Bool, inputMonitoringGranted: Bool) {
        let accessibility = accessibilityGranted ? "已授权" : "待授权"
        let inputMonitoring = inputMonitoringGranted ? "已授权" : "待授权"
        permissionStatusLabel.stringValue = "辅助功能：\(accessibility)　·　输入监控：\(inputMonitoring)"
        permissionStatusLabel.textColor = accessibilityGranted && inputMonitoringGranted ? .secondaryLabelColor : .systemOrange
    }

    func configureUpdates(automaticChecks: Bool, canCheck: Bool) {
        automaticUpdates.state = automaticChecks ? .on : .off
        automaticUpdates.isEnabled = onAutomaticUpdatesChanged != nil
        updateButton.isEnabled = canCheck && onCheckForUpdates != nil
    }

    func showGeneralSettings() {
        sectionPicker.selectedSegment = 2
        sectionChanged()
    }

    private func buildUI() {
        guard let content = window?.contentView else { return }
        let title = NSTextField(labelWithString: "MouseBridge")
        title.font = .systemFont(ofSize: 20, weight: .semibold)
        connectionLabel.font = .systemFont(ofSize: 12)
        connectionLabel.textColor = .secondaryLabelColor
        let header = NSStackView(views: [title, connectionLabel])
        header.orientation = .vertical
        header.alignment = .leading
        header.spacing = 5

        sectionPicker.selectedSegment = 0
        sectionPicker.segmentStyle = .rounded
        sectionPicker.target = self
        sectionPicker.action = #selector(sectionChanged)
        sectionPicker.setAccessibilityLabel("设置分类")
        for index in 0..<3 { sectionPicker.setWidth(100, forSegment: index) }
        pages.tabViewType = .noTabsNoBorder

        scrollLinesSlider.numberOfTickMarks = 21
        scrollLinesSlider.allowsTickMarkValuesOnly = true
        scrollLinesSlider.target = self
        scrollLinesSlider.action = #selector(scrollLinesChanged)
        dpiSlider.target = self
        dpiSlider.action = #selector(dpiChanged)
        dpiSlider.isEnabled = false
        dpiRange.font = .systemFont(ofSize: 11)
        dpiRange.textColor = .secondaryLabelColor
        for label in [scrollLinesValue, dpiValue] {
            label.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular)
            label.alignment = .right
        }

        trackpadFingerPopup.addItems(withTitles: ["2 指", "3 指", "4 指", "5 指"])
        for (index, item) in trackpadFingerPopup.itemArray.enumerated() { item.tag = index + 2 }
        trackpadEnabled.target = self
        trackpadEnabled.action = #selector(trackpadEnabledChanged)
        launchAtLogin.target = self
        launchAtLogin.action = #selector(toggleLaunchAtLogin)
        automaticUpdates.target = self
        automaticUpdates.action = #selector(automaticUpdatesChanged)
        automaticUpdates.isEnabled = false
        updateButton.target = self
        updateButton.action = #selector(checkForUpdates)
        updateButton.bezelStyle = .rounded
        updateButton.isEnabled = false

        mouseSectionPicker.selectedSegment = 0
        mouseSectionPicker.target = self
        mouseSectionPicker.action = #selector(mouseSectionChanged)
        mouseSectionPicker.setAccessibilityLabel("鼠标设置分类")
        let buttonSection = section("按键与横向滚轮", rows: [mouseMapping])
        let pointerSections = NSStackView(views: [
            section("滚轮", rows: [
                sliderRow(title: "滚动行数", slider: scrollLinesSlider, value: scrollLinesValue),
                reverseVertical, reverseHorizontal,
            ]),
            section("指针速度", rows: [
                sliderRow(title: "DPI", slider: dpiSlider, value: dpiValue), dpiRange,
            ]),
        ])
        pointerSections.orientation = .vertical
        pointerSections.alignment = .leading
        pointerSections.spacing = 18
        for view in pointerSections.arrangedSubviews {
            view.widthAnchor.constraint(equalTo: pointerSections.widthAnchor).isActive = true
        }
        pointerSections.isHidden = true
        mouseSections = [buttonSection, pointerSections]
        let mousePage = makePage([mouseSectionPicker, buttonSection, pointerSections])
        let trackpadPage = makePage([
            section("多指快捷键", rows: [
                trackpadEnabled,
                settingRow("手指数", control: trackpadFingerPopup, width: 120),
                settingRow("执行动作", control: trackpadActionField),
            ]),
            section("触发方式", rows: [trackpadTapEnabled, trackpadAllowMoreFingers,
                helpLabel("默认只在物理按压时触发，并保留原来的左 / 右键点击。开启轻点后，短促轻点也会执行所选动作。"),
            ]),
        ])
        let permissionButtons = NSStackView(views: [
            NSButton(title: "辅助功能设置…", target: self, action: #selector(openAccessibilitySettings)),
            NSButton(title: "输入监控设置…", target: self, action: #selector(openInputMonitoringSettings)),
        ])
        permissionButtons.orientation = .horizontal
        permissionButtons.spacing = 8
        for button in permissionButtons.arrangedSubviews.compactMap({ $0 as? NSButton }) { button.bezelStyle = .rounded }
        permissionStatusLabel.font = .systemFont(ofSize: 12)
        inputStatusLabel.font = .systemFont(ofSize: 12)
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "开发版本"
        let aboutButton = NSButton(title: "关于 MouseBridge…", target: self, action: #selector(showAbout))
        aboutButton.bezelStyle = .rounded
        let generalPage = makePage([
            section("启动", rows: [launchAtLogin]),
            section("权限与运行状态", rows: [permissionStatusLabel, inputStatusLabel, permissionButtons,
                helpLabel("辅助功能用于按键映射；输入监控用于更准确地区分鼠标与触控板。"),
            ]),
            section("软件更新", rows: [automaticUpdates, settingRow("版本 \(version)", control: updateButton, width: 130),
                helpLabel("发现新版本时会提醒你，下载和安装前由你确认。"),
            ]),
            section("关于", rows: [settingRow("MouseBridge", control: aboutButton, width: 160)]),
        ])
        for (index, page) in [mousePage, trackpadPage, generalPage].enumerated() {
            let item = NSTabViewItem(identifier: index)
            item.view = page
            pages.addTabViewItem(item)
        }

        saveButton.target = self
        saveButton.action = #selector(saveConfig)
        saveButton.keyEquivalent = "\r"
        saveButton.bezelStyle = .rounded
        messageLabel.font = .systemFont(ofSize: 11)
        messageLabel.textColor = .secondaryLabelColor
        messageLabel.stringValue = "更改后点击“保存并应用”。"
        let footer = NSStackView(views: [messageLabel, NSView(), saveButton])
        footer.orientation = .horizontal
        footer.alignment = .centerY
        footer.spacing = 16
        messageLabel.setContentHuggingPriority(.defaultLow, for: .horizontal)
        saveButton.setContentHuggingPriority(.required, for: .horizontal)
        saveButton.setContentCompressionResistancePriority(.required, for: .horizontal)
        let divider = NSBox()
        divider.boxType = .separator

        for view in [header, sectionPicker, pages, divider, footer] {
            view.translatesAutoresizingMaskIntoConstraints = false
            content.addSubview(view)
        }
        NSLayoutConstraint.activate([
            header.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 24),
            header.trailingAnchor.constraint(lessThanOrEqualTo: content.trailingAnchor, constant: -24),
            header.topAnchor.constraint(equalTo: content.topAnchor, constant: 20),
            sectionPicker.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 18),
            sectionPicker.centerXAnchor.constraint(equalTo: content.centerXAnchor),
            pages.topAnchor.constraint(equalTo: sectionPicker.bottomAnchor, constant: 18),
            pages.leadingAnchor.constraint(equalTo: content.leadingAnchor),
            pages.trailingAnchor.constraint(equalTo: content.trailingAnchor),
            pages.bottomAnchor.constraint(equalTo: divider.topAnchor, constant: -4),
            divider.leadingAnchor.constraint(equalTo: content.leadingAnchor),
            divider.trailingAnchor.constraint(equalTo: content.trailingAnchor),
            divider.bottomAnchor.constraint(equalTo: footer.topAnchor, constant: -12),
            footer.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 24),
            footer.trailingAnchor.constraint(equalTo: content.trailingAnchor, constant: -24),
            footer.heightAnchor.constraint(greaterThanOrEqualToConstant: 32),
            footer.bottomAnchor.constraint(equalTo: content.bottomAnchor, constant: -16),
        ])
    }

    private func helpLabel(_ text: String) -> NSTextField {
        let label = NSTextField(wrappingLabelWithString: text)
        label.font = .systemFont(ofSize: 11)
        label.textColor = .secondaryLabelColor
        return label
    }

    private func settingRow(_ title: String, control: NSView, width: CGFloat = 300) -> NSStackView {
        let label = NSTextField(labelWithString: title)
        let spacer = NSView()
        let row = NSStackView(views: [label, spacer, control])
        row.orientation = .horizontal
        row.alignment = .centerY
        row.spacing = 12
        control.widthAnchor.constraint(equalToConstant: width).isActive = true
        spacer.widthAnchor.constraint(greaterThanOrEqualToConstant: 0).isActive = true
        label.setContentCompressionResistancePriority(.required, for: .horizontal)
        label.setContentHuggingPriority(.required, for: .horizontal)
        return row
    }

    private func section(_ title: String, rows: [NSView]) -> NSView {
        let label = NSTextField(labelWithString: title)
        label.font = .systemFont(ofSize: 12, weight: .semibold)
        label.textColor = .secondaryLabelColor
        let card = SettingsCardView()
        let body = NSStackView(views: rows)
        body.orientation = .vertical
        body.alignment = .leading
        body.spacing = 12
        body.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(body)
        NSLayoutConstraint.activate([
            body.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16),
            body.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            body.topAnchor.constraint(equalTo: card.topAnchor, constant: 12),
            body.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -12),
        ])
        for row in rows { row.widthAnchor.constraint(equalTo: body.widthAnchor).isActive = true }
        let group = NSStackView(views: [label, card])
        group.orientation = .vertical
        group.alignment = .leading
        group.spacing = 8
        card.widthAnchor.constraint(equalTo: group.widthAnchor).isActive = true
        return group
    }

    private func makePage(_ sections: [NSView]) -> NSScrollView {
        let scroll = NSScrollView()
        scroll.drawsBackground = false
        scroll.hasVerticalScroller = true
        scroll.autohidesScrollers = true
        let document = FlippedSettingsView()
        document.translatesAutoresizingMaskIntoConstraints = false
        scroll.documentView = document
        let stack = NSStackView(views: sections)
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 14
        stack.translatesAutoresizingMaskIntoConstraints = false
        document.addSubview(stack)
        NSLayoutConstraint.activate([
            document.leadingAnchor.constraint(equalTo: scroll.contentView.leadingAnchor),
            document.topAnchor.constraint(equalTo: scroll.contentView.topAnchor),
            document.widthAnchor.constraint(equalTo: scroll.contentView.widthAnchor),
            stack.leadingAnchor.constraint(equalTo: document.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: document.trailingAnchor, constant: -24),
            stack.topAnchor.constraint(equalTo: document.topAnchor, constant: 2),
            stack.bottomAnchor.constraint(equalTo: document.bottomAnchor, constant: -20),
        ])
        for section in sections { section.widthAnchor.constraint(equalTo: stack.widthAnchor).isActive = true }
        return scroll
    }

    @objc private func mouseSectionChanged() {
        window?.makeFirstResponder(nil)
        for (index, section) in mouseSections.enumerated() {
            section.isHidden = index != mouseSectionPicker.selectedSegment
        }
    }

    @objc private func sectionChanged() {
        window?.makeFirstResponder(nil)
        pages.selectTabViewItem(at: sectionPicker.selectedSegment)
        saveButton.isHidden = sectionPicker.selectedSegment == 2
        if messageLabel.textColor == .secondaryLabelColor {
            messageLabel.stringValue = sectionPicker.selectedSegment == 2
                ? "此页的开关立即生效。" : "更改后点击“保存并应用”。"
        }
    }

    @objc private func automaticUpdatesChanged() {
        onAutomaticUpdatesChanged?(automaticUpdates.state == .on)
    }

    @objc private func checkForUpdates() { onCheckForUpdates?() }
    @objc private func showAbout() { onAboutRequested?() }

    @objc private func openAccessibilitySettings() {
        openPrivacySettings("Privacy_Accessibility")
    }

    @objc private func openInputMonitoringSettings() {
        openPrivacySettings("Privacy_ListenEvent")
    }

    private func openPrivacySettings(_ pane: String) {
        guard let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?\(pane)") else { return }
        NSWorkspace.shared.open(url)
    }

    @objc private func toggleLaunchAtLogin() {
        do {
            try LaunchAtLoginController.setEnabled(launchAtLogin.state == .on)
            refreshLaunchAtLogin()
        } catch {
            refreshLaunchAtLogin()
            messageLabel.textColor = .systemRed
            messageLabel.stringValue = "登录启动设置失败：\(error.localizedDescription)"
        }
    }

    private func refreshLaunchAtLogin() {
        switch LaunchAtLoginController.status {
        case .enabled:
            launchAtLogin.isEnabled = true
            launchAtLogin.state = .on
            launchAtLogin.title = "登录时自动启动"
        case .requiresApproval:
            launchAtLogin.isEnabled = true
            launchAtLogin.state = .on
            launchAtLogin.title = "登录时自动启动（等待系统批准）"
        case .disabled:
            launchAtLogin.isEnabled = true
            launchAtLogin.state = .off
            launchAtLogin.title = "登录时自动启动"
        case .unavailable:
            launchAtLogin.isEnabled = false
            launchAtLogin.state = .off
            launchAtLogin.title = "登录时自动启动（当前系统不可用）"
        }
    }

    private func sliderRow(title: String, slider: NSSlider, value: NSTextField) -> NSStackView {
        let titleLabel = NSTextField(labelWithString: title)
        titleLabel.alignment = .right
        titleLabel.widthAnchor.constraint(equalToConstant: 90).isActive = true
        slider.widthAnchor.constraint(greaterThanOrEqualToConstant: 160).isActive = true
        value.widthAnchor.constraint(equalToConstant: 130).isActive = true
        let row = NSStackView(views: [titleLabel, slider, value])
        row.orientation = .horizontal
        row.alignment = .centerY
        row.spacing = 10
        return row
    }

    private func loadConfig(_ initialConfig: AppConfig? = nil) {
        let config = initialConfig ?? ConfigStore.shared.config
        middleField.stringValue = config.middleAction
        backField.stringValue = config.backAction
        forwardField.stringValue = config.forwardAction
        mouseMapping.horizontalLeftField.stringValue = config.horizontalLeftAction
        mouseMapping.horizontalRightField.stringValue = config.horizontalRightAction
        trackpadEnabled.state = config.trackpadGestureEnabled ? .on : .off
        trackpadFingerPopup.selectItem(withTag: config.trackpadFingerCount)
        trackpadActionField.stringValue = config.trackpadAction
        trackpadTapEnabled.state = config.trackpadTapEnabled ? .on : .off
        trackpadAllowMoreFingers.state = config.trackpadAllowMoreFingers ? .on : .off
        reverseVertical.state = config.reverseVerticalScroll ? .on : .off
        reverseHorizontal.state = config.reverseHorizontalScroll ? .on : .off
        scrollLinesSlider.integerValue = config.scrollLines
        dpiSlider.doubleValue = percent(forDPI: config.primaryDPI)
        updateScrollLinesValue()
        updateDPIValue()
        updateTrackpadControls()
    }

    private func percent(forDPI dpi: Int) -> Double {
        guard dpiValues.count > 1 else { return 0 }
        let index = dpiValues.indices.min(by: { abs(dpiValues[$0] - dpi) < abs(dpiValues[$1] - dpi) }) ?? 0
        return Double(index) * 100 / Double(dpiValues.count - 1)
    }

    private func dpiForCurrentPercent() -> Int {
        guard dpiValues.count > 1 else { return dpiValues.first ?? 1000 }
        let index = Int((dpiSlider.doubleValue / 100 * Double(dpiValues.count - 1)).rounded())
        return dpiValues[min(dpiValues.count - 1, max(0, index))]
    }

    @objc private func scrollLinesChanged() { updateScrollLinesValue() }
    @objc private func dpiChanged() { dpiEdited = true; updateDPIValue() }
    @objc private func trackpadEnabledChanged() { updateTrackpadControls() }

    private func updateTrackpadControls() {
        let enabled = trackpadEnabled.state == .on
        trackpadActionField.isEnabled = enabled
        for control in [trackpadFingerPopup, trackpadTapEnabled, trackpadAllowMoreFingers] {
            control.isEnabled = enabled
        }
    }

    private func updateScrollLinesValue() {
        scrollLinesValue.stringValue = scrollLinesSlider.integerValue == 0 ? "跟随系统" : "\(scrollLinesSlider.integerValue) 行"
    }

    private func updateDPIValue() {
        dpiValue.stringValue = "\(dpiForCurrentPercent()) DPI · \(Int(dpiSlider.doubleValue.rounded()))%"
    }

    @objc private func saveConfig() {
        window?.makeFirstResponder(nil)
        let fields = [middleField, backField, forwardField, mouseMapping.horizontalLeftField, mouseMapping.horizontalRightField, trackpadActionField]
        if let index = fields.firstIndex(where: { !ShortcutExecutor.isValid($0.stringValue) }) {
            sectionPicker.selectedSegment = index == 5 ? 1 : 0
            sectionChanged()
            if index < 5 {
                mouseSectionPicker.selectedSegment = 0
                mouseSectionChanged()
                mouseMapping.select(index < 3 ? MouseMappingView.Control(rawValue: index)! : .horizontal)
            }
            fields[index].focus()
            messageLabel.textColor = .systemRed
            messageLabel.stringValue = "格式无效，请使用 cmd+r 或 cmd+left click；none=禁用，留空=透传。"
            return
        }
        var config = ConfigStore.shared.config
        config.middleAction = middleField.stringValue
        config.backAction = backField.stringValue
        config.forwardAction = forwardField.stringValue
        config.horizontalLeftAction = mouseMapping.horizontalLeftField.stringValue
        config.horizontalRightAction = mouseMapping.horizontalRightField.stringValue
        config.trackpadGestureEnabled = trackpadEnabled.state == .on
        config.trackpadFingerCount = trackpadFingerPopup.selectedItem?.tag ?? 3
        config.trackpadAction = trackpadActionField.stringValue
        config.trackpadTapEnabled = trackpadTapEnabled.state == .on
        config.trackpadAllowMoreFingers = trackpadAllowMoreFingers.state == .on
        config.reverseVerticalScroll = reverseVertical.state == .on
        config.reverseHorizontalScroll = reverseHorizontal.state == .on
        config.scrollLines = scrollLinesSlider.integerValue
        if dpiSlider.isEnabled && dpiEdited { config.primaryDPI = dpiForCurrentPercent() }
        config.normalize()
        do {
            let unchanged = config == ConfigStore.shared.config
            try ConfigStore.shared.save(config)
            dpiEdited = false
            loadConfig()
            messageLabel.textColor = .systemGreen
            messageLabel.stringValue = "配置已保存"
            if unchanged && dpiSlider.isEnabled { onDPIApplyRequested?() }
        } catch {
            messageLabel.textColor = .systemRed
            messageLabel.stringValue = error.localizedDescription
        }
    }
}

@MainActor
private final class FlippedSettingsView: NSView {
    override var isFlipped: Bool { true }
}

@MainActor
private final class SettingsCardView: NSView {
    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        let path = NSBezierPath(roundedRect: bounds.insetBy(dx: 0.5, dy: 0.5), xRadius: 10, yRadius: 10)
        NSColor.controlBackgroundColor.setFill()
        path.fill()
        NSColor.separatorColor.setStroke()
        path.lineWidth = 0.5
        path.stroke()
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        needsDisplay = true
    }
}
