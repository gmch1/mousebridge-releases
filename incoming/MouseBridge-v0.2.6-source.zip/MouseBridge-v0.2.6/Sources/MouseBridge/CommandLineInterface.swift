// SPDX-License-Identifier: GPL-3.0-or-later

import ApplicationServices
import Foundation

@MainActor
enum CommandLineInterface {
    static func run(arguments: [String]) -> Int? {
        guard let command = arguments.first else { return nil }
        switch command {
        case "config": return runConfig(Array(arguments.dropFirst()))
        case "device": return runDevice(Array(arguments.dropFirst()))
        case "launch-at-login": return runLaunchAtLogin(Array(arguments.dropFirst()))
        case "diagnose":
            print("config=\(ConfigStore.shared.fileURL.path)")
            print("log=\(DiagnosticLog.shared.fileURL.path)")
            print("accessibility=\(AXIsProcessTrusted())")
            print("input-monitoring=\(CGPreflightListenEventAccess())")
            print("launch-at-login=\(LaunchAtLoginController.status.description)")
            return 0
        case "help", "--help", "-h":
            printHelp()
            return 0
        default: return nil
        }
    }

    /// Queries hardware without loading/saving configuration or writing DPI.
    private static func runDevice(_ arguments: [String]) -> Int {
        guard arguments == ["status"] else {
            return fail("用法：MouseBridge device status", code: 2)
        }
        guard CGPreflightListenEventAccess() else {
            return fail("当前命令行进程没有输入监控权限。终端或自动化工具的权限与 MouseBridge App 独立；可在 App 中查看应用结果。")
        }
        // Separate from the GUI's 0x0A so concurrent replies cannot be mixed.
        let hid = HIDPPController(restoreOnStop: false, softwareID: 0x0B)
        var capabilities: HIDPPController.DPICapabilities?
        var finished = false
        var exitCode = 1
        hid.onDPICapabilities = { capabilities = $0 }
        hid.onConnectionChanged = { connected in
            guard connected else { return }
            let name = hid.connectedDeviceName ?? "Logitech mouse"
            hid.readDPI { dpi in
                DispatchQueue.main.async {
                    print("device=\(name)")
                    print("dpi=\(dpi.map(String.init) ?? "unknown")")
                    if let capabilities {
                        print("dpi-range=\(capabilities.minimum)...\(capabilities.maximum)")
                        print("dpi-values=\(capabilities.values.map(String.init).joined(separator: ","))")
                        print("device-reported=\(capabilities.cameFromDevice)")
                    }
                    exitCode = dpi == nil ? 1 : 0
                    finished = true
                }
            }
        }
        hid.start()
        let deadline = Date().addingTimeInterval(12)
        while !finished && Date() < deadline {
            RunLoop.current.run(until: Date().addingTimeInterval(0.05))
        }
        hid.onConnectionChanged = nil
        hid.onDPICapabilities = nil
        hid.stop()
        if !finished { return fail("未能读取鼠标。请检查蓝牙连接和 MouseBridge 的输入监控权限。") }
        return exitCode
    }

    private static func runLaunchAtLogin(_ arguments: [String]) -> Int {
        guard arguments.count == 1 else {
            return fail("用法：MouseBridge launch-at-login status|enable|disable", code: 2)
        }
        do {
            switch arguments[0] {
            case "status":
                print(LaunchAtLoginController.status.description)
            case "enable":
                try LaunchAtLoginController.setEnabled(true)
                print(LaunchAtLoginController.status.description)
            case "disable":
                try LaunchAtLoginController.setEnabled(false)
                print(LaunchAtLoginController.status.description)
            default:
                return fail("未知 launch-at-login 操作：\(arguments[0])", code: 2)
            }
            return 0
        } catch {
            return fail("登录启动设置失败：\(error.localizedDescription)")
        }
    }

    private static func runConfig(_ arguments: [String]) -> Int {
        guard let operation = arguments.first else {
            printHelp()
            return 2
        }
        switch operation {
        case "path":
            print(ConfigStore.shared.fileURL.path)
            return 0
        case "get":
            do {
                FileHandle.standardOutput.write(try ConfigStore.shared.config.prettyJSONData())
                FileHandle.standardOutput.write(Data("\n".utf8))
                return 0
            } catch {
                return fail(error.localizedDescription)
            }
        case "set":
            guard arguments.count == 3 else {
                return fail("用法：MouseBridge config set <key> <value>", code: 2)
            }
            var config = ConfigStore.shared.config
            let key = arguments[1]
            let value = arguments[2]
            switch key {
            case "middle": config.middleAction = value
            case "back": config.backAction = value
            case "forward": config.forwardAction = value
            case "horizontal-left": config.horizontalLeftAction = value
            case "horizontal-right": config.horizontalRightAction = value
            case "trackpad-action": config.trackpadAction = value
            case "trackpad-enabled":
                guard let parsed = parseBool(value) else { return fail("布尔值应为 true/false", code: 2) }
                config.trackpadGestureEnabled = parsed
            case "trackpad-tap":
                guard let parsed = parseBool(value) else { return fail("布尔值应为 true/false", code: 2) }
                config.trackpadTapEnabled = parsed
            case "trackpad-allow-more":
                guard let parsed = parseBool(value) else { return fail("布尔值应为 true/false", code: 2) }
                config.trackpadAllowMoreFingers = parsed
            case "trackpad-fingers":
                guard let parsed = Int(value), (2...5).contains(parsed) else { return fail("trackpad-fingers 应为 2–5", code: 2) }
                config.trackpadFingerCount = parsed
            case "trackpad-tap-milliseconds":
                guard let parsed = Int(value), (50...1_000).contains(parsed) else { return fail("trackpad-tap-milliseconds 应为 50–1000", code: 2) }
                config.trackpadTapMaxMilliseconds = parsed
            case "trackpad-tap-movement":
                guard let parsed = Double(value), (0.001...0.5).contains(parsed) else { return fail("trackpad-tap-movement 应为 0.001–0.5", code: 2) }
                config.trackpadTapMaxMovement = parsed
            case "reverse-vertical":
                guard let parsed = parseBool(value) else { return fail("布尔值应为 true/false", code: 2) }
                config.reverseVerticalScroll = parsed
            case "reverse-horizontal":
                guard let parsed = parseBool(value) else { return fail("布尔值应为 true/false", code: 2) }
                config.reverseHorizontalScroll = parsed
            case "scroll-lines":
                guard let parsed = Int(value), (0...20).contains(parsed) else { return fail("scroll-lines 应为 0–20", code: 2) }
                config.scrollLines = parsed
            case "dpi":
                guard let parsed = Int(value), (100...8000).contains(parsed) else { return fail("dpi 应为 100–8000", code: 2) }
                config.primaryDPI = parsed
            default:
                return fail("未知配置项：\(key)", code: 2)
            }
            guard [config.middleAction, config.backAction, config.forwardAction, config.horizontalLeftAction, config.horizontalRightAction, config.trackpadAction].allSatisfy(ShortcutExecutor.isValid) else {
                return fail("快捷键格式无效，请使用 cmd+r 或 cmd+left click", code: 2)
            }
            do {
                try ConfigStore.shared.save(config)
                print("ok")
                return 0
            } catch {
                return fail(error.localizedDescription)
            }
        default:
            return fail("未知 config 操作：\(operation)", code: 2)
        }
    }

    private static func parseBool(_ value: String) -> Bool? {
        switch value.lowercased() {
        case "true", "1", "yes", "on": return true
        case "false", "0", "no", "off": return false
        default: return nil
        }
    }

    private static func fail(_ message: String, code: Int = 1) -> Int {
        FileHandle.standardError.write(Data("MouseBridge: \(message)\n".utf8))
        return code
    }

    private static func printHelp() {
        print("""
        MouseBridge commands:
          MouseBridge config path
          MouseBridge config get
          MouseBridge config set middle|back|forward <shortcut|none>
          MouseBridge config set horizontal-left|horizontal-right <shortcut|none>
          MouseBridge config set trackpad-action <shortcut|none>
          MouseBridge config set trackpad-enabled|trackpad-tap|trackpad-allow-more <true|false>
          MouseBridge config set trackpad-fingers <2-5>
          MouseBridge config set trackpad-tap-milliseconds <50-1000>
          MouseBridge config set trackpad-tap-movement <0.001-0.5>
          MouseBridge config set reverse-vertical|reverse-horizontal <true|false>
          MouseBridge config set scroll-lines <0-20>
          MouseBridge config set dpi <100-8000>
          MouseBridge device status
          MouseBridge launch-at-login status|enable|disable
          MouseBridge diagnose

        Example: map the middle button to Command-click (quote actions containing spaces):
          MouseBridge config set middle "cmd+left click"
        """)
    }
}
